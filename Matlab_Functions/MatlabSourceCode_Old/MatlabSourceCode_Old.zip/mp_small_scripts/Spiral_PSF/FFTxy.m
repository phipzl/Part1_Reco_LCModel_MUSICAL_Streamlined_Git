nii = load_nii('/media/mokka1/projects/MRSI_Projects/Process_Results/MRSI_registration_postprocessing/FSL_testing/bet/magnitude_n3corr_brain_pve_1_resliced.nii');
csi = nii.img(:,:,185);
PSFxy = PSFs(:,:,16);
figure(1); imagesc(abs(csi)); colormap(gray)
csi = conv2(csi,PSFxy, 'same');
figure(2); imagesc(abs(csi)); colormap(gray)
% idmax = (csi >= 0.5);
% idmin = (csi < 0.5);
% csi(idmax) = 1;
% csi(idmin) = 0;
% figure(1); imagesc(abs(csi)); colormap(gray)

% first you do fftshift than fft and than fftshift again

s% % csi = conv2(csi,PSFxy, 'same');
% csi = ifft(ifft(csi,[],1),[],2);
% csi = ifftshift(ifftshift(csi,1),2);
% csi = csi(81:113,126:158);
% % csi = fftshift(fftshift(csi,1),2); 
% csi = fft(fft(csi,[],1),[],2);
% % idmax = (csi >= 0.1);
% % idmin = (csi < 0.1);
% % csi(idmax) = 1;
% % csi(idmin) = 0;
% figure(3); imagesc(abs(csi)); colormap(gray)
