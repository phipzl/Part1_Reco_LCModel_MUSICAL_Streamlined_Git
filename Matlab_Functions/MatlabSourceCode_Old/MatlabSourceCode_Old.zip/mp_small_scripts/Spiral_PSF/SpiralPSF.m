spiral_x = load('spiral_read8.pta');
spiral_y = load('spiral_phase8.pta');

figure(1)
plot(spiral_x,'-s');

figure(2)
plot(spiral_y,'-s');

Nt = size(spiral_x,1);

FOV   = 160;      %mm
Gmax  = 9.8E-6;   %T/mm
gamma = 42.576E6; %Hz/T

k_x = zeros(1,Nt);
k_y = zeros(1,Nt);
k_rad = zeros(1,Nt); 
k_phi = zeros(1,Nt);

Nx = 64;
Ny = 64;
PSF = complex(zeros(Nx+1,Ny+1));

%Calculate k-space in (kx,ky) coordinates
for l=1:Nt
    for s = 1:l
    k_x(l) = k_x(l) + gamma*Gmax*spiral_x(s);
    k_y(l) = k_y(l) + gamma*Gmax*spiral_y(s);
    end
end

%Calculate k-space in (kr,kphi) polar coordinates
for l=2:Nt
    k_rad(l) = sqrt(k_x(l)^2 + k_y(l)^2);
    k_phi(l) = atan(k_y(l)/k_x(l));
end

figure(3)
plot(k_x,k_y,'-s');

figure(4)
plot(k_rad,'-s');

figure(5)
plot(k_phi,'-s');

%unwrap the kphi angle
c = 0;
for l=2:Nt
    if (k_phi(l-1) > 0 && k_phi(l) < 0)
        c = c + 1;
    end
end

v = zeros(1,c);
d = 0
for l=2:Nt
    if (k_phi(l-1) > 0 && k_phi(l) < 0)
        d = d + 1;
        v(d) = l;
    end
end

q=2
for l=v(1):(v(c)-1)
    if ( l == v(q) )
        if ( q < c )
        q = q + 1;
        end
    end
    if ( v(q-1) <= l < v(q)-1 )
       k_phi(l) = k_phi(l) + (q-1)*pi; 
       %fprintf('(l,q,v) = %d\t%d\t%d\n', l,q,v(q-1))
    end
end

for l=v(c):Nt    
       k_phi(l) = k_phi(l) + c*pi;   
end
%finished unwrapping kphi
%plot the unwrapped phase
figure(6)
plot(k_phi,'-s');

%calculate PSF(x,y) = Sum_kr(Sum_kphi(kr*dkr*dkphi*exp(i*2pi*kr*r)))
%dkr is the same all over kspace and is actually not included explicitly
for nx = 1:(Nx+1)
    for ny = 1:(Ny+1)
        for p=1:(Nt-1)
            PSF(nx,ny) = PSF(nx,ny) + k_rad(p)*(k_phi(p+1)-k_phi(p))*exp(i*2*pi*(k_x(p)*(nx-1-Nx/2)/Nx*FOV + k_y(p)*(ny-1-Ny/2)/Ny*FOV));           
            %for r = 1:(Nt-1)
            %    PSF(nx,ny) = PSF(nx,ny) + k_rad(p)*(k_phi(r+1)-k_phi(r))*exp(i*2*pi*(k_x(p)*(nx-1-Nx/2)/Nx*FOV + k_y(r)*(ny-1-Ny/2)/Ny*FOV));
            %end
        end
        fprintf('(nx,ny) = %d\t%d\n', nx,ny);
        %fprintf('PSF = %d\n', real(PSF(nx,ny)));
    end
end

figure(7);
surf(real(PSF));

figure(8);
contourf(real(PSF));
