% A = nii.img(:,:,180);
A = convoluted_bin;
idmax = (A >= 0.5);
idmin = (A < 0.5);
A(idmax) = 1;
A(idmin) = 0;