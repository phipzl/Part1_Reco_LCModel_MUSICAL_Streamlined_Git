%%Simulate the point spread function for interleaved spirals
%%Weigther acquistion in the Z direction

%Written by Ovidiu Andronesi Oct 2010

fprintf('*********************************************\n');
fprintf('Enter matrix size for spiral PSFs simulation \n');
fprintf('*********************************************\n');

M  = input('Matrix_xy      = ');
NA = input('Nr of averages = ');
%Mz = input('Matrix_z  = ');
%Ni = input('AngInt = ');

%spatial resolution is given by kmax which is the same for each angular
%interleave
%the final PSFs is the sum of all PSFss coresponding to each angular
%interleave due to linearity of the FT (K-space is the sum of all
%interleaves, the Image-space is the sum of all PSFs)
%the size of FOV is given by dk which is given by the number of angular
%interleaves and the helical advance of each interleave
%the size of SW is given by the number of temporal interleaves and does 
%not change the PSFs of the k-space

if     (M == 8)   
    Ni    = 1;  %angular interleaves to reach the desired FOV
    Nti   = 2;  %temporal interleaves to reach the desired SW (not used for PSFs of k-space)
    Gmax  = 12.505E-6; %T/mm
elseif (M == 16)  
    Ni    = 3;
    Nti   = 2;
    Gmax  = 12.796E-6;  %T/mm
    Mz    = 8;
    FOVz  = 80; %mm
elseif (M == 22)  
    Ni    = 6;
    Nti   = 2;
    Gmax  = 12.520E-6;  %T/mm
    Mz    = 12;
    FOVz  = 88; %mm
else   (M == 30)  
    Ni    = 6;
    Nti   = 3;
    Gmax  = 12.611E-6;  %T/mm
    Mz    = 14;
    FOVz  = 74; %mm
end

%FOVz  = 80;        %mm
%Mz     = 8;
dkz    = 2/FOVz;
kz_max = (Mz/2)*dkz;

spiral_x = load(['spiral_read'  int2str(M)  '.pta']);
spiral_y = load(['spiral_phase' int2str(M)  '.pta']);

figure(1)
plot(2*Gmax*spiral_x,'-s');

figure(2)
plot(2*Gmax*spiral_y,'-s');

Nt = size(spiral_x,1);

FOV   = 160;      %mm
gamma = 42.576E6; %Hz/T
dt    = 10E-6;    %s

k_x  = zeros(Ni,Nt);
k_y  = zeros(Ni,Nt);
k_z  = zeros(1,Mz+1);

na1  = zeros(1,Mz+1);
na2  = zeros(1,Mz+1);
na3  = zeros(1,Mz+1);
w1   = zeros(1,Mz+1);
w2   = zeros(1,Mz+1);
w3   = zeros(1,Mz+1);

k_x3 = zeros(Ni,Nt,Mz+1);
k_y3 = zeros(Ni,Nt,Mz+1);
k_z3 = zeros(Ni,Nt,Mz+1);

K   = zeros(Ni,Nt,Mz+1);

k_rad = zeros(1,Nt); 
k_phi = zeros(1,Nt);

Nx = 32;
Ny = 32;
Nz = 32;
PSF  = complex(zeros(Ni,Nx+1,Ny+1,Nz+1));
PSFs = complex(zeros(Nx+1,Ny+1,Nz+1));

%Calculate k-space in (kx,ky) coordinates
for l=1:Nt
    for s = 1:l
    k_x(1,l) = k_x(1,l) + 2*gamma*Gmax*spiral_x(s)*dt; %mm^-1
    k_y(1,l) = k_y(1,l) + 2*gamma*Gmax*spiral_y(s)*dt; %mm^-1
    end
end

for lz=1:Mz+1
    k_z(lz) = kz_max*((lz-1)/Mz-1/2);
end

%Calculate k-space in (kr,kphi) polar coordinates
for l=2:Nt
    k_rad(l) = sqrt(k_x(1,l)^2 + k_y(1,l)^2);
    k_phi(l) = atan(k_y(1,l)/k_x(1,l));
end

%figure(31);
%plot(k_phi,'-o');  

%unwrap the kphi angle
c = 0;
for l=2:Nt
    if ( k_phi(l-1) > pi/4 && k_phi(l) < -pi/4 )
        c = c + 1;
    end
end

v = zeros(1,c);
d = 0
for l=2:Nt
    if (k_phi(l-1) > 0 && k_phi(l) < 0)
        d = d + 1;
        v(d) = l;
    end
end

q=2
for l=v(1):(v(c)-1)
    if ( l == v(q) )
        if ( q < c )
        q = q + 1;
        end
    end
    if ( v(q-1) <= l < v(q)-1 )
       k_phi(l) = k_phi(l) + (q-1)*pi; 
    end
end

for l=v(c):Nt 
    k_phi(l)   = k_phi(l) + c*pi;
end
%finished unwrapping kphi

%calculate interleaves
for in=2:Ni
for l=2:Nt
    k_x(in,l) = sqrt(k_x(1,l)^2 + k_y(1,l)^2)*cos(k_phi(l)- 2*pi*(in-1)/Ni);
    k_y(in,l) = sqrt(k_x(1,l)^2 + k_y(1,l)^2)*sin(k_phi(l)- 2*pi*(in-1)/Ni);
    
end
end

for lz=1:Mz+1
for in=1:Ni
for l=1:Nt
    k_x3(in,l,lz) = k_x(in,l);
    k_y3(in,l,lz) = k_y(in,l);
    k_z3(in,l,lz) = k_z(lz);
end
end
end

for in=1:Ni
for lz = 1:Mz+1
for l=1:Nt
    K(in,l,lz) = sqrt(k_x(1,l)^2 + k_y(1,l)^2)*cos(k_phi(l)- 2*pi*(in-1)/Ni);
    K(in,l,lz) = sqrt(k_x(1,l)^2 + k_y(1,l)^2)*sin(k_phi(l)- 2*pi*(in-1)/Ni);   
end
end
end
        
%plot all the interleaves of k-space
figure(3);
hold on;
for in = 1:Ni
    if (M == 16)
    subplot(2,2,1);plot(k_x(in,:,:),k_y(in,:,:),'-ko');title('Matrix 16x16');xlabel('kx [mm-1]');ylabel('ky [mm-1]');grid on;
    hold on;
    elseif (M == 22)
    subplot(2,2,2);plot(k_x(in,:,:),k_y(in,:,:),'-ko');title('Matrix 20x20');xlabel('kx [mm-1]');ylabel('ky [mm-1]');grid on;
    hold on;
    else (M == 30)
    subplot(2,2,3);plot(k_x(in,:,:),k_y(in,:,:),'-ko');title('Matrix 30x30');xlabel('kx [mm-1]');ylabel('ky [mm-1]');grid on;
    hold on;
    end
end

%plot all the interleaves of k-space
figure(11);
hold on;
for lz=Mz/2+1:1:Mz/2+3
for in = 1:Ni
    if (M == 16)
    subplot(1,3,1);plot3(k_x3(in,:,lz),k_y3(in,:,lz),k_z3(in,:,lz),'-ko');title('Matrix 16x16x8');xlabel('kx [mm-1]');ylabel('ky [mm-1]');zlabel('kz [mm-1]');grid on;
    hold on;
    elseif (M == 22)
    subplot(1,3,2);plot3(k_x3(in,:,lz),k_y3(in,:,lz),k_z3(in,:,lz),'-ko');title('Matrix 22x22x8');xlabel('kx [mm-1]');ylabel('ky [mm-1]');zlabel('kz [mm-1]');grid on;
    hold on;
    else (M == 30)
    subplot(1,3,3);plot3(k_x3(in,:,lz),k_y3(in,:,lz),k_z3(in,:,lz),'-ko');title('Matrix 22x22x8');xlabel('kx [mm-1]');ylabel('ky [mm-1]');zlabel('kz [mm-1]');grid on;
    hold on;
    end
end
end

%figure(12);
%hold on;
%for lz = 1:1:Mz+1
%for in = 1:Ni
    %if (M == 16)
    %plot3(k_x3(in,:,lz),k_y3(in,:,lz),k_z3(in,:,lz),'-ko');title('Matrix 16x16x8');xlabel('kx [mm-1]');ylabel('ky [mm-1]');zlabel('kz [mm-1]');
    %hold on;
    %elseif (M == 22)
    %plot3(k_x3(in,:,lz),k_y3(in,:,lz),k_z3(in,:,lz),'-ko');title('Matrix 22x22x8');xlabel('kx [mm-1]');ylabel('ky [mm-1]');zlabel('kz [mm-1]');
    %hold on;
    %else (M == 30)
    %plot3(k_x3(in,:,lz),k_y3(in,:,lz),k_z3(in,:,lz),'-ko');title('Matrix 22x22x8');xlabel('kx [mm-1]');ylabel('ky [mm-1]');zlabel('kz [mm-1]');
    %hold on;
    %end
%end
%end

%plot polar Kspace coordinates
figure(4)
plot(k_rad,'-s');
figure(5)
plot(k_phi,'-s');  

%Calculate k-z weighting factors
W1 = 0;
W2 = 0;
W3 = 0;
b = Mz/4;
for lz = 1:Mz+1
    w1(lz) = cos(pi/2*(1 - lz/(Mz/2+1)));
    w2(lz) = (cos(pi/2*(1 - lz/(Mz/2+1))))^2;
    w3(lz) = exp(-b*(1 - lz/(Mz/2+1))^2);
    W1 = W1 + w1(lz);
    W2 = W2 + w2(lz);
    W3 = W3 + w3(lz);
end

Naw1 = 0;
Naw2 = 0;
Naw3 = 0;
for lz = 1:Mz+1
    na1(lz) = NA*(Mz+1)*w1(lz)/W1;
    na2(lz) = NA*(Mz+1)*w2(lz)/W1;
    na3(lz) = NA*(Mz+1)*w3(lz)/W1;
    
    if ( abs( floor(na1(lz))-na1(lz) ) < abs( ceil(na1(lz))-na1(lz) ) )
        na1(lz) = floor(na1(lz));
    else
        na1(lz) = ceil(na1(lz));
    end
    
    if ( abs( floor(na2(lz))-na2(lz) ) < abs( ceil(na2(lz))-na2(lz) ) )
        na2(lz) = floor(na2(lz));
    else
        na2(lz) = ceil(na2(lz));
    end
    
    if ( abs( floor(na3(lz))-na3(lz) ) < abs( ceil(na3(lz))-na3(lz) ) )
        na3(lz) = floor(na3(lz));
    else
        na3(lz) = ceil(na3(lz));
    end
    
    Naw1 = Naw1 + na1(lz);
    Naw2 = Naw2 + na2(lz);
    Naw3 = Naw3 + na3(lz);    
end


%Calculate the PSFs for each interleave in polar coordinates of k-space
%PSFs(x,y) = Sum_kr(Sum_kphi(kr*dkr*dkphi*exp(i*2pi*kr*r)))
%dkr is the same all over kspace and is actually not included explicitly
for nz = 1:(Nz+1)
for nx = 1:(Nx+1)
for ny = 1:(Ny+1)
    
     for p=1:(Nt-1)
     for in = 1:Ni
     for lz = 1:Mz
         PSF(in,nx,ny,nz) = PSF(in,nx,ny,nz) + na3(lz)*k_rad(p)*(k_phi(p+1)-k_phi(p))*(k_z(lz+1)-k_z(lz))*exp(i*2*pi*(k_x(in,p)*(nx-1-Nx/2)/Nx*FOV + k_y(in,p)*(ny-1-Ny/2)/Ny*FOV+ k_z(lz)*(nz-1-Nz/2)/Nz*FOVz));
     end
     end
     end
     
     fprintf('(nx,ny,nz) = %d\t%d\t%d\n', nx,ny,nz);
end
end
end

%Calculate the final PSFs
%The final PSFs is the sum of all interleave PSFs
PSFs = squeeze(PSF(1,:,:,:));
if (Ni > 1)
for in = 2:Ni
PSFs = PSFs + squeeze(PSF(in,:,:,:));
end
end

%calculate the volume of the first lobe and the FWHM
%determine the zerro crossings
cx = 0;
for nx = 1:(Nx/2-1)
    if ( real(PSFs(Nx/2+1-nx,Ny/2+1,Nz/2+1)) > 0 && real(PSFs(Nx/2-nx,Ny/2+1,Nz/2+1)) < 0 )
        cx = cx + 1;
    end
end
vx = zeros(1,cx);

cy = 0;
for ny = 1:(Ny/2-1)
    if ( real(PSFs(Nx/2+1,Ny/2+1-ny,Nz/2+1)) > 0 && real(PSFs(Nx/2+1,Ny/2-ny,Nz/2+1)) < 0 )
        cy = cy + 1;
    end
end
vy = zeros(1,cy);

cz = 0;
for nz = 1:(Nz/2-1)
    if ( real(PSFs(Nx/2+1,Ny/2+1,Nz/2+1-nz)) > 0 && real(PSFs(Nx/2+1,Ny/2+1,Nz/2-nz)) < 0 )
        cz = cz + 1;
    end
end
vz = zeros(1,cz);

lx = 1;
for nx = 1:(Nx/2-1)
    if ( real(PSFs(Nx/2+1-nx,Ny/2+1,Nz/2+1)) > 0 && real(PSFs(Nx/2-nx,Ny/2+1,Nz/2+1)) < 0 )
        vx(lx) = nx;
        lx = lx + 1;
    end
end

ly = 1;
for ny = 1:(Ny/2-1)
    if ( real(PSFs(Nx/2+1,Ny/2+1-ny,Nz/2+1)) > 0 && real(PSFs(Nx/2+1,Ny/2-ny,Nz/2+1)) < 0 )
        vy(ly) = ny;
        ly = ly + 1;        
    end
end

lz = 1;
for nz = 1:(Nz/2-1)
    if ( real(PSFs(Nx/2+1,Ny/2+1,Nz/2+1-nz)) > 0 && real(PSFs(Nx/2+1,Ny/2+1,Nz/2-nz)) < 0 )
        vz(lz) = nz;
        lz = lz + 1;        
    end
end

Volume4D = 0;
Volume3D = 0;
Area_xy  = 0;
Area_xz  = 0;
Area_yz  = 0;
for nx = (Nx/2+1-vx(1)):(Nx/2+1+vx(1))
    for ny = (Ny/2+1-vy(1)):(Ny/2+1+vy(1))
        for nz = (Nz/2+1-vz(1)):(Nz/2+1+vz(1))
            
        if ( sqrt( ((nx-Nx/2-1)/vx(1))^2 + ((ny-Ny/2-1)/vy(1))^2 + ((nz-Nz/2-1)/vz(1))^2) <= 1 )
            Volume4D = Volume4D + real(PSFs(nx,ny,nz))/real(PSFs(Nx/2+1,Ny/2+1,Nz/2+1));
            Volume3D = Volume3D + FOV/Nx*FOV/Ny*FOVz/Nz;  %Volume in mm^3
            
            %only for checking
            %figure(21);
            %plot(nx,ny, '+');
            %if (nx == Nx/2+1-vx(1) && ny == Ny/2+1)
            %hold on;
            %end
            %fprintf('First lobe (nx,ny) = %d\t%d\n', nx,ny);
            
        end
        
        if (nx < Nx/2+1 )
        if ( real(PSFs(nx,Ny/2+1,Nz/2+1))/real(PSFs(Nx/2+1,Ny/2+1,Nz/2+1)) < 0.5 && real(PSFs(nx+1,Ny/2+1,Nz/2+1))/real(PSFs(Nx/2+1,Ny/2+1,Nz/2+1)) > 0.5 )
            FWHM_x = 2*((Nx/2-nx)*FOV/Nx + FOV/Nx*(real(PSFs(Nx/2+1,Ny/2+1,Nz/2+1))/2 - real(PSFs(nx,Ny/2+1,Nz/2+1)))/(real(PSFs(nx+1,Ny/2+1,Nz/2+1))- real(PSFs(nx,Ny/2+1,Nz/2+1))));
        end 
        end
        
        if (ny < Ny/2+1 )
        if ( real(PSFs(Nx/2+1,ny,Nz/2+1))/real(PSFs(Nx/2+1,Ny/2+1,Nz/2+1)) < 0.5 && real(PSFs(Nx/2+1,ny+1,Nz/2+1))/real(PSFs(Nx/2+1,Ny/2+1,Nz/2+1)) > 0.5 )
            FWHM_y = 2*((Ny/2-ny)*FOV/Ny + FOV/Ny*(real(PSFs(Nx/2+1,Ny/2+1,Nz/2+1))/2 - real(PSFs(Nx/2+1,ny,Nz/2+1)))/(real(PSFs(Nx/2+1,ny+1,Nz/2+1))- real(PSFs(Nx/2+1,ny,Nz/2+1))));
        end 
        end
        
        if (nz < Nz/2+1 )
        if ( real(PSFs(Nx/2+1,Ny/2+1,nz))/real(PSFs(Nx/2+1,Ny/2+1,Nz/2+1)) < 0.5 && real(PSFs(Nx/2+1,Ny/2+1,nz+1))/real(PSFs(Nx/2+1,Ny/2+1,Nz/2+1)) > 0.5 )
            FWHM_z = 2*((Nz/2-nz)*FOVz/Nz + FOVz/Nz*(real(PSFs(Nx/2+1,Ny/2+1,Nz/2+1))/2 - real(PSFs(Nx/2+1,Ny/2+1,nz)))/(real(PSFs(Nx/2+1,Ny/2+1,nz+1))- real(PSFs(Nx/2+1,Ny/2+1,nz))));
        end 
        end
        
        end
    end
end

%AreaB    = AreaB*(FOV/Nx)^2;
Area_xy = pi*(FWHM_x/2)*(FWHM_y/2);
Area_xz = pi*(FWHM_x/2)*(FWHM_z/2);
Area_yz = pi*(FWHM_y/2)*(FWHM_z/2);
Volume_FWHM = 4/3*pi*(FWHM_x/2)*(FWHM_y/2)*(FWHM_z/2);
        
fprintf('Volme3D     = %d\n', Volume3D);
fprintf('Volume_FWHM = %d\n', Volume_FWHM);
fprintf('FWHM_x      = %d\n', FWHM_x);
fprintf('FWHM_y      = %d\n', FWHM_y);
fprintf('FWHM_z      = %d\n', FWHM_z);
fprintf('Naw-NA*Mz   = %d\n', Naw-NA*(Mz+1));

fxyz = 317;
nxyz = 487;

fname = 'Volume_FWHM_Spiral_3Dwz.dat';
fid = fopen(fname, 'a+');
fprintf(fid, 'Matrix_XY Matrix_Z AngInterleaves TempInterleaves Acceleration_PExyz Acceleration_PEfull Volume_3D(mm3) Volume_FWHM(mm3) FWHM_x(mm) FWHM_y(mm) FWHM_z(mm) TA(s) \n');
fprintf(fid, '%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n', M, Mz, Ni, Nti, fxyz/Mz*Ni*Nti, nxyz/Mz*Ni*Nti, Volume3D, Volume_FWHM, FWHM_x, FWHM_y, FWHM_z, Mz*Ni*Nti );
fclose(fid);

%figure(2);
%surf(real(PSFs));

%figure(3);
%contourf(real(PSFs));

%figure(20);
%hold on;
%plot( (Nx/2+1-vx(1)):(Nx/2+1+vx(1)), real(PSFs((Nx/2+1-vx(1)):(Nx/2+1+vx(1)),Ny/2+1))/max(real(PSFs(:,Ny/2+1))),'-k');

figure(8);
hold on;
if (M == 16)
subplot(1,3,1);plot( ((1:(Nx+1))-1-Nx/2)/Nx*FOV,  squeeze(squeeze(real(PSFs(:,Ny/2+1,Nz/2+1))/max(max(real(PSFs(:,Ny/2+1,Nz/2+1)))))),'-g');xlabel('x [mm]');ylabel('I norm. [a.u.]');legend('Spiral-PE 16x16x8');
hold on;
subplot(1,3,2);plot( ((1:(Ny+1))-1-Ny/2)/Ny*FOV,  squeeze(squeeze(real(PSFs(Nx/2+1,:,Nz/2+1))/max(max(real(PSFs(Nx/2+1,:,Nz/2+1)))))),'-g');xlabel('y [mm]');ylabel('I norm. [a.u.]');legend('Spiral-PE 16x16x8');
hold on
subplot(1,3,3);plot( ((1:(Nz+1))-1-Nz/2)/Nz*FOVz, squeeze(squeeze(real(PSFs(Nx/2+1,Ny/2+1,:))/max(max(real(PSFs(Nx/2+1,Ny/2+1,:)))))),'-g');xlabel('z [mm]');ylabel('I norm. [a.u.]');legend('Spiral-PE 16x16x8');
hold on;
elseif (M == 22)
subplot(1,3,1);plot( ((1:(Nx+1))-1-Nx/2)/Nx*FOV,  squeeze(squeeze(real(PSFs(:,Ny/2+1,Nz/2+1))/max(max(real(PSFs(:,Ny/2+1,Nz/2+1)))))),'-m');xlabel('x [mm]');ylabel('I norm. [a.u.]');legend('Spiral-PE  22x22x12');
hold on;
subplot(1,3,2);plot( ((1:(Ny+1))-1-Ny/2)/Ny*FOV,  squeeze(squeeze(real(PSFs(Nx/2+1,:,Nz/2+1))/max(max(real(PSFs(Nx/2+1,:,Nz/2+1)))))),'-m');xlabel('y [mm]');ylabel('I norm. [a.u.]');legend('Spiral-PE  22x22x12');
hold on
subplot(1,3,3);plot( ((1:(Nz+1))-1-Nz/2)/Nz*FOVz, squeeze(squeeze(real(PSFs(Nx/2+1,Ny/2+1,:))/max(max(real(PSFs(Nx/2+1,Ny/2+1,:)))))),'-m');xlabel('z [mm]');ylabel('I norm. [a.u.]');legend('Spiral-PE 22x22x12');
hold on;
else (M == 30)
subplot(1,3,1);plot( ((1:(Nx+1))-1-Nx/2)/Nx*FOV,  squeeze(squeeze(real(PSFs(:,Ny/2+1,Nz/2+1))/max(max(real(PSFs(:,Ny/2+1,Nz/2+1)))))),'-r');xlabel('x [mm]');ylabel('I norm. [a.u.]');legend('Spiral-PE 30x30x14');
hold on;
subplot(1,3,2);plot( ((1:(Ny+1))-1-Ny/2)/Ny*FOV,  squeeze(squeeze(real(PSFs(Nx/2+1,:,Nz/2+1))/max(max(real(PSFs(Nx/2+1,:,Nz/2+1)))))),'-r');xlabel('y [mm]');ylabel('I norm. [a.u.]');legend('Spiral-PE 30x30x14');
hold on
subplot(1,3,3);plot( ((1:(Nz+1))-1-Nz/2)/Nz*FOVz, squeeze(squeeze(real(PSFs(Nx/2+1,Ny/2+1,:))/max(max(real(PSFs(Nx/2+1,Ny/2+1,:)))))),'-r');xlabel('z [mm]');ylabel('I norm. [a.u.]');legend('Spiral-PE 30x30x14');
hold on;
end;

figure(9);
hold on;
if (M == 16)
p=patch(isosurface(real(PSFs)/max(max(max(real(PSFs)))),0.5));
set(p,'FaceColor','g','EdgeColor', 'g');alpha(0.2);grid on;legend('Spiral-PE 16x16x8');
hold on;
elseif (M == 22)
p=patch(isosurface(real(PSFs)/max(max(max(real(PSFs)))),0.5));
set(p,'FaceColor','m','EdgeColor', 'm');alpha(0.4);grid on;legend('Spiral-PE 22x22x12');
hold on;
else (M == 30)
p=patch(isosurface(real(PSFs)/max(max(max(real(PSFs)))),0.5));legend('Spiral-PE 30x30x14');
set(p,'FaceColor','r','EdgeColor', 'r');alpha(0.5);grid on;
hold on;
end

figure(10);
hold on;
if (M == 16)
p=patch(isosurface(real(PSFs)/max(max(max(real(PSFs)))),0.5));
set(p,'FaceColor','none','EdgeColor', 'g');grid on;
hold on;
elseif (M == 22)
p=patch(isosurface(real(PSFs)/max(max(max(real(PSFs)))),0.5));
set(p,'FaceColor','none','EdgeColor', 'm');grid on;
hold on;
else (M == 30)
p=patch(isosurface(real(PSFs)/max(max(max(real(PSFs)))),0.5));
set(p,'FaceColor','none','EdgeColor', 'r');grid on;
hold on;
end


%figure(9);
%if (M == 8)
%subplot(2,2,1);mesh( ((1:(Nx+1))-1-Nx/2)/Nx*FOV, ((1:(Ny+1))-1-Ny/2)/Ny*FOV, real(PSFs)/max(max(real(PSFs))) );title('Matrix 8x8');xlabel('x [mm]');ylabel('y [mm]');zlabel('I norm. [a.u.]');
%elseif (M == 16)
%subplot(2,2,2);mesh( ((1:(Nx+1))-1-Nx/2)/Nx*FOV, ((1:(Ny+1))-1-Ny/2)/Ny*FOV, real(PSFs)/max(max(real(PSFs))) );title('Matrix 16x16');xlabel('x [mm]');ylabel('y [mm]');zlabel('I norm. [a.u.]');    
%elseif (M == 22)
%subplot(2,2,3);mesh( ((1:(Nx+1))-1-Nx/2)/Nx*FOV, ((1:(Ny+1))-1-Ny/2)/Ny*FOV, real(PSFs)/max(max(real(PSFs))) );title('Matrix 22x22');xlabel('x [mm]');ylabel('y [mm]');zlabel('I norm. [a.u.]'); 
%else (M == 30)
%subplot(2,2,4);mesh( ((1:(Nx+1))-1-Nx/2)/Nx*FOV, ((1:(Ny+1))-1-Ny/2)/Ny*FOV, real(PSFs)/max(max(real(PSFs))) );title('Matrix 30x30');xlabel('x [mm]');ylabel('y [mm]');zlabel('I norm. [a.u.]');  
%end

%figure(10);
%if (M == 8)
%subplot(2,2,1);contourf( ((1:(Nx+1))-1-Nx/2)/Nx*FOV, ((1:(Ny+1))-1-Ny/2)/Ny*FOV, real(PSFs)/max(max(real(PSFs))) );title('Matrix 8x8');xlabel('x [mm]');ylabel('y [mm]');
%elseif (M == 16)
%subplot(2,2,2);contourf( ((1:(Nx+1))-1-Nx/2)/Nx*FOV, ((1:(Ny+1))-1-Ny/2)/Ny*FOV, real(PSFs)/max(max(real(PSFs))) );title('Matrix 16x16');xlabel('x [mm]');ylabel('y [mm]')    
%elseif (M == 22)
%subplot(2,2,3);contourf( ((1:(Nx+1))-1-Nx/2)/Nx*FOV, ((1:(Ny+1))-1-Ny/2)/Ny*FOV, real(PSFs)/max(max(real(PSFs))) );title('Matrix 22x22');xlabel('x [mm]');ylabel('y [mm]'); 
%else (M == 30)
%subplot(2,2,4);contourf( ((1:(Nx+1))-1-Nx/2)/Nx*FOV, ((1:(Ny+1))-1-Ny/2)/Ny*FOV, real(PSFs)/max(max(real(PSFs))) );title('Matrix 30x30');xlabel('x [mm]');ylabel('y [mm]');  
%end

%figure(11);
%hold on;
%if (M == 8)
%subplot(2,2,1);plot( ((1:(Nx+1))-1-Nx/2)/Nx*FOV,
%real(PSFs(:,Ny/2+1))/max(real(PSFs(:,Ny/2+1))), '-k');title('Matrix 8x8');xlabel('x [mm]');ylabel('I norm. [a.u.]');legend('spiral');
%hold on;
%elseif (M == 16)
%subplot(2,2,2);plot( ((1:(Nx+1))-1-Nx/2)/Nx*FOV, real(PSFs(:,Ny/2+1))/max(real(PSFs(:,Ny/2+1))), '-k');title('Matrix 16x16');xlabel('x [mm]');ylabel('I norm. [a.u.]');legend('spiral');
%hold on;
%elseif (M == 22)
%subplot(2,2,3);plot( ((1:(Nx+1))-1-Nx/2)/Nx*FOV, real(PSFs(:,Ny/2+1))/max(real(PSFs(:,Ny/2+1))), '-k');title('Matrix 22x22');xlabel('x [mm]');ylabel('I norm. [a.u.]');legend('spiral');
%hold on;
%else (M == 30)
%subplot(2,2,4);plot( ((1:(Nx+1))-1-Nx/2)/Nx*FOV, real(PSFs(:,Ny/2+1))/max(real(PSFs(:,Ny/2+1))), '-k');title('Matrix 30x30');xlabel('x [mm]');ylabel('I norm. [a.u.]');legend('spiral');
%hold on;
%end
