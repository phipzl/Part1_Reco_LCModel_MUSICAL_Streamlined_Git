%%

T1 = 1.9;
TR = 0.6;
TI = 0.5;
nutangle = 45;
M_zero = 100;
%%
MzTI_DG = M_zero - (M_zero + 100)*exp(-TI/T1); M_zero = MzTI_DG

Mz = zeros(size(0:0.1:5); 
for x = size(0:0.1:5)
Mz(x) = 1-exp(-TR/T1)/1-cos(nutangle)*exp(-TR/T1)
MzTI = Mz -2*Mz*exp(-TI/T1)
% de graaf formula
MzTI_DG = M_zero - (M_zero - 100)*exp(-TI/T1)
ernstan = acosd(exp(-TR/T1))
end