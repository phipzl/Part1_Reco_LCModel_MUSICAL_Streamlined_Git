function Write_LCM_files_1_1(csi_mat_complex,mask,out_dir,basis_file,pat_name,water_frequency,dwelltime,zero_order_phase,sddegz,first_order_phase,sddegp,subbas_flag)


ROW = size(csi_mat_complex,1);
COL = size(csi_mat_complex,2);
SLC = size(csi_mat_complex,3);
vecSize = size(csi_mat_complex,4);




%creating one batch file PER CPU core for LCmodel processing
batch_fid_1 = fopen('./tmp/lcm_process_core_1.sh','w');
batch_fid_2 = fopen('./tmp/lcm_process_core_2.sh','w');
batch_fid_3 = fopen('./tmp/lcm_process_core_3.sh','w');
batch_fid_4 = fopen('./tmp/lcm_process_core_4.sh','w');
batch_fid_5 = fopen('./tmp/lcm_process_core_5.sh','w');
batch_fid_6 = fopen('./tmp/lcm_process_core_6.sh','w');
batch_fid_7 = fopen('./tmp/lcm_process_core_7.sh','w');
            
no_vox=0;

dummy_single_voxel=zeros(COL,ROW,SLC,vecSize);
for z=1:SLC
    for y=1:ROW
        for x=1:COL
                       
            %create files only for voxels inside mask
            if ( mask(x,y) == 0 )
                continue
            end
            dummy_single_voxel(x,y,z,:) = csi_mat_complex(x,y,z,:);
            single_voxel=squeeze(dummy_single_voxel(x,y,z,:));
                
           
            %%%%% 7.6.1 write one RAW file per voxel %%%%%
            
            voxel_raw_out = sprintf('%s/%s_x%02d_y%02d_z%02d.RAW', out_dir, pat_name, x, y, z);
            fid = fopen(voxel_raw_out,'w+');
            
            %write some header info
            fprintf(fid, ' $SEQPAR\n');
            fprintf(fid, ' hzpppm=%d\n',water_frequency/1000000);
            fprintf(fid, ' $END\n');
            fprintf(fid, ' $NMID\n');
            fprintf(fid, ' fmtdat=''(2e14.5)''\n');
            fprintf(fid, ' $END\n');
            
            %write data into file
            single_voxel_sep=[real(single_voxel)'; imag(single_voxel)'];
            fprintf(fid, '%14.5e%14.5e\n', single_voxel_sep);
            
            fclose(fid);
            

            %%%%% 7.6.3 write one CONTROL file per voxel %%%%%

            voxel_control_out = sprintf('%s/%s_x%02d_y%02d_z%02d.control', out_dir, pat_name, x, y, z);
            control_fid = fopen(voxel_control_out,'w+');
            
            %write some control file info
            fprintf(control_fid, ' $LCMODL\n');
            fprintf(control_fid, ' OWNER=''MR Exzellenzzentrum, Radiodiagnostik, MUW''\n');
            fprintf(control_fid, ' Title=''%s_x%02d_y%02d_z%02d''\n', pat_name, x, y, z);
            fprintf(control_fid, ' HZPPPM=%d, DELTAT=%d, NUNFIL=%i\n',water_frequency/1000000, dwelltime/1000000000, vecSize);
	        fprintf(control_fid, ' FILBAS=''%s''\n', basis_file);	
            fprintf(control_fid, ' DOREFS(1) = T\n');
            fprintf(control_fid, ' DOREFS(2) = F\n');
            if(subbas_flag)  
                fprintf(control_fid, ' SUBBAS = T\n');                          %Subtracts the baseline from the result
            end
            fprintf(control_fid, ' PPMST = 3.8\n');
            fprintf(control_fid, ' PPMEND = 1.8\n');                              
            fprintf(control_fid, ' DEGPPM = %2.1f\n',first_order_phase);        %1st order phase prior knowledge 
            fprintf(control_fid, ' SDDEGP = %2.1f\n',sddegp);                   %standard deviation of DEGPPM

%%%%% if 2 metabolites have circle freq w1, w2 and a phase 0. order of ph0 and they are measured with acquisition delay t
%%%%% then their phases in rad are:
%%%%% phw1(t) = ph0 + w1*t
%%%%% phw2(t) = ph0 + w2*t
%%%%% so their phase difference is deltaPH = (w2-w1)*t
%%%%% the acq delay is then t = delta_ph/(w2-w1) in seconds, converted to degree/ppm it is 
%%%%% t [s] ?????????? = delta_ph/(w2-w1) = delta_ph/((f2-f1)*2pi) = delta_ph/(ppm_difference*297.223*10^6*2pi); 
%%%%% so assuming ppm_difference = 2ppm and a delta_ph=0.05236rad  equal to 3deg --> SDDEGP = 0.05236 rad/ppm equal to 3 deg/ppm
%%%%% this leads to an acq delay of: t ~ 0.014 ms; 
%%%%% so such an deviation (because of wrong basis file or technical inaccuracy) can be compensated
%%%%% The maximum acquisition delay between the phase/mag images and the CSI/basis is 0.03333ms, so that should be ??? enough.

            fprintf(control_fid, ' WDLINE(6) = 0\n');
            fprintf(control_fid, ' nomit = 2\n');
            fprintf(control_fid, ' chomit(1) = ''lipmm1''\n');
            fprintf(control_fid, ' chomit(2) = ''mm2''\n');
            fprintf(control_fid, ' NEACH = 99\n');                          % all the individual metabolites get written to the .ps files, not just the sum.
            
            % the data is already phased, so LCM should not phase it; in that case zero_order_phase_sd is 0.
            fprintf(control_fid, ' DEGZER = %2.1f\n',zero_order_phase);     %0. order PPK
            fprintf(control_fid, ' SDDEGZ = %2.1f\n',sddegz);  %standard deviation (degree of freedom) to vary DEGZER
            
            fprintf(control_fid, ' LTABLE = 7, LCSV = 11\n');
            fprintf(control_fid, ' FILCSV=''%s/%s_x%02d_y%02d_z%02d.CSV''\n',out_dir, pat_name, x, y, z);
            fprintf(control_fid, ' FILRAW=''%s/%s_x%02d_y%02d_z%02d.RAW''\n',out_dir, pat_name, x, y, z);
            fprintf(control_fid, ' FILPS=''%s/%s_x%02d_y%02d_z%02d.ps''\n',out_dir, pat_name, x, y, z);
            fprintf(control_fid, ' FILTAB=''%s/%s_x%02d_y%02d_z%02d.table''\n',out_dir, pat_name, x, y, z);
            fprintf(control_fid, ' $END\n');
            
            fclose(control_fid);
            
            
            %%%%% 7.6.3 write commands to 7 LCModel batch files - split work in 7 CPUs %%%%% 

            switch mod(no_vox,7)
                case 0
                    fprintf(batch_fid_1, ' /bilbo/home/mach/.lcmodel/bin/lcmodel < %s \n', voxel_control_out);                   
                case 1
                    fprintf(batch_fid_2, ' /bilbo/home/mach/.lcmodel/bin/lcmodel < %s \n', voxel_control_out);
                case 2
                    fprintf(batch_fid_3, ' /bilbo/home/mach/.lcmodel/bin/lcmodel < %s \n', voxel_control_out);
                case 3
                    fprintf(batch_fid_4, ' /bilbo/home/mach/.lcmodel/bin/lcmodel < %s \n', voxel_control_out);    
                case 4
                    fprintf(batch_fid_5, ' /bilbo/home/mach/.lcmodel/bin/lcmodel < %s \n', voxel_control_out);    
                case 5
                    fprintf(batch_fid_6, ' /bilbo/home/mach/.lcmodel/bin/lcmodel < %s \n', voxel_control_out);    
                case 6
                    fprintf(batch_fid_7, ' /bilbo/home/mach/.lcmodel/bin/lcmodel < %s \n', voxel_control_out);     
            end
            
            no_vox = no_vox+1;
        end
    end
end

fclose(batch_fid_1);
fclose(batch_fid_2);
fclose(batch_fid_3);
fclose(batch_fid_4);
fclose(batch_fid_5);
fclose(batch_fid_6);
fclose(batch_fid_7);