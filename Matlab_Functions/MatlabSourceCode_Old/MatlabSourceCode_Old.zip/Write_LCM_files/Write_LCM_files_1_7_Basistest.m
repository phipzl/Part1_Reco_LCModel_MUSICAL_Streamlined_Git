function Write_LCM_files_1_7_Basistest(out_dir,basis_file,water_frequency,dwelltime,LCM_ProgramPath)
%
% 


%% 7.6.0 Definitions, Preparations, Initialization


% InArray:              Complex array with time domain data, e.g. [64x64x1x2048] CSI Matrix
% VarNames:             Names of the dimensions of InArray, e.g. {'ROW','COL','SLC','vecSize'}
% mask:                 Only write files for voxels with 1 in mask; If all should be processed: mask = ones(...) (same size as InArray but no vecSize dim)
% out_dir:              Path to where all files should be written
% basis_file:           Path of basis file with which LCModel should fit the spectra
% pat_name:             Name of Patient
% water_frequency:      Frequency where the scanner detected the water-resonance
% dwelltime:            Time interval between two consecutive FID-points
% zero_order_phase:     Prior Knowledge about the zero order phase of the spectra
% sddegz:               (StandardDeviationDegreeZero: StandardDeviation controlling how much LCModel is allowed to deviate from zero_order_phase
% first_order_phase:    Prior Knowledge about the first order phase of the spectra
% sddegp:               Same as sddegz, but for first_order_phase
% subbas_flag:          flag controlling whether the baseline should be subtracted in the .PS files of LCM
% use_phantom_flag:     If data is from a phantom, some parameters can be different (e.g. phantoms have different metabolites)
% LCM_ProgramPath:      Path of the lcmodel file, e.g. SOME_PATH/.lcmodel/bin/lcmodel



% The function can only handle Input Array with 6 dimensions. Quit function if input is larger.


% Find out in which dimension the FID-time-datapoints is saved in InArray. Find out the number of time-datapoints.
vecSize = 32768;


mkdir(out_dir);


batch_fid_1 = fopen(sprintf('%s/lcm_process_core_1.sh',out_dir),'w+');


            

%% 7.6.1 Loop over all entries of the InArray except vecSize entry

   
% Create the names for control files, e.g. ROW1_COL3 to get the right names for the output_files
Filename = 'BasisTest';





%% 7.6.2 write one CONTROL file per voxel %%%%%


voxel_control_out = sprintf('%s/%s.control', out_dir, Filename);
control_fid = fopen(voxel_control_out,'w+');

% General Info, Water Frequency, Dwelltime, ...
fprintf(control_fid, ' $LCMODL\n');
%fprintf(control_fid, ' OWNER=''MR Exzellenzzentrum, Radiodiagnostik, MUW''\n');
%fprintf(control_fid, ' Title=''%s''\n', Filename);
fprintf(control_fid, ' HZPPPM=%d, DELTAT=%d, NUNFIL=%i\n',water_frequency/1000000, dwelltime/1000000000, vecSize);
fprintf(control_fid, ' FILBAS=''%s''\n', basis_file);

fprintf(control_fid,' BASCAL=T\n');    
fprintf(control_fid,' CHBCAL=''GPC''\n');        
fprintf(control_fid,' NCALIB=1\n');            
fprintf(control_fid,' CHCALI(1)=''PCh''\n');            
fprintf(control_fid,' PPMST=3.45\n');   




%fprintf(control_fid, ' NEACH = 99\n');                              % "the number of metabolites for which individual plots are to be made." (LCM Manual p. 118)
% Zero order phase
fprintf(control_fid, ' FILPS=''%s/%s.ps''\n',out_dir, Filename);
fprintf(control_fid, ' $END\n');

fclose(control_fid);



%% 7.6.3 write commands to 7 batch files - split work to 7 CPUs %%%%% 


fprintf(batch_fid_1, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);                   


            

fclose(batch_fid_1);
