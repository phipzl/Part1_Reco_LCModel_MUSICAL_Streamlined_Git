function Write_LCM_files_1_7(InArray,DimNames,mask,out_dir,basis_file,pat_name,water_frequency,dwelltime,zero_order_phase,sddegz,first_order_phase,sddegp,subbas_flag,use_phantom_flag,LCM_ProgramPath,ppm_range)
%
% 


%% 7.6.0 Definitions, Preparations, Initialization


% InArray:              Complex array with time domain data, e.g. [64x64x1x2048] CSI Matrix
% VarNames:             Names of the dimensions of InArray, e.g. {'ROW','COL','SLC','vecSize'}
% mask:                 Only write files for voxels with 1 in mask; If all should be processed: mask = ones(...) (same size as InArray but no vecSize dim)
% out_dir:              Path to where all files should be written
% basis_file:           Path of basis file with which LCModel should fit the spectra
% pat_name:             Name of Patient
% water_frequency:      Frequency where the scanner detected the water-resonance
% dwelltime:            Time interval between two consecutive FID-points
% zero_order_phase:     Prior Knowledge about the zero order phase of the spectra
% sddegz:               (StandardDeviationDegreeZero: StandardDeviation controlling how much LCModel is allowed to deviate from zero_order_phase
% first_order_phase:    Prior Knowledge about the first order phase of the spectra
% sddegp:               Same as sddegz, but for first_order_phase
% subbas_flag:          flag controlling whether the baseline should be subtracted in the .PS files of LCM
% use_phantom_flag:     If data is from a phantom, some parameters can be different (e.g. phantoms have different metabolites)
% LCM_ProgramPath:      Path of the lcmodel file, e.g. SOME_PATH/.lcmodel/bin/lcmodel



% The function can only handle Input Array with 6 dimensions. Quit function if input is larger.
DimNumber_Input = numel(size(InArray));
if(DimNumber_Input > 6)
    display('Input Array too large. Rewrite function ''Write_LCM_files_x_y'' or shrink Input Array. char(10) Program quitted without output.')
    return
end


% Find out in which dimension the FID-time-datapoints is saved in InArray. Find out the number of time-datapoints.
vecSize_dim = find(max(size(InArray)) == size(InArray));
vecSize = size(InArray,vecSize_dim);

% Create an array with the dimensions of InArray over which will be looped are saved. (e.g. for [size(InArray) = [32 32 1 1024] this dimensions would be [1 2 3 5 6]
% The dimensions 5 and 6 will be ignored because size(InArray,5) = 1 = size(InArray,6) with the above InArray)
ArrayDimIndices = 1:6;
ArrayDimIndices(vecSize_dim) = [];

InArray_AccessStr = cell([1 6]);
InArray_AccessStr(ArrayDimIndices) = {'VarInd1','VarInd2','VarInd3','VarInd4','VarInd5'};
InArray_AccessStr{vecSize_dim} = ':';

for CommaLoop = 1:5
    InArray_AccessStr{CommaLoop} = [InArray_AccessStr{CommaLoop} ','];
end
InArray_AccessStr = cell2mat(InArray_AccessStr);

mkdir(out_dir);
mkdir([out_dir '/CoordFiles']);

% creating one batch file PER CPU core for LCmodel processing
batch_fid_1 = fopen('./tmp/lcm_process_core_1.sh','a');
batch_fid_2 = fopen('./tmp/lcm_process_core_2.sh','a');
batch_fid_3 = fopen('./tmp/lcm_process_core_3.sh','a');
batch_fid_4 = fopen('./tmp/lcm_process_core_4.sh','a');
batch_fid_5 = fopen('./tmp/lcm_process_core_5.sh','a');
batch_fid_6 = fopen('./tmp/lcm_process_core_6.sh','a');
batch_fid_7 = fopen('./tmp/lcm_process_core_7.sh','a');
batch_fid_8 = fopen('./tmp/lcm_process_core_8.sh','a');
% batch_fid_9 = fopen('./tmp/lcm_process_core_9.sh','a');
% batch_fid_10 = fopen('./tmp/lcm_process_core_10.sh','a');
% batch_fid_11 = fopen('./tmp/lcm_process_core_11.sh','a');
% batch_fid_12 = fopen('./tmp/lcm_process_core_12.sh','a');
% batch_fid_13 = fopen('./tmp/lcm_process_core_13.sh','a');
% batch_fid_14 = fopen('./tmp/lcm_process_core_14.sh','a');




% batch_fid_1 = fopen('/sacher/melange/raid/bstrasser/PROCESS/Sourcecode/Multichannel_Combination/Step_2_Implementation_of_CC_Algorithm/Multichannel_Combination_1.6/tmp/lcm_process_core_1.sh','a');
% batch_fid_2 = fopen('/sacher/melange/raid/bstrasser/PROCESS/Sourcecode/Multichannel_Combination/Step_2_Implementation_of_CC_Algorithm/Multichannel_Combination_1.6/tmp/lcm_process_core_2.sh','a');
% batch_fid_3 = fopen('/sacher/melange/raid/bstrasser/PROCESS/Sourcecode/Multichannel_Combination/Step_2_Implementation_of_CC_Algorithm/Multichannel_Combination_1.6/tmp/lcm_process_core_3.sh','a');
% batch_fid_4 = fopen('/sacher/melange/raid/bstrasser/PROCESS/Sourcecode/Multichannel_Combination/Step_2_Implementation_of_CC_Algorithm/Multichannel_Combination_1.6/tmp/lcm_process_core_4.sh','a');
% batch_fid_5 = fopen('/sacher/melange/raid/bstrasser/PROCESS/Sourcecode/Multichannel_Combination/Step_2_Implementation_of_CC_Algorithm/Multichannel_Combination_1.6/tmp/lcm_process_core_5.sh','a');
% batch_fid_6 = fopen('/sacher/melange/raid/bstrasser/PROCESS/Sourcecode/Multichannel_Combination/Step_2_Implementation_of_CC_Algorithm/Multichannel_Combination_1.6/tmp/lcm_process_core_6.sh','a');
% batch_fid_7 = fopen('/sacher/melange/raid/bstrasser/PROCESS/Sourcecode/Multichannel_Combination/Step_2_Implementation_of_CC_Algorithm/Multichannel_Combination_1.6/tmp/lcm_process_core_7.sh','a');



            
no_vox=0;

%% 7.6.1 Loop over all entries of the InArray except vecSize entry
for VarInd1 = 1:size(InArray,ArrayDimIndices(1))
    for VarInd2 = 1:size(InArray,ArrayDimIndices(2))
        for VarInd3 = 1:size(InArray,ArrayDimIndices(3))
            for VarInd4 = 1:size(InArray,ArrayDimIndices(4))
                for VarInd5 = 1:size(InArray,ArrayDimIndices(5))
                       
          %  create files only for voxels inside mask
            if ( mask(VarInd1,VarInd2,VarInd3,VarInd4,VarInd5) == 0 )
                continue
            end
            single_voxel = eval([ 'squeeze(InArray(' InArray_AccessStr '));' ]);
            
            % Create the names for control files, e.g. ROW1_COL3 to get the right names for the output_files
            Filename = pat_name;
            
            VarInd1leadingzero = sprintf('%02d', VarInd1);
            VarInd2leadingzero = sprintf('%02d', VarInd2);            
            VarInd3leadingzero = sprintf('%02d', VarInd3);           
            VarInd4leadingzero = sprintf('%02d', VarInd4);           
            VarInd5leadingzero = sprintf('%02d', VarInd5);            
            
            for DimNamesIndex = 1:numel(DimNames)
                
                Filename = [ Filename '_' DimNames{DimNamesIndex} num2str(eval([ 'VarInd' num2str(DimNamesIndex) 'leadingzero' ])) ];
            end

            
            %% 7.6.1 write one RAW file per voxel %%%%%
            
            
            voxel_raw_out = sprintf('%s/%s.RAW', out_dir, Filename);
            fid = fopen(voxel_raw_out,'w+');
            
            %write some header info
            fprintf(fid, ' $SEQPAR\n');
            fprintf(fid, ' hzpppm=%d\n',water_frequency/1000000);
            fprintf(fid, ' $END\n');
            fprintf(fid, ' $NMID\n');
            fprintf(fid, ' fmtdat=''(2e14.5)''\n');
            fprintf(fid, ' $END\n');
            
            %write data into file
            single_voxel = reshape(single_voxel,[vecSize 1]);
            single_voxel_sep=[real(single_voxel)'; imag(single_voxel)'];
            fprintf(fid, '%14.5e%14.5e\n', single_voxel_sep);
            
            fclose(fid);
            
            
%             % DEBUG MODE
%             size(single_voxel)
%             size(single_voxel_sep)
%             figure; plot(1:2048,real(single_voxel), 'b', 1:2048, imag(single_voxel), 'g'); waitforbuttonpress
%             % DEBUG MODE END
            
            
            %% 7.6.2 write one CONTROL file per voxel %%%%%


            voxel_control_out = sprintf('%s/%s.control', out_dir, Filename);
            control_fid = fopen(voxel_control_out,'w+');
            
            % General Info, Water Frequency, Dwelltime, ...
            fprintf(control_fid, ' $LCMODL\n');
            fprintf(control_fid, ' OWNER=''MR Exzellenzzentrum, Radiodiagnostik, MUW''\n');
            fprintf(control_fid, ' Title=''%s''\n', Filename);
            fprintf(control_fid, ' HZPPPM=%d, DELTAT=%d, NUNFIL=%i\n',water_frequency/1000000, dwelltime/1000000000, vecSize);
            
            % If for each slice a different basis-file was provided, use all these. Otherwise use only the one and only basis_file{1}
            if(numel(basis_file) == size(InArray,ArrayDimIndices(3)))
                fprintf(control_fid, ' FILBAS=''%s''\n', basis_file{VarInd3});
            else
                fprintf(control_fid, ' FILBAS=''%s''\n', basis_file{1});                
            end
            
            
            % Don't Simulate Basis-spectra
	        fprintf(control_fid, ' NSIMUL = 0\n'); 
            
            
            % Referencing, see LCModel Manual page 105
            if(use_phantom_flag)
                fprintf(control_fid, ' DOREFS(1) = F\n');                       % DOREFS(1): Reference to water T(rue) or F(alse)
                fprintf(control_fid, ' DOREFS(2) = T\n');                       % DOREFS(JCCF), JCCF natural number: Other References you can adjust with the following options
                fprintf(control_fid, ' NREFPK(2) = 1\n');                       % NREFPK(JCCF): number of delta functions used for Reference JCCF, e.g. 1 delta function for NAA at 2.01; Each delta function is numbered by JREF 
                fprintf(control_fid, ' PPMREF(2,1) = 2.01\n');                  % PPMREF(JREF,JCCF): What chemical shift should the delta function with number JREF for the Reference with number JCCF have?
                %fprintf(control_fid, ' SHIFMN(2) = 0.1\n');                    % SHIFMN(JCCF): Minimum chemshift to search for peak. LCModel searches from PPMREF(2,1) + SHIFMN(2) to PPMREF(2,1) + SHIFMX(2)
                fprintf(control_fid, ' SHIFMX(2) = 0.1\n');                     % SHIFMN should be negative.     
            else
                fprintf(control_fid, ' DOREFS(1) = T\n');                       % Use standard water referencing
                fprintf(control_fid, ' DOREFS(2) = F\n');                       % No Other metabolites used for referencing
            end
            
            % Water-Scaling
            fprintf(control_fid, ' WSMET = ''DSS''\n');                         % This tells LCModel what to use for scaling the absolute fitting concentrations.          
            fprintf(control_fid, ' WSPPM = 0.0\n');                             % The chemical shift of WSMET                                           
            fprintf(control_fid, ' N1HMET = 9\n');                              % The number of protons contributing to the signal
            

            % Subtract Baseline in plot
            if(subbas_flag)  
                fprintf(control_fid, ' SUBBAS = T\n');                          %Subtracts the baseline from the result
            end
            
            % Chemical Shift range to be processed
            fprintf(control_fid, ' PPMST = %2.1f\n',max(ppm_range));                             % Fit data in chemical shift region [PPMEND, PPMST], PPMST > PPMEND
            fprintf(control_fid, ' PPMEND = %2.1f\n',min(ppm_range));   
            
            % First order phase
            fprintf(control_fid, ' DEGPPM = %2.1f\n',first_order_phase);        %1st order phase prior knowledge, set to zero for no prior knowledge
            fprintf(control_fid, ' SDDEGP = %2.1f\n',sddegp);                   %standard deviation of DEGPPM; note that LCM varies the phase a lot: E.g. for sddegp=1 a total 1.order_phase > 15 is not rare!

%%%%% FIRST ORDER PHASE:
%%%%% if 2 metabolites have circle freq w1, w2 and a phase 0. order of ph0 and they are measured with acquisition delay t
%%%%% then their phases in rad are:
%%%%% phw1(t) = ph0 + w1*t
%%%%% phw2(t) = ph0 + w2*t
%%%%% so their phase difference is delta_ph[rad] = (w2-w1)*t
%%%%% the acq delay is then t = delta_ph[rad]/(w2-w1) in seconds, converted to degree/ppm it is 
%%%%% t [s] = delta_ph[rad]/(w2-w1) = delta_ph[rad]/((f2-f1)*2pi) = delta_ph[rad]/(ppm_difference*297.223*10^6*2pi);  (297.223 @ 7T !)
%%%%% so assuming ppm_difference = 2ppm and a delta_ph[rad]=0.05236rad  equal to 3deg --> 1stOrderPhase = 0.0262 rad/ppm equal to 1.5 deg/ppm
%%%%% this leads to an acq delay of: t ~ 0.014 ms; 
%%%%% so such an deviation (because of wrong basis file or technical inaccuracy) can be compensated


            fprintf(control_fid, ' WDLINE(6) = 0\n');                           % See LCM Manual page 119
            
            
            % Omit metabolites of the basis set or tell LCModel NOT to omit metabos.
            if(use_phantom_flag)
                fprintf(control_fid, ' nomit = 22\n');                           % Number of omitted components of the basis set
                %fprintf(control_fid, ' chomit(1) = ''lipmm1''\n');              % Don't try to fit the metabolite lipmm1 that is included in the basis set; NOT INCLUDED ANYMORE
                %fprintf(control_fid, ' chomit(2) = ''mm2''\n');                 % etc.
                fprintf(control_fid, ' chomit(1) = ''Ala''\n');
                fprintf(control_fid, ' chomit(2) = ''Glc''\n');
                fprintf(control_fid, ' chomit(3) = ''Asp''\n');
                fprintf(control_fid, ' chomit(4) = ''Glc_B''\n');
                fprintf(control_fid, ' chomit(5) = ''Cho''\n');
                %fprintf(control_fid, ' chomit(6) = ''Cr''\n');                
                fprintf(control_fid, ' chomit(7) = ''GABA''\n');
                fprintf(control_fid, ' chomit(8) = ''GPC''\n');
                fprintf(control_fid, ' chomit(9) = ''GSH''\n');               
                fprintf(control_fid, ' chomit(10) = ''Gln''\n');
                fprintf(control_fid, ' chomit(11) = ''Ins''\n');
                fprintf(control_fid, ' chomit(12) = ''NAA''\n');               
                fprintf(control_fid, ' chomit(13) = ''NAAG''\n');
                fprintf(control_fid, ' chomit(14) = ''PCh''\n');
                %fprintf(control_fid, ' chomit(15) = ''PCr''\n');               
                fprintf(control_fid, ' chomit(16) = ''Scyllo''\n');
                fprintf(control_fid, ' chomit(17) = ''Tau''\n');
                fprintf(control_fid, ' chomit(18) = ''Glu''\n');                   
                fprintf(control_fid, ' chomit(19) = ''Lip_c''\n');
                fprintf(control_fid, ' chomit(21) = ''mm3''\n');
                fprintf(control_fid, ' chomit(22) = ''mm4''\n'); 
                fprintf(control_fid, ' chomit(22) = ''Lac''\n');                
                fprintf(control_fid, ' chomit(22) = ''Act''\n');
                
                fprintf(control_fid, ' NUSE1=2\n');                 % Only use Act and Lac
                fprintf(control_fid, ' CHUSE1(1)=''Cr''\n');
                fprintf(control_fid, ' CHUSE1(2)=''PCr''\n');  
                
            else
                fprintf(control_fid, ' nomit = 5\n'); 
                %fprintf(control_fid, ' chomit(1) = ''lipmm1''\n');                 % REVERT ME BACK
                %fprintf(control_fid, ' chomit(2) = ''mm2''\n');
                fprintf(control_fid, ' chomit(1) = ''Cho''\n'); 
                fprintf(control_fid, ' chomit(2) = ''Act''\n');
                fprintf(control_fid, ' chomit(3) = ''mm3''\n'); 
                fprintf(control_fid, ' chomit(4) = ''mm4''\n');
                fprintf(control_fid, ' chomit(5) = ''Glc_B''\n');                
            end
            fprintf(control_fid, ' NKEEP = 1\n');                       % Keep Lactate in the Analysis, even though PPMEND > 1.41 (LCM Manual ver. 6.3-1, p. 118).
            fprintf(control_fid, ' CHKEEP(1) = ''Lac''\n');              
            
            
            
            fprintf(control_fid, ' NEACH = 99\n');                              % "the number of metabolites for which individual plots are to be made." (LCM Manual p. 118)

            
            % Zero order phase
            fprintf(control_fid, ' DEGZER = %2.1f\n',zero_order_phase);         % zero order phase prior knowledge, set to zero for no prior knowledge
            fprintf(control_fid, ' SDDEGZ = %2.1f\n',sddegz);                   %standard deviation (degree of freedom) to vary DEGZER
            
            fprintf(control_fid, ' LTABLE = 7, LCSV = 0, LCOORD = 9\n');      % , LCOORD = 9    Create table and COORD file, but no CSV file. Create files to following paths:
            %fprintf(control_fid, ' FILCSV=''%s/%s.CSV''\n',out_dir, Filename);
            fprintf(control_fid, ' FILRAW=''%s/%s.RAW''\n',out_dir, Filename);
            fprintf(control_fid, ' FILPS=''%s/%s.ps''\n',out_dir, Filename);
            fprintf(control_fid, ' FILTAB=''%s/%s.table''\n',out_dir, Filename);
            fprintf(control_fid, ' FILCOO=''%s/CoordFiles/%s.coord''\n', out_dir, Filename);            
            fprintf(control_fid, ' $END\n');
            
            fclose(control_fid);
            
            
            
            %% 7.6.3 write commands to 7 batch files - split work to 7 CPUs %%%%% 

            switch mod(no_vox,8)
                case 0
                    fprintf(batch_fid_1, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);                   
                case 1
                    fprintf(batch_fid_2, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);
                case 2
                    fprintf(batch_fid_3, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);
                case 3
                    fprintf(batch_fid_4, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);    
                case 4
                    fprintf(batch_fid_5, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);    
                case 5
                    fprintf(batch_fid_6, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);    
                case 6
                    fprintf(batch_fid_7, ' %s < %s \n', LCM_ProgramPath, voxel_control_out); 
                case 7
                    fprintf(batch_fid_8, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);                   
%                 case 8
%                     fprintf(batch_fid_9, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);
%                 case 9
%                     fprintf(batch_fid_10, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);
%                 case 10
%                     fprintf(batch_fid_11, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);    
%                 case 11
%                     fprintf(batch_fid_12, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);    
%                 case 12
%                     fprintf(batch_fid_13, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);    
%                 case 13
%                     fprintf(batch_fid_14, ' %s < %s \n', LCM_ProgramPath, voxel_control_out);                     
                    
                    
                    
                    
            end
            
            no_vox = no_vox+1;
            
                end  % VarInd5
            end      % VarInd4
        end          % VarInd3
    end              % VarInd2
end                  % VarInd1

fclose(batch_fid_1);
fclose(batch_fid_2);
fclose(batch_fid_3);
fclose(batch_fid_4);
fclose(batch_fid_5);
fclose(batch_fid_6);
fclose(batch_fid_8);
% fclose(batch_fid_9);
% fclose(batch_fid_10);
% fclose(batch_fid_11);
% fclose(batch_fid_12);
% fclose(batch_fid_13);
% fclose(batch_fid_14);







