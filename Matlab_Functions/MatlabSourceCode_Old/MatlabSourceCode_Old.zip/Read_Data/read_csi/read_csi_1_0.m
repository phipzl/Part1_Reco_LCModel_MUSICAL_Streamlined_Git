function [csi_mat_complex, csi_mat_complex_kspace] = read_csi_1_0(csi_file,zerofilling_fact, x_shift,y_shift,total_channel_no,ROW,COL,SLC,vecSize)
%% 1. Decide whether input file is DICOM or DAT; Call then appropriate function


if(numel(strfind(csi_file, '.dat')) > 0)
    
    [csi_mat_complex,csi_mat_complex_kspace] = read_csi_dat_1_3(csi_file, zerofilling_fact, x_shift,y_shift);
    
else
    
    [csi_mat_complex, csi_mat_complex_kspace] = read_csi_dicom_1_0(csi_file,total_channel_no,ROW,COL,SLC,vecSize);
    
end



