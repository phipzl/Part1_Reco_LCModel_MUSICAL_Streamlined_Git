function [csi_mat_complex_dat, csi_mat_complex_dat_k] = read_csi_dat_1_2(csi_dat_file, zerofilling_fact, x_shift,y_shift)
%% 0. Preparations

if(~exist('zerofilling_fact','var'))
    zerofilling_fact = 1;
end



[ROW,COL,SLC,vecSize,total_channel_no,total_k_points,headersize] = read_csi_dat_header_1_0(csi_dat_file);



% % READ HEADERSIZE
% headersize = fread(raw_csi_fid,1, 'uint32');
% 
% 
% % READ VECSIZE, TOTAL CHANNELS FROM FIRST DATA-HEADER
% fseek(raw_csi_fid,headersize,'bof'); 
% chak_header = fread(raw_csi_fid, 64, 'uint16');
% vecSize = chak_header(15);
% total_channel_no = chak_header(16);
% 
% 
% % READ TOTAL k-points AND NUMBER OF SLICES FROM END OF FILE
% fseek(raw_csi_fid, -256,'eof');
% chak_header = fread(raw_csi_fid, 23, 'uint16');
% total_k_points = chak_header(5)-1;
% if(chak_header(23) > 0)
%     SLC = chak_header(23);
% else
%     SLC = 1;
% end
% 
% 
% % READ MATRIX SIZE (ROW AND COLUMN NUMBERS) FROM MAXIMUM K-POINT
% fseek(raw_csi_fid,headersize,'bof');
% ROW = 1;
% COL = 1;
% for i = 1:total_k_points
% 
%         chak_header = fread(raw_csi_fid, 64, 'uint16');
%         if(chak_header(17) > ROW)
%             ROW = chak_header(17);
%         end
%         if(chak_header(22) > COL)
%             COL = chak_header(22);
%         end
%         fseek(raw_csi_fid,vecSize*2*4*total_channel_no + (total_channel_no-1)*128,'cof');
% 
% end
% 
% ROW = ROW + 1;
% COL = COL + 1;



%% 1. READ DATA

raw_csi_fid = fopen(sprintf('%s', csi_dat_file),'r');
fseek(raw_csi_fid, headersize,'bof');                                                               
                                                                                                   
                                                                                                    
csi_mat_complex_dat_kspace = zeros(total_channel_no,ROW,COL,SLC,vecSize);

for k_point = 1:total_k_points %total_k_points
    for channel_no = 1:total_channel_no

        chak_header = fread(raw_csi_fid, 64, 'int16');
        k_z = 1;                            %k_z = channel_k_header(??);
        k_x = ROW - chak_header(17) + 1;     %THIS FLIPS LEFT AND RIGHT IN SPATIAL DOMAIN BECAUSE PHYSICIANS WANT TO SEE IMAGES FLIPPED
        k_y = chak_header(22) + 1;
        if(chak_header(23)>0)
            Hadamard_index = chak_header(23);   % SAYS WHICH REPETITION FOR HADAMARD ENCODING OF THE SAME K-POINT IS MEASURED
        else
            Hadamard_index = 1;
        end
        chak_data = fread(raw_csi_fid, vecSize*2, 'float32');
        csi_real = chak_data(1:2:end);
        csi_imag = chak_data(2:2:end);
        csi_complex = complex(csi_real,csi_imag); 
        csi_mat_complex_dat_kspace(channel_no,k_x,k_y,Hadamard_index,:) = csi_complex;
        
    end
end

fclose(raw_csi_fid);

csi_mat_complex_dat_k = csi_mat_complex_dat_kspace;

%% 2. ZERO FILL IN SPATIAL DIMENSIONS, FFT


% % DEBUG MODE
% total_channel_no = 4;
% 
% xxx = real(repmat(exp(1i*x_shift*2*pi/ROW*(1:ROW)),[total_channel_no,1,COL,SLC,vecSize]));
% size(exp(1i*x_shift*2*pi/ROW*(1:ROW)))
% size(repmat(exp(1i*x_shift*2*pi/ROW*(1:ROW)),[total_channel_no,1,COL,SLC,vecSize]))
% size(reshape(repmat(exp(1i*x_shift*2*pi/ROW*(1:ROW)),[total_channel_no,1,COL,SLC,vecSize]), [total_channel_no,ROW,COL,SLC,vecSize]))
% squeeze(xxx(1:4,50:54,1,1,1))
% squeeze(xxx(1,4:8,30:34,1,1))
% squeeze(xxx(1:4,50:54,1,1,2))
% squeeze(xxx(1,4:8,30:34,1,2))
% 
% xxx = real(repmat(reshape(exp(1i*y_shift*2*pi/COL*(1:COL)), [1,1,COL,SLC,1]),[total_channel_no,ROW,1,SLC,vecSize]));
% size(reshape(exp(1i*y_shift*2*pi/COL*(1:COL)), [1,1,COL,SLC,1]))
% size(repmat(reshape(exp(1i*y_shift*2*pi/COL*(1:COL)), [1,1,COL,SLC,1]),[total_channel_no,ROW,1,SLC,vecSize]))
% size(reshape(repmat(reshape(exp(1i*y_shift*2*pi/COL*(1:COL)), [1,1,COL,SLC,1]),[total_channel_no,ROW,1,SLC,vecSize]), [total_channel_no,ROW,COL,SLC,vecSize]))
% squeeze(xxx(1:4,1,50:54,1,1))
% squeeze(xxx(1,4:8,30:34,1,1))
% squeeze(xxx(1:4,1,50:54,1,2))
% squeeze(xxx(1,4:8,30:34,1,2))
% % DEBUG MODE END



% 2.2 ZERO FILLING IN kSPACE

if(ne(zerofilling_fact,1))
    csi_mat_complex_dat_kspace_zerofilled = zeros(total_channel_no,ROW*zerofilling_fact, COL*zerofilling_fact,SLC,vecSize);
    csi_mat_complex_dat_kspace_zerofilled(:,ROW*zerofilling_fact/4+1:ROW*zerofilling_fact*3/4,COL*zerofilling_fact/4+1:COL*zerofilling_fact*3/4,:,:) = csi_mat_complex_dat_kspace;
    clear csi_mat_complex_dat_kspace
    csi_mat_complex_dat_kspace = csi_mat_complex_dat_kspace_zerofilled;
    clear csi_mat_complex_dat_kspace_zerofilled;
end

% 2.3 FFT FROM K_SPACE TO DIRECT SPACE
csi_mat_complex_dat = ifftshift(ifftshift(csi_mat_complex_dat_kspace,2),3);
clear csi_mat_complex_dat_kspace;
csi_mat_complex_dat = fft(fft(csi_mat_complex_dat,ROW*zerofilling_fact,2),COL*zerofilling_fact,3);
csi_mat_complex_dat = conj(csi_mat_complex_dat);                                                    % the chem shift gets higher von right to left --> conj reverses that
csi_mat_complex_dat = fftshift(fftshift(csi_mat_complex_dat,2),3);


% 2.1 shift right and then up
if(ne(x_shift,0) && exist('x_shift','var'))
    csi_mat_complex_dat = circshift(csi_mat_complex_dat, [0 x_shift 0 0 0]);
end

if(ne(y_shift,0) && exist('y_shift','var'))
    csi_mat_complex_dat = circshift(csi_mat_complex_dat, [0 0 y_shift 0 0]);
end

