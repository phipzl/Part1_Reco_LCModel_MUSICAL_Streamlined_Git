function [csi,csi_kspace] = read_csi_dat_1_9(csi_path, zerofill_to_nextpow2_flag, zerofilling_fact, Hadamard_flag, x_shift,y_shift)

% read_csi_dat_x_x Read in csi-data from Siemens raw file format
% This function was written by Bernhard Strasser, July 2012.
% The function can read in MRS(I) data in the Siemens raw file format ".DAT" 
% and perform some easy corrections like zerofilling, Hadamard decoding, etc.
%
%
% [csi,csi_kspace] = read_csi_dat_1_9(csi_path, zerofill_to_nextpow2_flag, zerofilling_fact, x_shift,y_shift)
%
% Input: 
% -         csi_path                    ...     Path of spectroscopy (imaging) file.
% -         zerofill_to_nextpow2_flag   ...     Flag, if the MRSI data should be zerofilled to the next power of 2 in k-space (e.g. 42x42 sampled --> zf to 64x64?)
% -         zerofilling_fact            ...     Factor with which the MRSI data should be zerofilled in k-space for interpolation (e.g. zerofill from 64x64 to 128x128)
% -         Hadamard_flag               ...     If data is multislice hadamard encoded, perform hadamard-decoding function
% -         x_shift                     ...     Shift the MRSI data in the left-right direction ( = row direction of matrix) by x_shift voxels
% -         y_shift                     ...     Shift the MRSI data in anterior-posterior direction ( = column direction of matrix) by y_shift voxels
%
% Output:
% -         csi                         ...     Output data in image domain. In case of Single Voxel Spectroscopy, this is the only output
% -         csi_kspace                  ...     Output data in k-space. In case of SVS this is zero. size: channel x ROW x COL x SLC x vecSize
%
%
% Feel free to change/reuse/copy the function. 
% If you want to create new versions, don't degrade the options of the function, unless you think the kicked out option is totally useless.
% Easier ways to achieve the same result & improvement of the program or the programming style are always welcome!
% File dependancy: read_csi_dat_meas_header_1_2.m, hadamard_encoding_7.m



%% 0. Preparations

% Initialization if some input-variables were omitted.
if(~exist('zerofill_to_nextpow2_flag','var'))
    zerofill_to_nextpow2_flag = 1;
end
if(~exist('zerofilling_fact','var'))
    zerofilling_fact = 1;
end
if(~exist('Hadamard_flag','var'))
    Hadamard_flag = 0;
end
if(~exist('x_shift','var'))
    x_shift = 0;
end
if(~exist('y_shift','var'))
    y_shift = 0;
end


% Read info from mdh
[headersize,total_channel_no,ROW,COL,SLC,vecSize,total_k_points,kline_min,kphase_min] = read_csi_dat_meas_header_1_2(csi_path);
if(zerofill_to_nextpow2_flag)
    ROW = 2^nextpow2(ROW);
    COL = 2^nextpow2(COL);
end


% In case of zerofilling
extra_ROWs = ROW * (zerofilling_fact - 1);              % = (ROW * zerofilling_fact - ROW). Additional ROWs due to zerofilling.
extra_COLs = COL * (zerofilling_fact - 1);              % e.g. 64x64 --> (zf) 128x128: 64 additional COLs, 32 at left, 32 right part of matrix
ROW = ROW * zerofilling_fact;
COL = COL * zerofilling_fact;

kline_min
kphase_min


%% 1. READ DATA

tic

csi_fid = fopen(sprintf('%s', csi_path),'r');
fseek(csi_fid, headersize,'bof');                                                                     
csi_kspace = zeros(total_channel_no,ROW,COL,SLC,vecSize); 

for k_point = 1:total_k_points
    for channel_no = 1:total_channel_no

        chak_header = fread(csi_fid, 64, 'int16');
        if(zerofill_to_nextpow2_flag)
            k_x = chak_header(17) + 1 + extra_ROWs/2;                     
            k_y = chak_header(22) + 1 + extra_COLs/2;                      
        else
            k_x = chak_header(17) + 1 + extra_ROWs/2 - kline_min;          % in case of e.g. 42x42 matrix, the k-space numbers are written as if the matrix were already zerofilled to 64x64
            k_y = chak_header(22) + 1 + extra_COLs/2 - kphase_min;         % i.e. it's starting from 12 ( 12 zeros at beginning + 41 entries + 11 zeros at the end = 64) . Correct for that.
        end
        if(ge(chak_header(19),1))
            k_z = chak_header(19) +1;                                    % SAYS WHICH REPETITION FOR HADAMARD ENCODING OF THE SAME K-POINT IS MEASURED
        else
            k_z = 1;                                                     % some distinction between multislice/hadamard and real 3d-CSI necessary!
        end
        chak_data = fread(csi_fid, vecSize*2, 'float32');
        csi_real = chak_data(1:2:end);
        csi_imag = chak_data(2:2:end);
        csi_kspace(channel_no,k_x,k_y,k_z,:) = complex(csi_real,csi_imag); 
        
    end
end

fclose(csi_fid);

display([ 'Read in took ... ' num2str(toc) ' seconds' ])


%% 2. Correction: In case of e.g. 42x42 matrix the sequence writes wrong k-space-numbers to dat file --> circshift necessary

if(ROW>1 && ~isa(log2(ROW),'integer'))                                                  
    csi_kspace = circshift(csi_kspace, [0 1 1 0 0]);
end



%% 3. FFT FROM K_SPACE TO DIRECT SPACE


if(size(csi_kspace,2) > 1 || size(csi_kspace,3) > 1)                    % In case that MRSI data, not Single Voxel Spectroscopy data is inputted.
    
    tic

    csi = ifftshift(ifftshift(csi_kspace,2),3);
    if(nargout == 1)
        clear csi_kspace;
    end
    csi = ifft(ifft(csi,[],2),[],3);
    csi = conj(csi);                                                    % the chem shift gets higher from right to left --> conj reverses that
    csi = fftshift(fftshift(csi,2),3);
    csi = flipdim(csi,2);                                               % THIS FLIPS LEFT AND RIGHT IN SPATIAL DOMAIN BECAUSE PHYSICIANS WANT TO SEE IMAGES FLIPPED

    display([ 'FFT took     ... ' num2str(toc) ' seconds' ])
    
else
    
    csi = conj(csi_kspace);
    csi_kspace = 0;
    
end



%% 4. Spatial Shift

if(ne(x_shift,0))
    csi = circshift(csi, [0 x_shift 0 0 0]);
end

if(ne(y_shift,0))
    csi = circshift(csi, [0 0 y_shift 0 0]);
end



%% 5. Hadamard Decoding

if(Hadamard_flag == 1 && SLC>1)
    csi = hadamard_encoding_7(csi);
end



