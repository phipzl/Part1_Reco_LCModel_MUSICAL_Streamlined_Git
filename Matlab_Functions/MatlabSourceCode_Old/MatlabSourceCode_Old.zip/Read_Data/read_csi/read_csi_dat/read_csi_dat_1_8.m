function [csi_mat_complex_dat,csi_mat_complex_dat_kspace] = read_csi_dat_1_8(csi_dat_file, zerofill_to_nextpow2_flag, zerofilling_fact, x_shift,y_shift)
%% 0. Preparations


if(~exist('zerofilling_fact','var'))
    zerofilling_fact = 1;
end
if(~exist('zerofill_to_nextpow2_flag','var'))
    zerofill_to_nextpow2_flag = 1;
end


[headersize,total_channel_no,ROW,COL,SLC,vecSize,total_k_points,kline_min,kphase_min] = read_csi_dat_meas_header_1_2(csi_dat_file);
if(zerofill_to_nextpow2_flag)
    ROW = 2^nextpow2(ROW);
    COL = 2^nextpow2(COL);
end



%% 1. READ DATA

tic
raw_csi_fid = fopen(sprintf('%s', csi_dat_file),'r');
fseek(raw_csi_fid, headersize,'bof');                                                               
                
csi_mat_complex_dat_kspace = zeros(total_channel_no,ROW,COL,SLC,vecSize); 

for k_point = 1:total_k_points %total_k_points
    for channel_no = 1:total_channel_no

        chak_header = fread(raw_csi_fid, 64, 'int16');
        if(zerofill_to_nextpow2_flag)
            k_z = 1;                            %k_z = channel_k_header(??);
            k_x = chak_header(17) + 1;    
            k_y = chak_header(22) + 1;            
        else
            k_z = 1;                            %k_z = channel_k_header(??);
            k_x = chak_header(17) + 1 - kline_min;    
            k_y = chak_header(22) + 1 - kphase_min;        
        end
        
        
        if(ge(chak_header(19),1))
            Hadamard_index = chak_header(19) +1;   % SAYS WHICH REPETITION FOR HADAMARD ENCODING OF THE SAME K-POINT IS MEASURED
        else
            Hadamard_index = 1;
        end
        chak_data = fread(raw_csi_fid, vecSize*2, 'float32');
        csi_real = chak_data(1:2:end);
        csi_imag = chak_data(2:2:end);
        csi_complex = complex(csi_real,csi_imag); 
        csi_mat_complex_dat_kspace(channel_no,k_x,k_y,Hadamard_index,:) = csi_complex;
        
    end
end

fclose(raw_csi_fid);
display([ 'Read in Data ... ' num2str(toc) ' seconds' ])



%% 2. Correction: In case of e.g. 42x42 matrix the sequence writes wrong k-space-numbers to dat file --> circshift necessary

if(ROW>1 && ~isa(log2(ROW),'integer'))                                                  
    csi_mat_complex_dat_kspace = circshift(csi_mat_complex_dat_kspace, [0 1 1 0 0]);
end

%csi_mat_complex_dat_k = csi_mat_complex_dat_kspace;


%% 3. ZERO FILLING IN kSPACE

if(ne(zerofilling_fact,1))
    csi_mat_complex_dat_kspace_zerofilled = zeros(total_channel_no,ROW*zerofilling_fact, COL*zerofilling_fact,SLC,vecSize);
    csi_mat_complex_dat_kspace_zerofilled(:,ROW*zerofilling_fact/4+1:ROW*zerofilling_fact*3/4,COL*zerofilling_fact/4+1:COL*zerofilling_fact*3/4,:,:) = csi_mat_complex_dat_kspace;
    clear csi_mat_complex_dat_kspace
    csi_mat_complex_dat_kspace = csi_mat_complex_dat_kspace_zerofilled;
    clear csi_mat_complex_dat_kspace_zerofilled;
end




%% 4. FFT FROM K_SPACE TO DIRECT SPACE

tic

csi_mat_complex_dat = ifftshift(ifftshift(csi_mat_complex_dat_kspace,2),3);
% clear csi_mat_complex_dat_kspace;
csi_mat_complex_dat = fft(fft(csi_mat_complex_dat,ROW*zerofilling_fact,2),COL*zerofilling_fact,3);
csi_mat_complex_dat = conj(csi_mat_complex_dat);                                                    % the chem shift gets higher from right to left --> conj reverses that
csi_mat_complex_dat = fftshift(fftshift(csi_mat_complex_dat,2),3);
csi_mat_complex_dat = flipdim(csi_mat_complex_dat,2);  %THIS FLIPS LEFT AND RIGHT IN SPATIAL DOMAIN BECAUSE PHYSICIANS WANT TO SEE IMAGES FLIPPED

display([ 'FFT Data ... ' num2str(toc) ' seconds' ])



%% 5. Spatial Shift

if(exist('x_shift','var') && ne(x_shift,0))
    csi_mat_complex_dat = circshift(csi_mat_complex_dat, [0 x_shift 0 0 0]);
end

if(exist('y_shift','var') && ne(y_shift,0))
    csi_mat_complex_dat = circshift(csi_mat_complex_dat, [0 0 y_shift 0 0]);
end



%% 6. Hadamard Decoding;

if(SLC>1)
    csi_mat_complex_dat = hadamard_encoding_7(csi_mat_complex_dat);
end



