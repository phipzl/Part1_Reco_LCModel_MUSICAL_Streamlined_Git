function [csi_mat_complex_dat csi_mat_complex_dat_k] = read_csi_dat(csi_dat_file,total_channel_no, total_k_points, ROW,COL, vecSize, zerofilling_fact, x_shift,y_shift)
%% 0. Preparations
SLC = 1;

if(~exist('zerofilling_fact','var'))
    zerofilling_fact = 1;
end


%% 1. READ DATA

raw_csi_fid = fopen(sprintf('%s', csi_dat_file),'r');
fseek(raw_csi_fid, -256*total_channel_no-total_channel_no*total_k_points*(128+vecSize*2*4),'eof');  %in total file is 1586148896 bytes large; 460320 of that is header; then there is for every channel and every k_point a 
                                                                                                    %header which is 128 bytes large and then comes the data which is vecSize (eg 1024*2) * 2 (real, imag) * 
                                                                                                    %4 bytes (because float32) large; at the end there is 256*total_channel_no bytes something unimportant;
csi_mat_complex_dat_kspace = zeros(total_channel_no,ROW,COL,SLC,vecSize);

for k_point = 1:total_k_points %total_k_points
    for channel_no = 1:total_channel_no

        chak_header = fread(raw_csi_fid, 64, 'int16');
        k_z = 1; %k_z = channel_k_header(??);

        k_x = 64 - chak_header(17) + 1;     %THIS FLIPS LEFT AND RIGHT
        k_y = chak_header(22) + 1;
        chak_data = fread(raw_csi_fid, vecSize*2, 'float32');
        csi_real = chak_data(1:2:end);
        %plot(csi_real)
        %waitforbuttonpress
        csi_imag = chak_data(2:2:end);
        csi_complex = complex(csi_real,csi_imag); 
        csi_mat_complex_dat_kspace(channel_no,k_x,k_y,k_z,:) = csi_complex;
    end
% DEBUG MODE    
%        channelll_no = chak_header(63) + 1
%         k_x = 64 - chak_header(17) + 1
%         k_y = chak_header(22) + 1
%         sprintf('\n\n\n')
%         waitforbuttonpress
% DEBUG MODE END
end

csi_mat_complex_dat_k = csi_mat_complex_dat_kspace;
fclose(raw_csi_fid);

%% 2. SHIFT IN K-SPACE, ZERO FILL IN SPATIAL DIMENSIONS, FFT


% % DEBUG MODE
% total_channel_no = 4;
% 
% xxx = real(repmat(exp(1i*x_shift*2*pi/ROW*(1:ROW)),[total_channel_no,1,COL,SLC,vecSize]));
% size(exp(1i*x_shift*2*pi/ROW*(1:ROW)))
% size(repmat(exp(1i*x_shift*2*pi/ROW*(1:ROW)),[total_channel_no,1,COL,SLC,vecSize]))
% size(reshape(repmat(exp(1i*x_shift*2*pi/ROW*(1:ROW)),[total_channel_no,1,COL,SLC,vecSize]), [total_channel_no,ROW,COL,SLC,vecSize]))
% squeeze(xxx(1:4,50:54,1,1,1))
% squeeze(xxx(1,4:8,30:34,1,1))
% squeeze(xxx(1:4,50:54,1,1,2))
% squeeze(xxx(1,4:8,30:34,1,2))
% 
% xxx = real(repmat(reshape(exp(1i*y_shift*2*pi/COL*(1:COL)), [1,1,COL,SLC,1]),[total_channel_no,ROW,1,SLC,vecSize]));
% size(reshape(exp(1i*y_shift*2*pi/COL*(1:COL)), [1,1,COL,SLC,1]))
% size(repmat(reshape(exp(1i*y_shift*2*pi/COL*(1:COL)), [1,1,COL,SLC,1]),[total_channel_no,ROW,1,SLC,vecSize]))
% size(reshape(repmat(reshape(exp(1i*y_shift*2*pi/COL*(1:COL)), [1,1,COL,SLC,1]),[total_channel_no,ROW,1,SLC,vecSize]), [total_channel_no,ROW,COL,SLC,vecSize]))
% squeeze(xxx(1:4,1,50:54,1,1))
% squeeze(xxx(1,4:8,30:34,1,1))
% squeeze(xxx(1:4,1,50:54,1,2))
% squeeze(xxx(1,4:8,30:34,1,2))
% % DEBUG MODE END


% % 2.1 shift right and then up
% if(exist('x_shift','var') && ne(x_shift,0))
%     csi_mat_complex_dat_kspace = repmat(exp(1i*x_shift*2*pi/ROW*(1:ROW)),[total_channel_no,1,COL,SLC,vecSize]) .* csi_mat_complex_dat_kspace;   
%     csi_mat_complex_dat_kspace = csi_mat_complex_dat_kspace * exp(-1i*deg2rad(x_shift*(180 + 360/ROW)));
% end
% 
% if(exist('y_shift','var') && ne(y_shift,0))
%     csi_mat_complex_dat_kspace = repmat(reshape(exp(1i*y_shift*2*pi/COL*(1:COL)),[1,1,COL,SLC,1]),[total_channel_no,ROW,1,SLC,vecSize]) .* csi_mat_complex_dat_kspace;  
%     csi_mat_complex_dat_kspace = csi_mat_complex_dat_kspace * exp(-1i*deg2rad(y_shift*(180 + 360/ROW)));
% end


% 2.2 ZERO FILLING IN kSPACE

if(ne(zerofilling_fact,1))
    csi_mat_complex_dat_kspace_zerofilled = zeros(total_channel_no,ROW*zerofilling_fact, COL*zerofilling_fact,SLC,vecSize);
    csi_mat_complex_dat_kspace_zerofilled(:,ROW*zerofilling_fact/4+1:ROW*zerofilling_fact*3/4,COL*zerofilling_fact/4+1:COL*zerofilling_fact*3/4,:,:) = csi_mat_complex_dat_kspace;
    clear csi_mat_complex_dat_kspace
    csi_mat_complex_dat_kspace = csi_mat_complex_dat_kspace_zerofilled;
    clear csi_mat_complex_dat_kspace_zerofilled;
end

% 2.3 FFT FROM K_SPACE TO DIRECT SPACE
csi_mat_complex_dat = ifftshift(ifftshift(csi_mat_complex_dat_kspace,2),3);
clear csi_mat_complex_dat_kspace;
csi_mat_complex_dat = fft(fft(csi_mat_complex_dat,ROW*zerofilling_fact,2),COL*zerofilling_fact,3);
csi_mat_complex_dat = conj(csi_mat_complex_dat);
csi_mat_complex_dat = fftshift(fftshift(csi_mat_complex_dat,2),3);


% 2.1 shift right and then up
if(exist('x_shift','var') && ne(x_shift,0))
    csi_mat_complex_dat = circshift(csi_mat_complex_dat, [0 x_shift 0 0 0]);
end

if(exist('y_shift','var') && ne(y_shift,0))
    csi_mat_complex_dat = circshift(csi_mat_complex_dat, [0 0 y_shift 0 0]);
end

