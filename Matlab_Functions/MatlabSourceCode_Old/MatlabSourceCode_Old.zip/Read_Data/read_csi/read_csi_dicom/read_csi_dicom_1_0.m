function [csi_mat_complex_dicom, csi_mat_complex_dicom_kspace] = read_csi_dicom_1_0(csi_dicom_file,total_channel_no,ROW,COL,SLC,vecSize)
%% 0. Preparations

% if(~exist('zerofilling_fact','var'))
%     zerofilling_fact = 1;
% end
% 
% if(~exist('x_shift','var'))
%     x_shift = 0;
% end
% 
% if(~exist('y_shift','var'))
%     y_shift = 0;
% end


%[ROW,COL,SLC,vecSize,total_channel_no,total_k_points,headersize] = read_csi_dat_meas_header_1_0(csi_dat_file);


%% 1. READ DATA



%read CSI data
fid = fopen(csi_dicom_file,'r');
fseek(fid, -((vecSize*ROW*COL*SLC*2*4)), 'eof');
csi_data = fread(fid,'float32');
%csi_data = fread(fid,'uint16');
fclose(fid);

csi_real=csi_data(1:2:end);
csi_imag=csi_data(2:2:end);
csi_complex=complex(csi_real,csi_imag);

% create 4D matrix of csi grid
csi_mat_complex_dicom=zeros(total_channel_no,ROW,COL,SLC,vecSize);

k=-1;
for z=1:SLC
    for y=1:ROW
        for x=1:COL
            k=k+1;
            csi_mat_complex_dicom(1,x,y,z,:)=csi_complex(k*vecSize+1:(k+1)*vecSize);	% total channel number not yet implemented
     	end
    end
end

csi_mat_complex_dicom_kspace = 0;


%csi_mat_complex_dicom_k = csi_mat_complex_dicom_kspace;



