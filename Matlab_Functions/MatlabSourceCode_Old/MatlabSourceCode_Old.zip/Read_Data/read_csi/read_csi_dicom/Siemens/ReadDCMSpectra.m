%--------------------------------------------------------------------------
% Read Spectroscpy Data from Dicom Files
% Save each spec series in a different file
% cm 27.5.08
%--------------------------------------------------------------------------

%clear;
 
cd(uigetdir)
listoffiles = dir('*.ima');
numfiles = size(listoffiles,1);

oldimgnum=0;
for k=1:numfiles

file=listoffiles(k).name;
fh = dicom_open(file);
info=dicominfo(file);
imgnum=info.SeriesNumber;
acqnum=info.InstanceNumber;
fid = dicom_get_spectrum_siemens(fh);
%spec = abs(fftshift(fft(fid)));
 
eval(sprintf('SpecSer%02d(:,%d)=fid;',imgnum,acqnum));
%eval(sprintf('SpecSer%02d.spec(:,%d)=spec;',imgnum,acqnum));
%eval(sprintf('SpecSer%02d.info=info;',imgnum));
if imgnum>oldimgnum
    oldimgnum=imgnum;
    disp([imgnum acqnum])
end    
%pause(0.01);
clear fid acqnum imgnum info;
fclose(fh);
end
 
clear fh file k listoffiles numfiles;
 

