function [csi_mat_complex, csi_mat_complex_kspace] = read_csi_1_1(csi_file,zerofilling_fact, x_shift,y_shift,total_channel_no,ROW,COL,SLC,vecSize)
%% 1. Decide whether input file is DICOM or DAT; Call then appropriate function


if(numel(strfind(csi_file, '.dat')) > 0)
    
    % Assign standard values to variables if nothing is passed to function.
    
    if(~exist('zerofilling_fact','var'))
        zerofilling_fact = 1;
    end
    if(~exist('x_shift','var'))
        x_shift = 0;
    end    
    if(~exist('y_shift','var'))
        y_shift = 0;
    end    
    
    [csi_mat_complex,csi_mat_complex_kspace] = read_csi_dat_1_6(csi_file, zerofilling_fact, x_shift,y_shift);
    
else
    
    [csi_mat_complex, csi_mat_complex_kspace] = read_csi_dicom_1_0(csi_file,total_channel_no,ROW,COL,SLC,vecSize);
    
end



