% I have a special folder where ondly one series of dicom images is store
% no other file (only hidden files beggining with '.' should be in that folder)

cd(strcat(directory));
slices = dir(pwd);
for k = length(slices):-1:1 % this is the part removing hidden files
    fname = slices(k).name;
    if fname(1) == '.'
        slices(k) = [];
    end
end
n = numel(slices);
imgs = cell(1,1);
for ii = 1:n
    imgs{1,1}(:,:,ii) = double(dicomread(slices(ii).name));
end

nfo1 = dicominfo(slices(1).name);
% interpolate so 1 mm ~ 1 image voxel
% ba_interp3 (fast binary) need to be downloaded from: 
% http://www.mathworks.com/matlabcentral/fileexchange/21702-3d-volume-interpolation-with-bainterp3-fast-interp3-replacement
[XI,YI,ZI] = meshgrid(1:(floor(10000 * 1 / nfo1.PixelSpacing(1,1)) / 10000):length(imgs{1,1}(1,:,1)),...
    1:(floor(10000 * 1 / nfo1.PixelSpacing(2,1)) / 10000):length(imgs{1,1}(:,1,1)),...
    1:(floor(10000 * 1 / nfo1.SliceThickness) / 10000):length(imgs{1,1}(1,1,:)));
imgs{2,1} = ba_interp3(imgs{1,1},XI,YI,ZI,'nearest'); % fast interpolation to 1x1x1 mm3
[YI,XI,~] = size(imgs{2,1});
