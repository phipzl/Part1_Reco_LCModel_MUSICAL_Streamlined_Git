%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%    FUNCTION TO READ IN THE header of .dat IMAGING FILES    %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% fredir = frequency encoding direction; phadir = phase encoding direction



function [headersize,k_fredir_center,fredir_measured,phadir_measured,total_channel_no] = read_image_dat_meas_header_1_0(image_dat_file)






%% 0. Preparations


% READ SIZE OF HEADER
raw_image_fid = fopen(sprintf('%s', image_dat_file),'r');
headersize = fread(raw_image_fid,1, 'int32');


% READ CENTER OF K-SPACE, MEASURED POINTS IN FREQ ENCOD AND PHASE ENCOD DIRECTION
fseek(raw_image_fid, headersize,'bof');
chak_header = fread(raw_image_fid, 39, 'uint16');
k_fredir_center = chak_header(33)+1;
fredir_measured = chak_header(15);
total_channel_no = chak_header(16);
phadir_measured = chak_header(39)*2;




% phadir_measured = 1;
% fseek(raw_image_fid, headersize,'bof');
% while(~feof(raw_image_fid))
%     
%         chak_header = fread(raw_image_fid, 64, 'uint16')
%         if(chak_header(39) > phadir_measured)
%             phadir_measured = chak_header(39)
%         end
%         fseek(raw_image_fid,fredir_measured*2*4*total_channel_no + 0*(total_channel_no-1)*128,'cof');
%               
% end


% % READ TOTAL CHANNEL NUMBER
% fseek(raw_image_fid, -256,'eof');
% chak_header = fread(raw_image_fid, 16, 'uint16');
% total_channel_no = chak_header(16);

fclose(raw_image_fid);

