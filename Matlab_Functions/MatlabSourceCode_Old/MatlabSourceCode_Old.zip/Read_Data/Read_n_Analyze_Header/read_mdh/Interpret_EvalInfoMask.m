%%%%%%%%%%%%%%%%%%%%% Read Eval Info Mask of MDH %%%%%%%%%%%%%%%%%%%%%%%%%%%%



Prescans_path = '/sacher/mokka1/projects/MRSI_Projects/Measurement_Data/CartesianSequence_SemiFinal_Tests/SequenceTest_bs_gh_ghsi_2plus1DCaip_v_13/meas_MID182_bs_gh_ghsi_2plus1DCaip_1_13_FID22546____5.dat';
Prescans_fid = fopen(sprintf('%s', Prescans_path),'r');

headersize = fread(Prescans_fid,1, 'uint32');
fseek(Prescans_fid, headersize,'bof');
for i = 1:1
    i
    for j = 32:-1:1
        fprintf('%i',mod(j,10))
    end
    mdh = read_mdh(Prescans_fid);
    fseek(Prescans_fid, 4000*4*2, 'cof');
    fprintf('\n%s',dec2bin(mdh.aulEvalInfoMask(1),32))
    fprintf('\n%s',dec2bin(mdh.aulEvalInfoMask(2),32))
    bla1 = dec2bin(mdh.aulEvalInfoMask(1),32);
    bla2 = dec2bin(mdh.aulEvalInfoMask(2),32);
    
    for k = 1:numel(bla1)
        Flags1(k) = logical(str2double(bla1(k)));
        Flags2(k) = logical(str2double(bla2(k)));        
    end
    
    
    
end

fclose(Prescans_fid)


Flags = cat(2,fliplr(Flags1),fliplr(Flags2));



always_zeros = [7,8,10,34,35,36,37,38,39,40,44,45,54,55,56,57,58,59,60,61,62,63,64];

Flags(always_zeros) = [];

