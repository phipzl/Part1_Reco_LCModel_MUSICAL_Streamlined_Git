%Profile1d.m: generate sensitivity profile with phase modulation, complex 
%function [true_profiles]...
%              =profile1d_lp(num_coils,FOV,sigma,center,max_sensitivity, backgroundphase_freq) 
%  output: true profiles
%  backgroundphase_freq: in term of FOV, if ==1, 2*pi variation in the
%  whole FOV
%Copyright: JIM X. JI
%TAMU
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2003 Jim Ji	Source code
% Updated
%-----------------------------------------------------
%-------------------------------------------------------------
%input=number of coils ->num_coils
%image field of vies->FOV
%variance/localization of the coil sensitivity-> sigma
%coil centers ->center
%maximumsensitivity possible ->max_sensitivity;
%background phase -> background_phase
%-------------------------------------------------------------
%output=ideal coil profiles->profiles
%-------------------------------------------------------------
%SIGMA IS THE SCALED VERSION OF THE VARIABLE variance ACCEPTED IN THE MAIN
%PROGRAM CALLING THIS ROUTINE.
%VARIABLE background_phase  IS USED TO RID THE PHASE FOR SMASH
%RECONSTRUCTION
%-------------------------------------------------------------

function [profiles]...
              =profile1d_lp(sigma,Image_size, Receiver) 
FOV=Image_size.PEs;
x=0:(FOV-1);
profiles = zeros(FOV,Receiver.num_coils);
for coil = 1:Receiver.num_coils
	a=normpdf(x,Receiver.center(coil),sigma(coil))';
    profiles(:,coil)=a.*Receiver.max_sensitivity/max(a);

    %phase factor; assume the 3*sigma covers a range of phase (two circles)
    %   0->pi  (-pi)->0->pi  (-pi)-> 0 
 
%     if nargin==6
        %freq = 4*pi/(3*sigma(coil));
        freq = 2*pi*Receiver.backgroundphase_freq;
        phase = exp(j*freq*(x'-Receiver.center(coil)));
        profiles(:,coil)=a.*Receiver.max_sensitivity/max(a).*phase;
%     end, April 25, 2005
end
%backgroundphase specifically added for SMASH code. Firstly the harmonics
%were not getting generated properly with complex profiles. Now they do.
%Aug. 30, 2004

return



