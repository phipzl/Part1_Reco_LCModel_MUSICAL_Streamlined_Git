function rays = rays_image    
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Swati Rane	Source code
% Updated
%-----------------------------------------------------
clc;

rays=zeros(256,256);
    [rs cs]=size(rays);
    origin=round(cs/2);
    end_vector=1:5:cs;
    [trash len_v]=size(end_vector);
    for(k=1:len_v/2)
        hyp=sqrt(256.^2+(256-end_vector(k)).^2);
        theta=atan((128-end_vector(k))/256);
        y_vect=1:1:256;
        x_vect=y_vect.*tan(theta);
        for(cnt=2:256)
            if(ceil(x_vect(cnt))-ceil(x_vect(cnt-1)))<1
                rays(cnt,ceil(x_vect(cnt)))=1;
                rays(cnt-1,ceil(x_vect(cnt-1)))=1;
            else
                diff=(ceil(x_vect(cnt))-ceil(x_vect(cnt-1)));
                rays(cnt,ceil(x_vect(cnt-1):x_vect(cnt)))=1;
            end
        end
    end
    rays=fliplr(flipud(rays));
    rays=circshift(rays,[1 -ceil(cs/2)]);
    rays(:,ceil(cs/2+1:cs))=rays(:,ceil(1:cs/2));
    rays(:,ceil(cs/2+1:cs))=fliplr(rays(:,ceil(cs/2+1:cs)));
    rays(:,ceil(cs/2))=1;               
                
    imagesc(abs(rays));colormap(gray)
    
    return
    
  