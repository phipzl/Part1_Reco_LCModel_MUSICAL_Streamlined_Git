function [I_rec,Misc]...
             =reconstruct_image(option, data_type,full_kspace_data,reduced_kspace_data,Receiver,Sampling,Flags,per_list,regularization_image,Misc, Image_size);
% Swati D. Rane
% TAMU, Jan 21, 2005
% Modified April 5, 2005
%---------------------------------------
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Swati Rane	Source code
% Updated
%-----------------------------------------------------
%input= sampling technique for SPACE RIP ->samp
%flag for tight_harmonic fitting of the SMASH sinusoids ->fit_img
%---------------------------------------
%output=reconstructed image
%---------------------------------------
%ALL THE PARAMETERS REQUIRED ARE CONTINUOUSLY SAVED IN A FILE CALLED parameters.mat
%THIS FILE IS LOADED BEFORE ANY STEP IS EXECUTED.
%----------------------------------------
% RESONCTRUCTION IS PERFORMED THROUGH sense.m, pils.m, smash.m, spacerip.m,
% grappa.m. COILS PROFILES ARE MANIPULATED TO FIT SMOOTH SINUSOIDS IN
% SMASH THROUGH make_profile. THE ACS LINES IN GRAPPA ARE REARRANGED FOR
% RECONSTRUECTION USING prepare_garppa.m. NONUNIFORM SUBSAMPLING IS
% ACHIEVED BY subsamp_gen.m.
%----------------------------------------

switch option
    case 1% SENSE reconstruction
        %SENSE:MRM 42:952-962 (1999)
        %Regularized SENSE: MRM 51:559-567(2004)
        if(Flags.regularization_flag==1)
            %path(path,'C:\PULSAR\source\sense');
            I_rec=sense_tikhnov(Receiver, reduced_kspace_data,regularization_image);
        else
            %path(path,'C:\PULSAR\source\sense');
            I_rec=sense(Receiver,reduced_kspace_data);
        end
        figure, imagesc(abs(I_rec));colormap('gray');title('SENSE Reconstruction');colorbar;
    case 2%PILS reconstruction
        %PILS: MRM 44:602-609 (2000)
        %path(path,'C:\PULSAR\source\pils');
        [I_rec]=pils_gauss(Receiver,reduced_kspace_data,Sampling,Flags);
        figure, imagesc(abs(I_rec));colormap('gray');title('PILS Reconstruction');colorbar;
        
    case 3%SMASH Reconstruction
        %SMASH: MRM 38:591-563 (1997)
        %path(path,'C:\PULSAR\source\smash');
        if(Flags.auto_smash_flag==1)
            if(data_type==1||data_type==2)
                [len trash]=size(Sampling.sampling_location);
                 Sampling.center_locs=Sampling.sampling_location(round(len/2))+(1:Sampling.subsampling_factor-1);
             end
            I_rec=auto_smash(data_type,full_kspace_data,reduced_kspace_data,Sampling, Image_size);
        else
            if(Flags.lin_flag==1)
                reg_profiles=(make_profile(Receiver)); 
                %[Receiver,reg_profiles]=(make_gauss_profile(Receiver)); 
                %instead of make_profile April 22, 2005
            else
                %centers are redefind since the default centers are meant for a
                %linear array
                [Receiver,reg_profiles]=(make_gauss_profile(Receiver));
            end
            I_rec=smash(reduced_kspace_data,reg_profiles,Sampling,Flags,Misc);
        end
        figure,imagesc(abs((I_rec)));colormap('gray');title ('SMASH Reconstruction');colorbar;
    case 4% GRAPPA reconstruction
        %GRAPPA: MRM 47:1202-1210(2002)
        %path(path,'C:\PULSAR\source\grappa');
         [kspread,acs,start_acs_row,consider_coils,nacs]=prepare_grappa2(full_kspace_data,reduced_kspace_data,Sampling,Receiver,data_type,Image_size,Misc);
         I_rec=transpose(grappa(kspread,nacs,acs,start_acs_row,consider_coils,Sampling,Misc));
         figure,imagesc(abs(I_rec));colormap('gray');title('GRAPPA Reconstruction');colorbar;
    case 5% SPACERIP reconstruction
        %SPACE RIP:MRM 44:301-308 (2000)
         %--------------------
         %path(path,'C:\PULSAR\source\space-rip');
         num_lines=Image_size.PEs/Sampling.subsampling_factor+Sampling.center_lines/Sampling.subsampling_factor;
         %number of lines collected with non-uniform sampling must be same
         %as those collected with uniform sampling.
         
         if(data_type~=4)
             if(Misc.samp~=1)
                    [reduced_kspace_data, Sampling] = subsamp_gen(data_type,full_kspace_data,Misc,num_lines,Sampling);
             end
         end
         I_rec=transpose(spacerip(reduced_kspace_data,Receiver,Sampling));
         figure,imagesc(abs(I_rec));colormap('gray');title('SPACE RIP reconstruction');colorbar;
end
 Misc.second_acq=1;
 Misc.cntr=Misc.cntr+1;
return; 
                
% p='C:\temp\frame2\source\common';
% path(p);
save parameters;

return;