function Receiver=fitcurve(Receiver);
%fitting into gaussian 
%Swati Rane, Sept. 30, 2004
%Texas A&M University
%---------------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2004 Swati Rane	Source code
% Updated
%-----------------------------------------------------
%------------------------

[ Ro C num_coils]=size(Receiver.rough_map);

coil_dat=abs(Receiver.rough_map);
[ Ro C num_coils]=size(coil_dat);
for(i=1:num_coils)
    test(:,:,i)=ones(Ro,C);
    coil(:,:,i)=coil_dat(:,:,i);
    xdata=test(:,:,i);
    ydata=coil(:,:,i);
    options=optimset;
    options=optimset('MaxFunEvals',1000);
    x=(lsqcurvefit(@myfun,[C/2 C/num_coils C/2 C/num_coils],xdata,ydata,1,C));

  
    if(x(1)>C)
        x(1)=C-(x(1)-C);
    end
    if(x(3)>C)
        x(3)=C-(x(3)-C);
    end    
    if(x(1)<0)
        x(1)=0;
    end    
    for(k=1:Ro)
        for(l=1:C)
            Receiver.gauss_fit(k,l,i)=exp((-(k-x(1))^2)/(2*x(2)^2))*exp((-(l-x(3))^2)/(2*x(4)^2));
        end
    end
    clear x;
end






