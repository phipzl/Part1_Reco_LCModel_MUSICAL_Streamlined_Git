function I_rec=sos_recon(I_rec, Receiver, Flags,Sampling,option)
%----------------------------------------------
% This function perform an additional iteration to have a coil-by-coil
% recon followed by sos just as in m-SENSE
%
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Swati Rane	Source code
% Updated
%-----------------------------------------------------

tf=isempty(Receiver.center_data);
if(tf==0)
    Receiver.center_data=double(importdata(Files.calibration));
else
    sos_data=Receiver.center_data;
end

[trash trash2 num_coils]=size(sos_data);
if(option ==4 ||(option==3&&Flags.auto_smash_flag==1)) 
%     switch Receiver.sensitivity_estimation
%         case 1% coil sensitivity estimation by coil images
%             refdata=double(importdata(Files.reference_scan));
%             [Receiver, regularization_image]=ref_map(refdata, Flags);       
%         case 2% coil sensitivity estimation by extra calibration lines  
%             [Receiver, regularization_image]=estimate_maps(full_kspace_data,Sampling,Flags,Receiver,Image_size);     
%         case 3% coil sensitivity estimation by Walsh method
%             %MRM 43:682-690 (2000)
%             [Receiver,regularization_image]=walsh_sensitivity(full_kspace_data,Receiver,Sampling,Image_size, data_type);
%     end
end

for(i=1:num_coils)
    coil_fts(:,:,i)=fftshift(fft2(fftshift(I_rec.*Receiver.rough_map(:,:,i))));
    coil_fts(:,Sampling.center_locs,i)=Receiver.center_data(:,:,i);
    coil_im(:,:,i)=abs(ifftshift(ifft2(ifftshift(coil_fts(:,:,i))))).^2;
end
I_rec=sqrt(sum(coil_im,3)/num_coils);
    