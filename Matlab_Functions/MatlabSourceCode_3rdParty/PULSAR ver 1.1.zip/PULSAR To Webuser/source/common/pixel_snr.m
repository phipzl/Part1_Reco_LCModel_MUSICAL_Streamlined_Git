function snrpixel = get_snr(I_req,loop_cnt)
% pixel wise SNR
%Swati D. Rane
%TAMU, April, 2004
%----------------------------------------------
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2004 Swati Rane	Source code
% Updated
%-----------------------------------------------------
[Ro, C]=size(I_req(:,:,1));
% normalise image
for(l=1:loop_cnt)
    add(:,:)=I_req(:,:,l);
    I_req(:,:,l)=I_req(:,:,l)./sum(add(:));
end
for(r=1:Ro)
    for(c=1:C)
       s=I_req(r,c,1:loop_cnt);
       sums=s(:);
       signal=abs(mean(sums));
       noise=std(s);
       snrpixel(r,c)=20*log10(signal/noise);
     end
 end
 
 return
