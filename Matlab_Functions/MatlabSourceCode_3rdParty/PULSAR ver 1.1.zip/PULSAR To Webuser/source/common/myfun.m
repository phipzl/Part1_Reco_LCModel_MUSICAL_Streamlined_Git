function F = myfun(x,xdata)
%---------------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2004 Swati Rane	Source code
% Updated
%-----------------------------------------------------
%F=xdata.*x(1);
%F = xdata.*(exp(-(xdata-x(1)).^2/(2*x(2).^2)));
% [rt ct]=size(xdata);
% t=[1:ct];
% gt=exp((-(t-x(1)).^2)/(2*x(2).^2));
% F=repmat(gt,[rt 1]);
%-----------------------------
[rt ct]=size(xdata);

for(k=1:rt)
    for(l=1:ct)
        F(k,l)=exp((-(k-x(1))^2)/(2*x(2)^2))*exp((-(l-x(3))^2)/(2*x(4)^2));
    end
end
%figure,imagesc(abs(F));
return