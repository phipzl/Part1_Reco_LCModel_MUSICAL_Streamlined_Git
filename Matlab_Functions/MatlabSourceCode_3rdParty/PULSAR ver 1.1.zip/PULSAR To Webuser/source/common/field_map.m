function map2=field_map(image,Receiver)
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Dan Spence, modified Swati Rane	Source code
% Updated
%-----------------------------------------------------
coil=[0; 0];
while(coil(1)*coil(2)~=Receiver.num_coils)
coil(1)=input('How many coils in the array along Y axis? ');
coil(2)=input('How many coils in the array along X axis? ');
end
coils=coil(:);
% FOV=[0.015 0.015];
% Plane=[1 0;0 0;0 1];
% [R C]=size(image)
% Pix=[R C];
% offset=-0.0000;
% Aperature=[0.012 0.012];
% array_offset= 0.0009;
% theta=0;
FOV = [.16; .16];
Plane=[1 0 0 ;0 0 1]';
Pix=[128;128];
%depth=0.045
depth=input('Depth in meters(typically is 4 cm): ');
offset=[0 depth 0]';
Aperature= [.12375; .12375];
theta=0,
array_offset=[0; 0; 0];
Res = FOV./(Pix-1);

grid = zeros(Pix(1),Pix(2),3);

ro = Plane(:,1);
pe = Plane(:,2);

ro = ro/norm(ro);
pe = pe/norm(pe);


lowerleft = -ro*FOV(1)/2 -pe*FOV(2)/2 + offset

for m=1:Pix(1)
   for n=1:Pix(2)
      grid(m,n,:)=lowerleft + (m-1)*ro*Res(1) + (n-1)*pe*Res(2);
   end
end

x = linspace(-FOV(1)/2,FOV(1)/2,Pix(1));
y = linspace(-FOV(2)/2,FOV(2)/2,Pix(2));


coil_dims = Aperature./coils;

w = coil_dims(1);
l = coil_dims(2);

n1 = [cos(theta) sin(theta) 0]';
n2 = [0 0 1]';

n1=n1/norm(n1);
n2=n2/norm(n2);

center = zeros(coils(1),coils(2),3);

lowerleft = -n1*Aperature(1)*(coils(1)-1)/(2*coils(1)) - n2*Aperature(2)*(coils(2)-1)/(2*coils(2)) + array_offset;

for m=1:coils(1)
   for n=1:coils(2)
      center(m,n,:) = lowerleft+(m-1)*n1*w + (n-1)*n2*l;
   end
end

%R = pseudor(coils(1),coils(2));

%scale = 10e6;%/sqrt(coils(1)*coils(2));
map = zeros(coils(1)*coils(2),Pix(1),Pix(2));

%Rp=W*R*W';

%inv_Rp = inv(Rp);

for m=1:Pix(1)
%   m
   for n=1:Pix(2)
      for o=1:coils(1)
         for p=1:coils(2)
            X = squeeze(grid(m,n,:));
            C = squeeze(center(o,p,:));
            temp = square_loop_b(X,C,theta,l,w);
            map( (o-1)*coils(2) + p,m,n) = (temp(1,:) + j*temp(2,:));
           
         end
      end
   end
end

%figure(1);

%surf(y,x,real(map));
%shading interp;
%view([0 90])
%colorbar;

map2=permute(map,[2 3 1]);
%for(i=1:coils(1)*coils(2))
    %figure, imagesc(abs(map2(:,:,i)));
    
    %end






