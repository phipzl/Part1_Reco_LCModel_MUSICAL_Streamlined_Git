function [I_rec, Misc]= Repeat_proc(Misc)
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Swati Rane	Source code
% Updated
%-----------------------------------------------------

         Inputs_list;
         %------------------------------------
         %kspace data collection
         disp('Loading files and generating kspace data...');
         [full_kspace_data,reduced_kspace_data,Sampling, Image_size,Receiver]...
             =get_kspace_data(data_type,Files,Flags,Receiver,Sampling,Misc,per_list,Image_size) ;

         %-------------------------------------
         %sensitivity estimation
         if(option~=4 || (option==3&&Flags.auto_smash_flag==1))
             disp('Estimating sensitivity...');
         end
         [Receiver,regularization_image]...
             =sensitivity_estimation_process(data_type,option,full_kspace_data, reduced_kspace_data,Receiver,Image_size,Files,Sampling,Flags,Misc,per_list);
            
         %------------------------------------
         % image reconstruction
         disp('Reconstructing image...');
         [I_rec, Misc]...
             =reconstruct_image(option, data_type,full_kspace_data,reduced_kspace_data,Receiver,Sampling,Flags,per_list,regularization_image,Misc,Image_size);
         
         %-----------------------------------
return