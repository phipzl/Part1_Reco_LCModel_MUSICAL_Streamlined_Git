function [sensitivity_new]=sensitivity_wavelet(roughsensitivity, wavelet_name, wavelet_levels);
% This function uses wavelet denoising to filter the rough sensitivity
%
% function [sensitivity_new]=sensitivity_wavelet(roughsensitivity, wavelet_name, wavelet_levels);
% maps. Needs Matlab Wavelet Toolbox to work. The user can modify the other denoising parameters in this file.
%
% The real and imaginary parts are filtered separately.
%
% Input: 
%   rouoghsensitivity: raw,nisy sensitivity;
%   wavelet_name: the name of the wavelet, say 'Bior5.5'
%   wavelet_levels: the levels
%
% output: 
% sensitivity_new: filtered sensitivity using wavelet denoising: 
% 
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2003 Jim Ji	Source code
% Updated
%-----------------------------------------------------

[Nx,Ny,Ncoils]=size(roughsensitivity);

for ch=1:Ncoils
    C_real = real(roughsensitivity(:,:,ch));
    C_imag = imag(roughsensitivity(:,:,ch));

    %find the thresholds
    [thrR,sorhR,keepappR] = ddencmp('den','wv',C_real);
    [thrI,sorhI,keepappI] = ddencmp('den','wv',C_imag);

    C_real_den = wdencmp('gbl',C_real,wavelet_name,wavelet_levels,thrR,sorhR,keepappR);
    C_imag_den = wdencmp('gbl',C_imag,wavelet_name,wavelet_levels,thrI,sorhI,keepappI);

     sensitivity_new(:,:,ch) = C_real_den + sqrt(-1)*C_imag_den;
 end
 