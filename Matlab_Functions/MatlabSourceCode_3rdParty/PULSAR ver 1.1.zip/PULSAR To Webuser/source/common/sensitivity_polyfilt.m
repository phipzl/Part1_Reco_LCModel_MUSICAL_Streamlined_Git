function [sensitivity_new]=sensitivity_polyfilt(roughsensitivity,Poly_Order,Width_col,Width_row);
% perform filtering using polynimal fitting
%function [sensitivity_new]=sensitivity_polyfilt(roughsensitivity,Poly_Order,Width_col,Width_row);
% input: 
% rouoghsensitivity: raw,nisy sensitivity;
% Width_col,Width_row: the window size (range of neighboring pixels) considered in polynomial fitting,
% e.g., -fix(W/2) : round(W/2) will be neighbors; 
% Poly_Order: either 1 or 2; order of the polynomials; 
%
% output: filtered sensitivity_new: 
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2003 Jim Ji	Source code
% Updated
%-----------------------------------------------------
[Nx,Ny,Ncoils]=size(roughsensitivity);

%construct the distance polynomial matrix
Wc = fix(Width_col/2); Wr = fix(Width_row/2); 

[dy,dx]=meshgrid( (-Wc):(Wc), (-Wr):(Wr) ); dx=dx(:); dy=dy(:);
N=(2*Wc+1)*(2*Wr+1);
A=ones(N,1);

if Poly_Order==1
    A=[A dx dy dx.*dy]; 
    
else if Poly_Order==2
    A=[A dx dy dx.*dy dx.*dx dy.*dy dx.*dx.*dy dx.*dy.*dy dx.*dx.*dy.*dy]; 
end
end

invA = pinv(A);

sensitivity_new = roughsensitivity;
for coil = 1:Ncoils
    coil
    for i= (Wc+1):(Nx-Wc)
        for j= (Wr+1):(Ny-Wr)
            measured_s = roughsensitivity((i-Wc):(i+Wc),(j-Wr):(j+Wr),coil);
            tmp = invA*measured_s(:);
            sensitivity_new(i,j,coil) = tmp(1);
        end
    end
end
return