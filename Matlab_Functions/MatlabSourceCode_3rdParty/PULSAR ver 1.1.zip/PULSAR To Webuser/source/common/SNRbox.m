% Evaluation
% Swati D. Rane
% TAMU, March 27, 2005
%----------------------------------
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Swati Rane	Source code
% Updated
%-----------------------------------------------------

%SNR by original box method
function SNRvalue=SNRbox(I_rec)

SNR_image=I_rec;

figure, imagesc(abs(SNR_image));colormap('gray');
title('SNR Calculation');

%--------for signal-----------------
disp('Select the ROI to calculate mean signal intensity. ');
[x_co, y_co]=ginput(2);
SNR_image(round(y_co(1):y_co(2)),round(x_co(1)))=max(SNR_image(:));
SNR_image(round(y_co(1):y_co(2)),round(x_co(2)))=max(SNR_image(:));
SNR_image(round(y_co(1)),round(x_co(1):x_co(2)))=max(SNR_image(:));
SNR_image(round(y_co(2)),round(x_co(1):x_co(2)))=max(SNR_image(:));
imagesc(abs(SNR_image));colormap('gray');

signal_region= I_rec(round(y_co(1):y_co(2)),round(x_co(1):x_co(2)));

%---for noise------------------------------------
disp('Select the background area to calculate noise.');
[x_co, y_co]=ginput(2);
SNR_image(round(y_co(1):y_co(2)),round(x_co(1)))=max(SNR_image(:));
SNR_image(round(y_co(1):y_co(2)),round(x_co(2)))=max(SNR_image(:));
SNR_image(round(y_co(1)),round(x_co(1):x_co(2)))=max(SNR_image(:));
SNR_image(round(y_co(2)),round(x_co(1):x_co(2)))=max(SNR_image(:));
imagesc(abs(SNR_image));colormap('gray');

noise_region= I_rec(round(y_co(1):y_co(2)),round(x_co(1):x_co(2)));

sig=mean2(abs(signal_region));
noi=std2(abs(noise_region));

SNRvalue=abs(10*log10((sig/noi).^2));

return;