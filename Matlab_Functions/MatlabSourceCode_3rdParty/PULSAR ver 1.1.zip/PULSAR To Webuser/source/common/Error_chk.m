function error_flag=Error_chk(data_type,Flags,Receiver,Sampling,per_list,Misc,option);
%-error in data_type-----------------
%---------------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Swati Rane	Source code
% Updated
%-----------------------------------------------------
error_flag=0;
if(data_type<1||data_type>4)
    disp('Error: Data_type takes values between 1 and 4 only!');
    error_flag=1;
end
%------------------------------------
%-error in any of the Flags----------
if(Flags.lin_flag~=0&&Flags.lin_flag~=1)
    disp('Error: Variable lin_flag can take values 0 or 1');
    error_flag=1;
end
if(Flags.poly_tick~=0&&Flags.poly_tick~=1)
    disp('Error: Variable poly_tick can take values 0 or 1');
    error_flag=1;
end

switch option
    case 1
    if(Flags.regularization_flag~=0&&Flags.regularization_flag~=1)
        disp('Error: Variable regularization_flag can take values 0 or 1');
        error_flag=1;
    end
    case 3
    if(Flags.auto_smash_flag~=0 && Flags.auto_smash_flag~=1)
        disp('Error: Variable auto_smash_flag can take values 0 or 1');
        error_flag=1;
    end
    if(Flags.auto_smash_flag==0)
        if(Flags.fit_img~=0 && Flags.fit_img~=1)
            disp('Error: Variable fit_img can take values 0 or 1');
            error_flag=1;
        end
    end
end
%---------------------------------------
%-------error in Receiver--------------
if(Receiver.sensitivity_estimation<1||Receiver.sensitivity_estimation>3)
    disp('Error: Variable sensitivity_estimation can take values from 1 to 3');
    error_flag=1;
end
%---------------------------------------
if(option<1||option>5)
    disp('Error: Variable option can take values from 1 to 5');
    error_flag=1;
end
%---error in Misc-----------------------
switch option
    case 3
        if(Misc.per>100)
            disp('Error: Maximum value of variable per is 100');
            error_flag=1;
        end
    case 5
        if(Misc.samp<1||Misc.samp>5)
        disp('Error: Variable samp can take values from 1 to 4');
        error_flag=1;
        end
end
%--------------------------------------
if(per_list<1||per_list>6)
    disp('Error: Variable per_list can take values from 1 to 6');
    error_flag=1;
end