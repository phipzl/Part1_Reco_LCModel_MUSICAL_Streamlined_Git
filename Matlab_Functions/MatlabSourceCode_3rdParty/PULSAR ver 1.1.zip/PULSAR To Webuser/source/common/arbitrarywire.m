function [Bx, By, Bz]=arbitrarywire(x,y,z,Xs,Xe);
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Dan Spence	Source code
% Updated
%-----------------------------------------------------

%find length and direction and center of wire

Dx=Xe-Xs;

len=norm(Dx);

N=(Dx)/len;
S=(Xs);


Bx=Bxarbwire(x,y,z,N,S,len);
By=Byarbwire(x,y,z,N,S,len);
Bz=Bzarbwire(x,y,z,N,S,len);



