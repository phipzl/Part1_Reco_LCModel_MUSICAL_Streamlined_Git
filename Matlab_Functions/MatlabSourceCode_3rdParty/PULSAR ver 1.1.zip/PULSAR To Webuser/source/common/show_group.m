function img=show_group(data,handle,Ncolumn, boundary_width);
%function img=show_group(data,handle,Ncolumn, boundary_width);
% data(Nx,Ny,Nt), 
% handle: the figure handle
% no_columns: the number of slices/frames per row.
% boundary_width: default 0; otherwise insert white stripe between rows and
% columns.
% Jim Ji, Dept. of Electrical Engineering, Texas A&M University

if nargin < 4
    boundary_width = 0;
end

[Nx,Ny,Nt]=size(data);


if nargin < 3
    Ncolumn=ceil(sqrt(Nt));
    if nargin ==1
        handle =1
    end
end

Nrow = ceil(Nt/Ncolumn);

tmp = Ncolumn*Nrow - Nt;
img=max(abs(data(:)))*ones(Nx*Nrow + boundary_width*(Nrow-1),Ny*Ncolumn + boundary_width*(Ncolumn-1));
for frame = 1:Nt
   	ix=double(uint8((frame-1)/Ncolumn));
   	iy=frame-ix*Ncolumn-1;
   	xcord = ((ix*Nx):((ix+1)*Nx-1))+1 + ix*boundary_width;
  	ycord = ((iy*Ny):((iy+1)*Ny-1))+1 + iy*boundary_width;
    img(xcord,ycord)=data(:,:,frame);
end

figure(handle);
imagesc((img));colormap('gray');axis equal; axis tight; axis off

set(findobj(gcf,'type','image'),'ButtonDownFcn','im_pos')

return
