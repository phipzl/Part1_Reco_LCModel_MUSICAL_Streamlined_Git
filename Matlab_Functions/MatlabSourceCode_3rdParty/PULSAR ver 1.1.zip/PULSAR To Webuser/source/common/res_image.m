%generates the reolsution phantom or chooses the simulated phantom
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2004 Swati Rane	Source code
% Updated
%-----------------------------------------------------
function image= res_image

    res=zeros(128,128);
    res(20:120,20:110)=0.5;
    res(40:60,48:80)=0.7;
    res(61:79,48:80)=0.3;
    

    locate=[28 36 40 46 50 54 56 58 60 62  66 70 78 86 94 98 102 104 106 108 110];
    for(r=61:80)
        res(r,locate)=1;
    end
    res(20,20:110)=1;
    res(40,20:110)=1;
  %-------uniform lines---------
    res(20:40,20:2:110)=1;
  %-----------dots-----------
    for(c=21:6:30)
        for(r=42:4:60)
            res(r,c)=1;
        end
    end
    for(c=31:6:40)
        for(r=42:2:60)
            res(r,c)=1;
        end
    end
    for(c=41:4:50)
        for(r=42:2:60)
            res(r,c)=1;
        end
    end
    for(c=51:2:60)
        for(r=42:2:60)
            res(r,c)=1;
        end
    end
    for(c=61:2:70)
        for(r=42:4:60)
            res(r,c)=1;
        end
    end
    for(c=71:4:80)
        for(r=42:4:60)
            res(r,c)=1;
        end
    end
    for(c=81:6:90)
        for(r=42:6:60)
            res(r,c)=1;
        end
    end
    for(c=91:4:100)
        for(r=42:6:60)
            res(r,c)=1;
        end
    end
    for(c=101:2:110)
        for(r=42:6:60)
            res(r,c)=1;
        end
    end
    res(60,20:110)=1;
    %----------oblique lines----------
    res(81,locate)=1;
    for(r=82:100)
        temp=res(r-1,20:110);
        res(r,20:110)=circshift(temp,[-1 1]);
    end
    res(20:120,20)=1;
    res(20:120,110)=1;
    res(100,20:110)=1;
    %---------horizontal lines--------------
    h_locate=[100 101 102 104 106 110 114 116 118 120];
    res(h_locate,20:110)=1;
    
    image=circshift(res,[-5 0]);
    
    image(76,20:110)=1;
%     image(55:94,44:84)=0.6;
%     rays=image(55:94,44:84);
%     [rs cs]=size(rays);
%     origin=round(cs/2);
%     end_vector=1:5:cs;
%     [trash len_v]=size(end_vector);
%     for(k=1:len_v/2)
%         hyp=sqrt(38.^2+(20-end_vector(k)).^2);
%         theta=atan((20-end_vector(k))/38);
%         y_vect=1:1:38;
%         x_vect=y_vect.*tan(theta);
%         for(cnt=2:38)
%             if(ceil(x_vect(cnt))-ceil(x_vect(cnt-1)))<1
%                 rays(cnt,ceil(x_vect(cnt)))=1;
%                 rays(cnt-1,ceil(x_vect(cnt-1)))=1;
%             else
%                 diff=(ceil(x_vect(cnt))-ceil(x_vect(cnt-1)));
%                 rays(cnt,ceil(x_vect(cnt-1):x_vect(cnt)))=1;
%             end
%         end
%     end
%     rays=fliplr(flipud(rays));
%     rays=circshift(rays,[1 -ceil(cs/2)]);
%     rays(:,ceil(cs/2+1:cs))=rays(:,ceil(1:cs/2));
%     rays(:,ceil(cs/2+1:cs))=fliplr(rays(:,ceil(cs/2+1:cs)));
%     rays(:,ceil(cs/2))=1;               
%                 
%                 
%     
%     image(55:94,44:84)=rays;
    image(55,20:110)=1;
    save parameters image '-append';
    %imagesc(abs(image));colormap('gray');
    
         
return;
