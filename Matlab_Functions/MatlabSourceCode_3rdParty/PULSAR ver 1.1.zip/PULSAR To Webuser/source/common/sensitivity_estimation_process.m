function []=sensitivity_estimation_process(data_type,option,full_kspace_data, reduced_kspace_data,Receiver,Image_size,Files,Sampling,Flags,Misc,per_list);


%----------------------------------------------------------------
%sensitivity estimation
%---------------------------------------------------------------
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Swati Rane	Source code
% Updated
%-----------------------------------------------------

%collection of  extra lines
switch data_type  
    case {3,4}    
        tf=exist(Files.calibration);
        if(tf~=0)
           Receiver.center_data=double(importdata(Files.calibration));
        else
            Receiver.center_data=0;
        end

        if(size(Receiver.center_data)~=0)
            if(per_list==2&&(Misc.two_acq=='y'||Misc.two_acq=='Y'))
                if(Misc.second_acq==1)
                    Files.calibration=input('Enter filename for central data of second dataset: ','s');
                    center_data=double(importdata(Files.calibration));
                    %assumption: center_locs is same for both acquisitions.
                else
                    %center_data=double(importdata(Files.calibration));
                end
            end 
            if(per_list==3)
                if(Misc.cntr>1)
                    Files.calibration=input('Enter filename for central data of second dataset: ','s');
                    center_data=double(importdata(Files.calibration));
                    %assumption: center_locs is same for both acquisitions.
                else
                    %center_data=double(importdata(extra_filename));
                end
            end 
            if(Sampling.direction=='Y')
                for(i=1:Receiver.num_coils)
                    center_data1(:,:,i)=transpose(Receiver.center_data(:,:,i));
                end
                clear Receiver.center_data;
                Receiver.center_data=center_data1;
                clear center_data1;
            end
        else
            clear Receiver.center_data;
            [trashf trashp num_coils]=size(full_kspace_data);
            for(i=1:num_coils);
                Receiver.center_data(:,:,i)=full_kspace_data(:,Sampling.center_locs,i);
            end
        end
    otherwise
       Receiver.center_data=0;
end
%-----------------------------------------------------------
%sensitivity estimation methods
% not required for GRAPPa and AUTO-SMASH
switch Receiver.sensitivity_estimation
    case 1% coil sensitivity estimation by coil images
        if(option ==4 ||(option==3&&Flags.auto_smash_flag==1))
            Receiver.rough_map=0;
            regularization_image=0;
        else       
            switch data_type;
                case {3,4}
                    refdata=double(importdata(Files.reference_scan));
                     if(Sampling.direction=='Y')
                         refdata1=refdata;
                         clear refdata;
                        for(i=1:Receiver.num_coils)
                             refdata(:,:,i)=transpose(refdata1(:,:,i));
                        end
                     end
                 otherwise
                     refdata=full_kspace_data;                 
             end
            [Receiver, regularization_image]=ref_map(refdata, Flags,Receiver);
        end
    
    case 2% coil sensitivity estimation by extra calibration lines
   
       if(option==4 || (option==3&&Flags.auto_smash_flag==1))
           Receiver.rough_map=0;
           regularization_image=0;
       else
            [Receiver, regularization_image]=estimate_maps(full_kspace_data,Sampling,Flags,Receiver,Image_size);
       end
       
    case 3% coil sensitivity estimation by Walsh method
    %MRM 43:682-690 (2000)
    
        if(option==4 || (option==3&&auto_smash_flag==1))
            Receiver.rough_map=0;
            regularization_image=0;
        else
            [Receiver,regularization_image]=walsh_sensitivity(full_kspace_data,Receiver,Sampling,Image_size, data_type);
        end
end

%-----------------------------------------------------
%gaussian fitting for PILS
Receiver.gauss_fit=0;
switch option
    case 2
        if((Flags.lin_flag~=1))
             [gauss,rlin,clin]=fitcurve_gauss(abs((Receiver.rough_map)));
             Receiver.center=abs(clin);
             Receiver.gauss_fit=gauss;
             [Ro trashp num_coils]=size(Receiver.rough_map);
             
%                  for(i=1:num_coils)
%                     [maxi index]=max(Receiver.gauss_fit(Ro/2,:,i));
%                     Receiver.center(i)=index;
%                  end
        else
            Receiver.gauss_fit=Receiver.rough_map;
        end
 end
 save parameters;