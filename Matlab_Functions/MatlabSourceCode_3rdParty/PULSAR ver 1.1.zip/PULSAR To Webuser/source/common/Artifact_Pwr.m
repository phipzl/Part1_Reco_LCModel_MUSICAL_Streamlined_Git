function artifact_power=Artifact_Pwr(I_rec, I_ref)
%Artifact power 
%sum over all pixels of square of the difference image by power in ref
%image
%---------------------------------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:VD-AUTO-SMASH Imaging
%            Robin M. Heidemann, Mark A. Griswold, Axel Haase, and Peter M. Jakob
%            Magnetic Resonance in Medicine 45:1066-1074 (2001)

% Version of 4-June-2005.

% Log:
% Created  2004 Swati Rane	Source code
% Updated	
%------------------------------------------------------------------------

%load input_parameters;
image=I_ref;
s_image=max(image(:));
image=image./s_image;

s_rec=max(I_rec(:));
I_rec=I_rec./s_rec;
diff=image-I_rec;
sq_diff=diff.^2;
sum_diff=sum(sq_diff(:));

sq_ref=image.^2;
sum_ref=sum(sq_ref(:));

artifact_power=sum_diff./sum_ref;