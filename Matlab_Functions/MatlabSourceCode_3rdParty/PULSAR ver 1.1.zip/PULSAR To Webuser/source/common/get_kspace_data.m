function [full_kspace_data,reduced_kspace_data,Sampling,Image_size,Receiver]...
         =get_kspace_data(data_type,Files,Flags,Receiver,Sampling,Misc,per_list,Image_size) ;
%Swati D Rane
%TAMU, April 4, 2005
%Modified APril 8, 2005
%---------------------------------------------------
%---------------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Swati Rane	Source code
% Updated
%-----------------------------------------------------
% depending on the data type,  reduced kspace data is simulated
% for image input, sensitivity maps are created
%--------------------------------------------------------------------------
%image inputs
%inputs required: data_type,lin_flag, subsampling_factor, num_coils,variance,backgroundphase_freq,SNR
%--------------------------------------------------------------------------
%kspace inputs:
%inputs required: data_type, lin_flag,subsampling_factor, data
%--------------------------------------------------------------------------
%load input file

switch data_type
    case 1
        switch per_list
            case 5
                image=rays_image;
                [Image_size.FEs, Image_size.PEs]=size(image);
            otherwise
                load mri;
                image=double(D(:,:,10));
                [Image_size.FEs, Image_size.PEs]=size(image);
        end
    case 2
        image=double(importdata(Files.data));
        [Image_size.FEs, Image_size.PEs]=size(image);
    case {3,4}
        if(per_list==2&&(Misc.two_acq=='y'||Misc.two_acq=='Y'))
                if(Misc.second_acq==1)
                    Files.data=input('Enter filename for the second dataset: ','s');
                    kspace_data=double(importdata(Files.data));
                   
                    %assumption: center_locs is same for both acquisitions.
                end
         else
                kspace_data=double(importdata(Files.data));
                    
               
         end 
         if(per_list==3)
                if(Misc.cntr>1)
                   Files.data=input('Enter filename for the second dataset: ','s');
                   kspace_data=double(importdata(Files.data));
        
                    %assumption: center_locs is same for both acquisitions.
                end
          else
                kspace_data=double(importdata(Files.data));
                   
         
         end 
         switch data_type
             case 3
                 full_kspace_data=kspace_data;
                 [Image_size.FEs, Image_size.PEs, Receiver.num_coils]=size(full_kspace_data);
             case 4
                 reduced_kspace_data=kspace_data;
                 [trashf, red_PEs, Receiver.num_coils]=size(reduced_kspace_data);
                  
          end     
end
%--------------------------------------------------------------------------      
%sensitivity generation for data types 1,2
switch data_type
    case {1,2}%for image input, coil sensitvities are simulated
        switch Flags.lin_flag
            case 0%non-linear array of 2D gaussian profiles
                Receiver.sensitivity = field_map(image, Receiver);
                center=0;
            case 1%linear array of 1D gaussian profiles
                Receiver.max_sensitivity=1;
                sigma=Image_size.PEs/Receiver.num_coils*ones(Receiver.num_coils,1)/(2-(Receiver.variance_factor-1)/10);
                %centers of the coil
                Receiver.center = [Image_size.PEs/Receiver.num_coils/2:Image_size.PEs/Receiver.num_coils:Image_size.PEs];
                %generate gaussian sensitivity profiles
                [profiles]=profile1d_lp(sigma,Image_size, Receiver); 
                sensitivity_temp = repmat(profiles,[1,1,Image_size.FEs]); 
                Receiver.sensitivity = permute(sensitivity_temp,[3 1 2]);%coil sensitivities
                clear sensitivity_temp;
        end   
    otherwise
        sensitivity=0;
end
%--------------------------------------------------------------------------
%kspace simulation
switch data_type  
    case 3
        if(Sampling.direction=='Y')% transpose data for further programming convenience
                          % default direction of subsampling is along X ie
                          % colunmns
            for(i=1:Receiver.num_coils);
                temp(:,:,i)=transpose(full_kspace_data(:,:,i));
            end
            clear full_kspace_data;
            full_kspace_data=temp;
        end    
        % default direction of subsampling = along X
        [reduced_kspace_data, Sampling]=sample_kd(full_kspace_data,Sampling);
        %kspace data simulation to get reduced kspace data and sampling
        %locations
    case 4
        if(Sampling.direction=='Y')% transpose data for further programming convenience
                          % default direction of subsampling is along X ie
                          % colunmns
            for(i=1:Receiver.num_coils);
                temp(:,:,i)=transpose(reduced_kspace_data(:,:,i));
            end
            clear reduced_kspace_data;
            reduced_kspace_data=temp;
            [Image_size.FEs, red_PEs, Receiver.num_coils]=size(reduced_kspace_data);
        end    
        full_kspace_data=0;      
    otherwise
        [full_kspace_data, reduced_kspace_data, Sampling]=kspacedata_sim(Receiver, image, Sampling);  
        %kspace data simulation to get reduced kspace data and
        %sampling_locations  
end
%------------------------------------------------------------------------    
save parameters;
return;

