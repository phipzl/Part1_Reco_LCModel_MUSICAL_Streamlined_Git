function [Receiver, regularization_image]=estimate_maps(full_kspace_data,Sampling,Flags,Receiver,Image_size);
%---------------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2004 Swati Rane	Source code
% Updated
%-----------------------------------------------------
%input= full_kspace_data or reduced kspace_data whatever is available. The
%other is zero
%sampling_locations
%centers of the coil ->center
%variable informing the type of data entered ->data_type
%file containing the extra lines 
%--------------------------------------------------
%output=estimated sensitivity maps->rough_maps
%sum of squares data is nothing but the extra ACs lines used for
%sensitivity estimation-> sos_data
%---------------------------------------------------
%ALL THE PARAMETERS REQUIRED ARE CONTINUOUSLY SAVED IN A FILE CALLED parameters.mat
%THIS FILE IS LOADED BEFORE ANY STEP IS EXECUTED
%---------------------------------------------------
%generate sensitvity maps from the given coil data;
%the center of the k space is collected by filtering with a hamming window
%The unaliased coil image obtained from every coil is then divided by the
%sum of squares image obtained form all the coil images together.
%polynomial filtering is provided,  but the maps look better without that .
%---------------------------------------------------
Ro=Image_size.FEs;
C=Image_size.PEs;

%JJ 2005 July, remove Hamming window for coil images; 

if(Receiver.center_data~=0)
    [trashf trashp num_coils]=size(Receiver.center_data);
    for(i=1:num_coils)
       k_coil(:,:,i)=zeros(Ro,C);
       k_coil(:,Sampling.center_locs,i)=Receiver.center_data(:,:,i);
       k_coil_full(:,:,i)=k_coil(:,:,i);
       coil_full(:,:,i)=ifftshift(ifft2(ifftshift(k_coil_full(:,:,i))));
       %figure, imagesc(abs(coil_full(:,:,i)));
       Receiver.sos_data(:,:,i)=Receiver.center_data(:,:,i);
     end      
 else
    [trashp trashf num_coils]=size(full_kspace_data);
    sampl_in=round(Sampling.center_lines/Sampling.subsampling_factor);
    collect_lines=round([C/2-Sampling.center_lines/2-sampl_in:C/2+Sampling.center_lines/2+sampl_in-1]);
    for(i=1:num_coils)
        k_sub_coil(:,:,i)=zeros(Ro,C);
        k_sub_coil(:,collect_lines,i)=full_kspace_data(:,collect_lines,i);
        Receiver.sos_data(:,:,i)=k_sub_coil(:,collect_lines,i);
        k_coil_full(:,:,i)=k_sub_coil(:,:,i);
        coil_full(:,:,i)=ifftshift(ifft2(ifftshift(k_coil_full(:,:,i))));
    end
end

%--------sum of squares image--------------------   
sum_of_squares=sqrt(sum([abs(coil_full)].^2,3)/3);
regularization_image=sum_of_squares;
warning off MATLAB:divideByZero;

for i=1:num_coils
    temp=coil_full(:,:,i);
    Receiver.rough_map(:,:,i)=temp./sum_of_squares;
end

%hamming windowing
%window_col=hamming(Sampling.center_lines);
%hamm_window=repmat(window_col,[1 Ro]);
%hamm_window_full=zeros(Ro,C);
%hamm_window_full(:,round(C/2-Sampling.center_lines/2:C/2+Sampling.center_lines/2-1))=transpose(hamm_window); %zeroed the figh frequency



%----------polynomial filtering-------------
if(Flags.poly_tick==1)
    %------------------------
    Np=1;% order of polynomial
    order=5; %neighborhood pixels considered for filtering

    %------------------------
    for(i=1:num_coils)
        big_map(1:Ro+2*order,1:C+2*order,i)=0;
        big_map(order+1:order+1+Ro-1,order+1:order+1+C-1,i)=Receiver.rough_map(:,:,i);
        temp_map(:,:)=big_map(:,:,i);
        big_map_contoured(:,:,i)=get_contour(big_map(:,:,i),0.01).*big_map(:,:,i);
        clear temp_map;
    end
    roughmap=sensitivity_polyfilt(big_map,Np,order,order);%low pass polynomial
    for( i=1:num_coils)
      Receiver.rough_map(:,:,i)=roughmap(order+1:order+1+Ro-1,order+1:order+1+C-1,i);
    end
end
save parameters;
return