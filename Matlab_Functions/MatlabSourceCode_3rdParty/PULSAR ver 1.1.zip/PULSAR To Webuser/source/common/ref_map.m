function [Receiver, regularization_image]=ref_map(refdata,Flags,Receiver);
% calculate sensitivity maps from reference data
% reference data= full scan kspace data
% Swati D. Rane
% TAMU, March 2005
%-----------------------------------------------
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Swati Rane	Source code
% big_map_contoured never used
% Updated
%-----------------------------------------------------

[Ro C num_coils]=size(refdata);
 for(i=1:num_coils)
      ref_data(:,:,i)=ifftshift(ifft2(ifftshift(refdata(:,:,i))));
 end
 sum_of_squares=sqrt(sum([abs(ref_data)].^2,3)/3);
 for(i=1:num_coils)
      Receiver.rough_map(:,:,i)=ref_data(:,:,i)./sum_of_squares;
 end
 if(Flags.poly_tick==1)
    %------------------------
    Np=1;% order of polynomial
    order=5; %neighborhood pixels considered for filtering

    %------------------------
    for(i=1:num_coils)
        big_map(1:Ro+2*order,1:C+2*order,i)=0;
        big_map(order+1:order+1+Ro-1,order+1:order+1+C-1,i)=Receiver.rough_map(:,:,i);
        temp_map(:,:)=big_map(:,:,i);
        big_map_contoured(:,:,i)=get_contour(big_map(:,:,i),0.01).*big_map(:,:,i);
        clear temp_map;
        %all this used for polnomial fitting
        %figure, imagesc(abs(rough_map(:,:,i)));
    end
    roughmap=sensitivity_polyfilt(big_map,Np,order,order);%low pass polynomial
    for( i=1:num_coils)
      Receiver.rough_map(:,:,i)=roughmap(order+1:order+1+Ro-1,order+1:order+1+C-1,i);
    end
end
save  parameters;
%save parameters collect_lines '-append';
if(Flags.regularization_flag==0);
    regularization_image=0;
else
    regularization_image=sum_of_squares;
end
return