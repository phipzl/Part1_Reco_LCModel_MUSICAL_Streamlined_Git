function [Bx]=Bxarbwire(x,y,z,N,S,len);
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Dan Spence	Source code
% Updated
%-----------------------------------------------------
nx=N(1);
ny=N(2);
nz=N(3);
xs=S(1);
ys=S(2);
zs=S(3);
len;

t=len;
dx=xs-x;
dy=ys-y;
dz=zs-z;


Bx_num1=-2*(2*t+2*nz*(dz)+2*ny*(dy)+2*nx*(dx)).*(ny*(-dz)-nz*(-dy));

Bx_den1=(2*nz*(dz)+2*ny*(dy)+2*nx*(dx)).^2 - 4*((dx).^2 + (dy).^2 + (dz).^2);
Bx_den1=Bx_den1.*sqrt(t^2+2*t*(nz*(dz)+ny*(dy)+nx*(dx))+(dx).^2 +(dy).^2+(dz).^2);

t=0;

Bx_num2=-2*(2*t+2*nz*(dz)+2*ny*(dy)+2*nx*(dx)).*(ny*(-dz)-nz*(-dy));

Bx_den2=(2*nz*(dz)+2*ny*(dy)+2*nx*(dx)).^2 - 4*((dx).^2 + (dy).^2 + (dz).^2);
Bx_den2=Bx_den2.*sqrt(t^2+2*t*(nz*(dz)+ny*(dy)+nx*(dx))+(dx).^2 +(dy).^2+(dz).^2);


Bx=Bx_num1./Bx_den1 - Bx_num2./Bx_den2;

