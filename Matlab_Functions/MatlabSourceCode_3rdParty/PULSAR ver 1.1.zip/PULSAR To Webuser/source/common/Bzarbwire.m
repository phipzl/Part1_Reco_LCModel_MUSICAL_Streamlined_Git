function [Bz]=Bzarbwire(x,y,z,N,S,len);
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Dan Spence	Source code
% Updated
%-----------------------------------------------------
nx=N(1);
ny=N(2);
nz=N(3);
xs=S(1);
ys=S(2);
zs=S(3);


t=len;

Bz_num1=-2*(2*t+2*nz*(zs-z)+2*ny*(ys-y)+2*nx*(xs-x)).*(nx*(y-ys)-ny*(x-xs));

Bz_den1=(2*nz*(zs-z)+2*ny*(ys-y)+2*nx*(xs-x)).^2 - 4*((x-xs).^2 + (y-ys).^2 + (z-zs).^2);
Bz_den1=Bz_den1.*sqrt(t^2+2*t*(nz*(zs-z)+ny*(ys-y)+nx*(xs-x))+(x-xs).^2 +(y-ys).^2+(z-zs).^2);

t=0;

Bz_num2=-2*(2*t+2*nz*(zs-z)+2*ny*(ys-y)+2*nx*(xs-x)).*(nx*(y-ys)-ny*(x-xs));

Bz_den2=(2*nz*(zs-z)+2*ny*(ys-y)+2*nx*(xs-x)).^2 - 4*((x-xs).^2 + (y-ys).^2 + (z-zs).^2);
Bz_den2=Bz_den2.*sqrt(t^2+2*t*(nz*(zs-z)+ny*(ys-y)+nx*(xs-x))+(x-xs).^2 +(y-ys).^2+(z-zs).^2);


Bz=Bz_num1./Bz_den1 - Bz_num2./Bz_den2;


