function [sensitivity_new]=sensitivity_median(roughsensitivity,W);
%function [sensitivity_new]=sensitivity_median(roughsensitivity,W);
% This function filters the rough sensitivity maps using median filter of a size of W*W
%   only the magnitude is filtered and the phase is not.
% input: 
% rouoghsensitivity: raw,nisy sensitivity;
% W: filter window size
% output: 
% sensitivity_new: filtered sensitivity using Hamming window: 
% 
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2003 Jim Ji	Source code
% Updated
%-----------------------------------------------------

[Nfe,Npe,Ncoils]=size(roughsensitivity);

sensitivity_new = zeros(Nfe,Npe,Ncoils);

for i=1:Ncoils
        sM = medfilt2(abs(roughsensitivity(:,:,i)), [W W]); %magnitude
        sA = angle(roughsensitivity(:,:,i)); % phase
        sensitivity_new(:,:,i) = sM.*exp(sqrt(-1)*sA);
end
