function sensitivity_new = sensitivity_walsh(coilcalibrationimages, width)
%function sensitivity_new = sensitivity_walsh(coilcalibrationimages, width)
% 
% input: 
%   coilcalibrationimages: size (Nx,Ny,Ncoils), coil images collected for
%   sensitivity estimation.
%   width, W*W averaging range for correlation matrix, see the Reference
%
% output: filtered sensitivity maps, the same size as the input
%
% Jim Ji, Texas A&M University, 2005, All rights reserved
% jimji@tamu.edu
%
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:  Adaptive Reconstructin of MR Phased Array Imagery
%              D.O. Walsh,A. Gmitro and M. Marcellin 
%              Magentic Resonance in Medicine,vol.43(5), pp.~680-692, 2000

% Version of 4-June-2005.

% Log:
% Created  2005 Jim Ji
% Updated
%-----------------------------------------------------

[Nx,Ny,num_coils]=size(refimg);

R=zeros(Nx,Ny,num_coils,num_coils); 
for i=1:Nx
    i
    for j=1:Ny
            f = refimg(i,j,:);
            f=f(:); 
            R(i,j,:,:) = f*f';
    end
end

%smoothing
win=ones(width,width)/(width*width);

for m=1:num_coils;
    for n=1:num_coils;
        R(:,:,m,n)=filter2(win,R(:,:,m,n),'same');
    end
end

%eigen decomposition
sensitivity_new=zeros(Nx,Ny,num_coils);
for i=1:Nx
    i
    for j=1:Ny
        D=squeeze(R(i,j,:,:));
        [v,d]=eig(D);
        w=v(:,num_coils);%/sqrt(d(num_coils,num_coils)); %Not necessary to normalize with ||f||_2

        %sensitivity
        sensitivity_new(i,j,:)=reshape(w,[1 1 num_coils]);
    end
end

return




