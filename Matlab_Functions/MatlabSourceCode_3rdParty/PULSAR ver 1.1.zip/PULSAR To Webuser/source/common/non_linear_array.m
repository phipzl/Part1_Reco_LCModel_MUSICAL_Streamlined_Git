% non-linear array of 2D gaussian profiles
%Swati D. Rane
% Feb. 18, 2005
%Modified April 8, 2005
%-----------------------------
%---------------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Swati Rane	Source code
% Updated
%-----------------------------------------------------
function sensitivity =non_linear_array(image,Receiver)
clear all;
close all;
clc;

[Ro,C]=size(image);
mux=Ro/2;
muy=C/2;

xlocs=ceil((Receiver.num_coils)/4+1);
if(2*xlocs==Receiver.num_coils)
    ylocs=2;
else
    ylocs=floor((Receiver.num_coils-2*xlocs)/2+2);
end  %find locations of the coils 
diffx=Ro/(xlocs+1);
diffy=C/(ylocs+1);

x_locs=floor(diffx:diffx:Ro-diffx);% find the center of the coils
y_locs=floor(diffy:diffy:C-diffy);
varx=diffx/Receiver.variance_factor;
vary=diffy/Receiver.variance_factor;

k=1;
for(i=1:size(x_locs,2))
    if(i==1)
        for(j=1:size(y_locs,2))
            mu_x(k)=x_locs(i);
            mu_y(k)=y_locs(j);
            k=k+1;
        end
    elseif(i==size(x_locs,2))
        for(j=1:size(y_locs,2))
            mu_x(k)=x_locs(i);
            mu_y(k)=y_locs(j);
            k=k+1;
        end
    else
        mu_x(k)=x_locs(i);
        mu_y(k)=y_locs(1);
        k=k+1;
        mu_x(k)=x_locs(i);
        mu_y(k)=y_locs(size(y_locs,2));
        k=k+1;
    end
end

center= [mu_x(:) mu_y(:)]
for(k=1:Receiver.num_coils)
    for(i=1:Ro)
        for(j=1:C)
            sensitivity(i,j,k)=exp((-(i-mu_x(k))^2)/(2*varx^2))*exp((-(j-mu_y(k))^2)/(2*vary^2));
        end
    end
    %-------------March 30, 2005-------
    Receiver.backgroundphase_freq=0;
     xv=1:C;
     yv=1:Ro;
     freq = 2*pi*Receiver.backgroundphase_freq;
     phase = exp(sqrt(-1)*freq*(xv'-mu_x(k)))*transpose(exp(sqrt(-1)*freq*(yv'-mu_y(k))));
     Receiver.sensitivity(:,:,k)=sensitivity(:,:,k).*phase;
     %-adding phase to sensitivity------
    %figure,imagesc(abs(Receiver.sensitivity(:,:,k)));
end
save parameters;
figure, imagesc(abs(sum(Receiver.sensitivity,3)));
                
    




