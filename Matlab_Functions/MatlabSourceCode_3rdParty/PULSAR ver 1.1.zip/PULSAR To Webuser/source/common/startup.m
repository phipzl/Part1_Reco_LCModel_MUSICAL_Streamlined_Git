path(path,'C:\Documents and Settings\JIMJI\Desktop\pulsartest\source\common\source\common');
path(path,'C:\Documents and Settings\JIMJI\Desktop\pulsartest\source\common\source\sense');
path(path,'C:\Documents and Settings\JIMJI\Desktop\pulsartest\source\common\source\smash');
path(path,'C:\Documents and Settings\JIMJI\Desktop\pulsartest\source\common\source\pils');
path(path,'C:\Documents and Settings\JIMJI\Desktop\pulsartest\source\common\source\grappa');
path(path,'C:\Documents and Settings\JIMJI\Desktop\pulsartest\source\common\source\space-rip');
path(path,'C:\Documents and Settings\JIMJI\Desktop\pulsartest\source\common\examples');
path(path,'C:\Documents and Settings\JIMJI\Desktop\pulsartest\source\common\examples\data');
cd 'C:\Documents and Settings\JIMJI\Desktop\pulsartest\source\common\work'
