function [B] = square_loop_B(X,C,theta,l,w);
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Dan Spence	Source code
% Updated
%-----------------------------------------------------
% X = point to be evaluated at
% C = center of loop
% theta = angle of plane from x-axis  0 = sagital
% l = length of coil along z-axis
% w = width of coil in plane = l by default

if nargin == 4
   w=l;
end

x = X(1,:);
y = X(2,:);
z = X(3,:);

corner1 = zeros(3,1);
corner2 = corner1;
corner3 = corner1;
corner4 = corner1;

corner1(1) = C(1) - cos(theta)*w/2;
corner1(2) = C(2) - sin(theta)*w/2;
corner1(3) = C(3) - l/2;

corner1 = C + [ -cos(theta)*w/2; -sin(theta)*w/2; -l/2];
corner2 = C + [ -cos(theta)*w/2; -sin(theta)*w/2;  l/2];
corner3 = C + [  cos(theta)*w/2;  sin(theta)*w/2;  l/2];
corner4 = C + [  cos(theta)*w/2;  sin(theta)*w/2; -l/2];

Bx = 0;
By = 0;
Bz = 0;

[a,b,c] = arbitrarywire(x,y,z,corner1,corner2);
Bx = Bx-a;
By = By-b;
Bz = Bz-c;

[a,b,c] = arbitrarywire(x,y,z,corner2,corner3);
Bx = Bx-a;
By = By-b;
Bz = Bz-c;

[a,b,c] = arbitrarywire(x,y,z,corner3,corner4);
Bx = Bx-a;
By = By-b;
Bz = Bz-c;

[a,b,c] = arbitrarywire(x,y,z,corner4,corner1);
Bx = Bx-a;
By = By-b;
Bz = Bz-c;


B= 4*pi*1e-7*[Bx; By; Bz];
%B= [Bx; By; Bz];
return 







