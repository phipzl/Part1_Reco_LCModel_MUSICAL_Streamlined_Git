function [Receiver, gprofiles]=make_gauss_profile(Receiver)
%---------------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2003 Swati Rane	Source code
% Updated
%-----------------------------------------------------
%input=rough coil_map
%output= regenerates profiles, coil centers

%function make_gauss_profile
%estimate the center of any non linear array
%if subsampling is along x then need column as the location of the centers
%in PILS
%and the row for harmonic generation in SMASH
%-----------------------------------------------------------
[Ro C num_coils]=size(Receiver.rough_map);
%load input_parameters;
temp_map=(Receiver.rough_map);%abs(rough_map) ??
[gauss,rlin,clin]=fitcurve_gauss(temp_map);
    Receiver.center=round(abs(clin));
    lines=round(abs(rlin));
for(i=1:num_coils)
    if(lines(i)>C)
        lines(i)=C;
    end
    profil(i,:)=Receiver.rough_map(lines(i),:,i);
end
gprofiles=transpose(profil);
return



