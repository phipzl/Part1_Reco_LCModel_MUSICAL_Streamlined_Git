function Perform_parameters=evaluate_method(data_type,Files,I_rec,Misc,per_list)
%---------------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2005 Swati Rane	Source code
% Updated
%-----------------------------------------------------
switch per_list
    case 1%SNR  using the box method
        Perform_parameters.snr=SNRbox(I_rec)
        
    case 2%2 acquisitions SNR
        Misc.two_acq=input('Are two image acquisitions available?(y/n):' ,'s');
        if(Misc.two_acq=='n'||Misc.two_acq=='N')
            disp('Error: Cannot calculate SNR with method 2. Select method 1.');
            return;
        else
        rec_img1=I_rec;
        [rec_img2,Misc]=Repeat_proc(Misc);   
    end
        Perform_parameters.snr=abs(box_snr(rec_img1, rec_img2))
        
    case 3% pixel-wise SNR
         Misc.two_acq=input('Are multiple image acquisitions available?(y/n):' ,'s');
         if(Misc.two_acq=='n'||Misc.two_acq=='N')
            disp('Error: Cannot calculate  pixel wise SNR ');
            return;
        else
        iterations=input('Enter total acquisitions');
        rec_img(:,:,1)=I_rec;
    end
    for(k=2:iterations)
        [rec_img(:,:,k),Misc]=Repeat_proc(Misc);
    end
         Perform_parameters.snr_map=pixel_snr(rec_img,iterations-1);
         figure, imagesc(abs(Perform_parameters.snr_map));colormap('gray');title('Pixelwise SNR');
         
    case 4%artifact power measurement
        %PILS: MRM 44:602-609 (2000)
         switch data_type
             case 1
                 load mri;
                 I_ref=double(D(:,:,10));
             case 2
                 I_ref=double(importdata(Files.data));
             case 3
                 full_kspace_data=double(importdata(Files.data));
                 [trashf trashp num_coils]=size(full_kspace_data);
                 for(i=1:num_coils)
                     coil_img(:,:,i)=ifftshift(ifft2(ifftshift(full_kspace_data(:,:,i))));
                 end
                 I_ref=sqrt(sum([abs(coil_img)].^2,3));
             case 4
                 tf=exist(Files.refrence_image);
                 if(tf==0)
                     disp('Error: No reference image available.');
                 else
                     I_ref=double(importdata(Files.reference_image));
                 end
         end
        Perform_parameters.artifact_power=abs(Artifact_Pwr(I_rec, I_ref))
     case 5
        Perform_parameters.message='No evaluation: Resolution phantom used';

    case 6
        Perform_parameters.message='No evaluation';
    
end
save parameters;
return;