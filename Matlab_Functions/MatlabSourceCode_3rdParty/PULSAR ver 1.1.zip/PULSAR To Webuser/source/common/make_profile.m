function coilprofiles=make_profile(Receiver);
% the coil profile are put together again to find the weighting for SMASH
% coding. (reconstructing the ideal 'fitted_profiles'
%Swati Rane, TAMU
%September 15, 2004
%---------------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2004 Swati Rane	Source code
% Updated
%-----------------------------------------------------
%makes use of the sensitivity profile at the center of the image (DC line)
%rearranges the pofile for harmonic generation
%--------------------------------------------------------------------------
[Ro,C,num_coils]=size(Receiver.rough_map);

for(i=1:num_coils)
    h_ext=zeros(1,C);
    spread=ceil(C/num_coils);
    if(Receiver.center(i)-spread+1<=0 || Receiver.center(i)+spread>=C)
        spread=ceil((spread/2));
    end
    kais_win=kaiser(ceil(spread*2),0.01);
    prof_temp(i,:)=Receiver.rough_map(ceil(Ro/2),:,i);
    h_ext(Receiver.center(i)-spread+1:Receiver.center(i)+spread)=kais_win;
    prof_temp(i,:)=prof_temp(i,:).*h_ext(1:C);
    clear h_ext;       
end
coilprofiles=transpose(prof_temp);
return
