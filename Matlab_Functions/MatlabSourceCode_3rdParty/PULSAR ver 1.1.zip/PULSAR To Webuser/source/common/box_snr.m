function SNRbox = box_snr(rec_img1,rec_img2);
%requires two image acquisitions
%-------------------------------------------

% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2004 Swati Rane	Source code
% Updated	
%-------------------------------------------
figure, imagesc(abs(rec_img1));colormap('gray');
title('SNR caclulation with 2 acquisition: Image 1');
SNR_image1=rec_img1;
disp('Draw of in the ROI to calculate mean signal intensity. ');
[x_co, y_co]=ginput(2);
SNR_image1(round(y_co(1):y_co(2)),round(x_co(1)))=max(SNR_image1(:));
SNR_image1(round(y_co(1):y_co(2)),round(x_co(2)))=max(SNR_image1(:));
SNR_image1(round(y_co(1)),round(x_co(1):x_co(2)))=max(SNR_image1(:));
SNR_image1(round(y_co(2)),round(x_co(1):x_co(2)))=max(SNR_image1(:));
imagesc(abs(SNR_image1));colormap('gray');

roi1= rec_img1(round(y_co(1):y_co(2)),round(x_co(1):x_co(2)));

SNR_image2=rec_img2;
roi2= SNR_image2(round(y_co(1):y_co(2)),round(x_co(1):x_co(2)));
% figure,imagesc(abs(SNR_image2));colormap('gray');
% title('SNR caclulation with 2 acquisition: Image 2');


mean_roi=mean2(roi1);
sub_ron=roi1-roi2;
std_ron=std2(sub_ron);
ratio_sn=(sqrt(2)*mean_roi/std_ron).^2;
SNRbox=10*log10(ratio_sn);


return


