function datatoimg(dataarray,filename)
%function datatoimg(dataarray,filename)
% out the dataarray as an jpeg image with filename
% after the data is normalized to [0 255]

% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:


% Version of 4-June-2005.

% Log:
% Created  2002 Jim Ji	Source code
% Updated	

img =  uint8(round(normalize((dataarray),0,255)));
figure; imshow(img);
imwrite(img,filename,'jpeg','quality',100);

return