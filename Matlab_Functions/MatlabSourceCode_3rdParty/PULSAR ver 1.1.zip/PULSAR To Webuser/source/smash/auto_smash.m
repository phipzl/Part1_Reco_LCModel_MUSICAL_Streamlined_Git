function recon=auto_smash(data_type,full_kspace_data,reduced_kspace_data,Sampling, Image_size);
this is rediculous , full k-space data as input to a parallel imaging recon program, are you kidding?

%AUTO-SMASH
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:AUTO-SMASH: a self-calibrating technique for SMASH imaging. 
%            SiMultaneous Acquisition of Spatial Harmonics.
%            Jakob PM, Griswold MA, Edelman RR, Sodickson DK.
%            MAGMA. 1998 Nov;7(1):42-54
%       
%       a self-calibrating technique for SMASH imaging. In: Proceedings of the. ISMRM Sixth
%       Scientific Meeting and Exhibition, 1998. p 1975

% Version of 4-June-2005.

% Log:
% Created  2004 Swati Rane	Source code
% Updated	
%------------------------------------------------------------------------

%---------------------------------------------
[Ro trashp num_coils]=size(reduced_kspace_data);
nacs=Sampling.subsampling_factor-1;
C=Image_size.PEs;
nharm=Sampling.subsampling_factor;%number of harmonics including fundamental
%---------------------------------------------
switch data_type
    case {3,4}
            for(i=1:num_coils)
                center_data(:,:,i)=full_kspace_data(:,Sampling.center_locs,i);
            end
   
    case {1,2}
        for(i=1:num_coils)
            center_data(:,:,i)=full_kspace_data(:,Sampling.center_locs,i);
        end
end
ref_line=Sampling.center_locs(1)-1;
ref=find(Sampling.sampling_location==ref_line);
tf=isempty(ref);
while(tf==1)
    ref_line=ref_line+1;
    ref=find(Sampling.sampling_location==ref_line);
    tf=isempty(ref)
end
posit=find(Sampling.center_locs==(ref_line+1))
for(i=1:num_coils)
     acs(:,:,i)=center_data(:,posit:posit+nharm-2,i);% posit not generalised
     coil_data(:,:,i)=reduced_kspace_data(:,ref,i);%line for obtaining coeffcients
end
%--------sub-sampled data---------------------

for(i=1:nharm-1)
    tempdata=reshape(coil_data,Ro,num_coils);
    acs_col=acs(:,i,:);
    wt=1;
    composit_acs=sum(wt*acs_col,3);
    coeff(:,i)=pinv(tempdata)*composit_acs;
end

clear tempdata;
tempdata=reshape(reduced_kspace_data,Ro*ceil(C/Sampling.subsampling_factor), num_coils);

    for kshift = [0:nharm-1]
        if(kshift~=0)
            coeff_temp=coeff(:,kshift);
            dataset=tempdata*(coeff_temp);
            dataset=reshape(dataset,Ro,ceil(C/Sampling.subsampling_factor));
          end
      %to arrange the harmonics correctly depending on the sampling location
      %e.g for factor of 4
      %sampling location: 1  5   9   13  ...
      %kspace columns:     1    2   3       4   5   6   7       8   9   10
      %harmonics  opsition:0    1   2,-2   -1   0   1   2,-2    -1  0   1  ...
      %here 2 and -2 harmonic are the same , so averaging is done
      %for a factor of 3
      %sampling location:  2   5   8   11  14
      %kspace columns:     1   2   3   4   5   6   7   8   9 ...
      %harmonics position: -1  0   1  -1   0   1  -1   0   1 ...
      %for all even factors, averaging was required.
      %sampling locationare chose sucht that the center of kspace is always
      %collected     
          if kshift==0
              temp(1:num_coils)=1;
              dataset=tempdata*temp(:);
              dataset=reshape(dataset,Ro,ceil(C/Sampling.subsampling_factor));
              kdata(:,Sampling.sampling_location )=dataset;
          elseif kshift>0
              kdata(:,Sampling.sampling_location + abs(kshift))=dataset;
          elseif kshift<0
                if rem(Sampling.subsampling_factor,2)==1 % odd
                    if(Sampling.sampling_location(1)-abs(kshift)<=0)
                        factor=Sampling.subsampling_factor;
                    else
                    factor=0;
                    end
                    if sum(kdata(:,Sampling.sampling_location+factor  - abs(kshift) )~=0 ) ~=0
                        kdata(:,Sampling.sampling_location+factor  - abs(kshift) ) = (kdata(:,Sampling.sampling_location+factor  - abs(kshift) ) + dataset)/2;
                    else
                        kdata(:,Sampling.sampling_location+factor  - abs(kshift) ) = dataset;
                    end
                 else %even
                    dataset = circshift(dataset, [0 kshift]);
                    if sum(kdata(:,Sampling.sampling_location + Sampling.subsampling_factor - abs(kshift) ) ~=0) ~=0
                        kdata(:,Sampling.sampling_location + Sampling.subsampling_factor - abs(kshift) ) = (kdata(:,Sampling.sampling_location + Sampling.subsampling_factor - abs(kshift) ) + dataset)/2;        
                    else                
                        kdata(:,Sampling.sampling_location + Sampling.subsampling_factor - abs(kshift) ) = dataset;
                    end
                 end
            end
        end
        %end 

[recon]=idft(kdata,Ro,C);
%imagesc(abs(recon));colormap('gray');colorbar;

 
%cp=[kdata(:,64) composit_acs idealk(:,64)];


