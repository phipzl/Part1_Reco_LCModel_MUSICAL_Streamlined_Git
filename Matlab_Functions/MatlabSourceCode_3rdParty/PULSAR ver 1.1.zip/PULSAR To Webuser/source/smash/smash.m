function [recon, successful_flag]=smash(channelsensitivity, reduced_kspace_data, FOV_reduction_factor, ROI_mask)
%function [recon, successful_flag]=smash(channelsensitivity, reduced_kspace_data, FOV_reduction_factor, ROI_mask)
% perform SMASH reconstruction
%----------------------------------------
%Input-
%   channelsensitivity: the spatial coil sensitivity function; 
%   size (Nfe, Npe, Ncoil) or (Npe,Ncoil); For the
%   later case, the 1-D coil sensitivity profile is assumed to be invariant
%   along the Frequency enc direcition.   It is required that 
%    lines_Phase Enc must = Number_Phase Enc_Subsampled * FOV_reduction_factor; 
%
%   reduced_kspace_data: size (Number_Freq Enc, Number_Phase Enc_Subsampled,
%       Number_channels); As a convention, the center k-space line is in the 
%       middle. 
%
%   FOV_reduction_factor: It must be an integer, (FOV of sensitivity function)/(FOV of
%       reduced_kspace_data). If the data acquisition parameters results in
%       fractual reduction factor, then channelsensitivity functions must
%       be cropped and interpolated to make the reduction factor an integer 
%       before calling this function. 
%
%  ROI_mask: an binary mask indicating interested region of interest in the
%  FOV. This can be estimated from the low-resolution coil sensitivity calibration images.
%   It does not have to be accurate and can be set to be a constant matrix
%   1 if not known.
%
%Output-
%   recon: The SMASH reconstruction:  size (Number_Freq Enc,
%   Number_Phase Enc)
%
%   sucessful_flag:  1 if reconstructin is successful and 0 if there is no error in the process.
%                       
%
%--------------------------------------------------------
% The k-space subsampling is along the second dimension.; The leading dimension is
% the frequency encoding; The second dimension is phase encoding; The last
% dimension is the channel index;
%
% Jim Ji, 2002
% University of Illinois at Urbanan-Champaign
%----------------------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

%SMASH RECONSTRUCTION IS DONE: SMOOTH SINUSOIDS ARE GENERATED USING
%smash_fit_harmonics.m. THE DATA HASE TO BE ARRANGED CAREFULLY AFTER IT IS
%SHIFTED FOR SMASH RECONSTRUCTION. THE ARRANEGMENT PROCDURE IS INDICATED
%IN THE COMMENTS BELOW
%-----------------------------------------
%----------------------------------------------
% Simultaneous acquisition of spatial harmonics (SMASH): fast imaging with radiofrequency coil arrays. 
% Sodickson DK, Manning WJ., Magn Reson Med. 1997 Oct;38(4):591-603.
% Log:
% Created  2004 Jim Ji and Swati Rane	Source code
%          2005 Jim Ji remove structures, add annotations, change to
%          line-by-line SMASH fitting, using complex Harmonics
%
% Updated
%-----------------------------------------------------


successful_flag = 0; % will return 1 if reconstructin is successful and there is no error in the process.

if ndims(channelsensitivity) == 3
    [Nfe,Npe,Ncoil]=size(channelsensitivity);
    flag_1dprofile = 0;
else
    if ndims(channelsensitivity) == 2
        [Npe,Ncoil]=size(channelsensitivity);
        flag_1dprofile = 1;
    end
end

[Nfe,Np,Ncoil1]=size(reduced_kspace_data);

if Npe ~= FOV_reduction_factor*Np | Ncoil~=Ncoil
    display('The data size does not match the FOV_reduction_factor for the SMASH reconstruction');
    return
end


%1-D IFT along the Freq enc
reduced_kspace_data = ifftshift(ifft(ifftshift(reduced_kspace_data,1),[],1),1);


kdata=zeros(Nfe,Npe + 2*FOV_reduction_factor); %  synthesized data lines
count = zeros(size(kdata)); % used for average the overlapped synthesized lines



%determine line locations corresponding to 0-th order harmonics
sampling_locations = [(-Np/2):(Np/2-1)]*FOV_reduction_factor + Npe/2 + 1+  FOV_reduction_factor; 

flag_fit_done = 0; % for 1D profile, fitting needs to be done only once

for fe = 1:Nfe
    
    if flag_1dprofile==1 
        if flag_fit_done == 0% 1D fitting
            %fit the harmonics
            [Coef_harmonics, Harmonic_index,synth_harmonics] = smash_fit_harmonic(channelsensitivity, ROI_mask(1,:), FOV_reduction_factor);
            flag_fit_done == 1;
        end
    else
            [Coef_harmonics, Harmonic_index,synth_harmonics] = smash_fit_harmonic(squeeze(channelsensitivity(fe,:,:)), ROI_mask(fe,:), FOV_reduction_factor);
    end
    Nharm = length(Harmonic_index); 

    
    tempdata=squeeze(reduced_kspace_data(fe,:,:)); 

    for i = 1: Nharm
%    for i = 1: FOV_reduction_factor
        kshift = Harmonic_index(i); %line shift for the corresponding harmonics; k-space corresponds to FT space, so harmonic 1 is shift by -1 line
        synthdata=tempdata*Coef_harmonics(:,i);
        kdata(fe,sampling_locations + kshift) = kdata(fe,sampling_locations + kshift) + transpose([synthdata(:)]);
        count(fe,sampling_locations + kshift) = count(fe,sampling_locations + kshift) + 1; 
    end
    
      %to arrange the harmonics correctly depending on the sampling location
      %e.g for R factor of 4
      %sampling location:  1                     5                   9    ...
      %kspace columns:     1    2   3        4   5   6   7       8   9   10
      %harmonics  opsition:0    1   2, -2   -1   0   1   2,-2    -1  0   1  ...
      %here harmonic 2 from line 1 and harmonic -2 from line 5 overlap at
      %the same location. Averaging is done in this case.
      % for R = 3
      %sampling location:      2           5           8 
      %kspace columns:     1   2   3   4   5   6   7   8   9 ...
      %harmonics position: -1  0   1  -1   0   1  -1   0   1 ...

end
  
 % process the synthesized data so it has the same width, height, and FOV as one channel
 % sensitivity function
 kdata = datacrop2d(kdata, Nfe, Npe); 
 count = datacrop2d(count, Nfe, Npe); 
 count(find(count==0)) = 1;

 %average
kdata = kdata./count;

%
[recon]=ifftshift(ifft(ifftshift(kdata,2),[],2),2);
successful_flag = 1;
return