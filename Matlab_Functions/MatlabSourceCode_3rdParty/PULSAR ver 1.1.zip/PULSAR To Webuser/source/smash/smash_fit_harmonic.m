function [Coef_harmonics, Harmonic_index, synth_harmonics] = smash_fit_harmonic(profile,weighvector, FOV_reduction_factor)
%function [Coef_harmonics, Harmonic_index, sinrec, cosrec] = smash_fit_harmonic(profile,weighvector, FOV_reduction_factor)
% This function provides the fitting coefficient for generating sin and cos
% harmonics using the coil sensitiivity function (1D). 
%
%Input:
% profile: 1d sensitivity profile, complex, along phase encoding direciton. 
%           size Npe*Ncoil
% weightvector: vector with length of Npe; use to weigh the harmonic fitting at
% difference location. This can be used to, for example, to force the
% fitting only in object areas. This increase the robustness of the fitting
% as the sensitivity in the backgrouond area contains mainly noise. 
%  This can be also used to implement the tailored-SMASH
%
% FOV_reduction_factor: the subsample factor, used to determin the number
% of harmonics needed.

% flag for tight harmonic fitting ->fit_img
%-------------------------------------------------------
%output:
% Coef_harmonics: Ncoil * Num_harmonics; complex  coefficients for harmonic fitting (sin and cos)
% Harmonic_index: index of harmonics. [-1 0 1] correspondings to
%    exp(-j2*pi*delta k), 1, and exp(j2*pi*delta k)
% synth_harmonics:   actual reconstructed harmonics, used for check fitting accuracy only. 
%--------------------------------------------------------------------------
%
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References:Simultaneous Acquisition of Spatial Harmonics using radio-frequency                    coil Array, D. SoDickson
%                   Magnetic Resonance in Medicine,38:591-563 (1997)

% Version of 4-June-2005.

% Log:
% Created  2003 Jim Ji	Source code
%          2004 swati modi
%          2005 Jim Ji adding weighting vector, annotations
%                      change fitting to Complex harmonics
% Updated
%-----------------------------------------------------

[Npe,Ncoil]=size(profile);

Harmonic_index= -floor(FOV_reduction_factor/2) : floor(FOV_reduction_factor/2);
Nharm = length(Harmonic_index);
% note if 5 complex harmonics -2, -1, 0, 1, 2 are synthesized, it will 
% allow FOV reduction factor (R) of 4.  

%-the calculated sensitivity maps---%    
weighted_profiles=profile.* repmat(weighvector(:), [1 Ncoil]); %weighting 

n=[(-Npe/2):(Npe/2-1)]'; %index along PE
deltak=1/Npe*2*pi;       % k-space interval

Coef_harmonics =zeros(Ncoil,Nharm); 
synth_harmonics=zeros(Npe,Nharm); 

pv=pinv(weighted_profiles);

%finding the coefficients to generate the harmonics
for i=1:Nharm
   harmonic = Harmonic_index(i);
   complexharmonic=exp( - sqrt(-1)*n*deltak*harmonic).*weighvector(:);
   Coef_harmonics(:,i) = pv*complexharmonic;
   
   synth_harmonics(:,i)=(profile)*Coef_harmonics(:,i);
end   

return