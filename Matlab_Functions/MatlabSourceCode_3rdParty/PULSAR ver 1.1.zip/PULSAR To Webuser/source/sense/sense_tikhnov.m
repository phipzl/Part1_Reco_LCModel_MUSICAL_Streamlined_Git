
function [recon] = sense_tikhnov(Receiver, reduced_kspace_data, regularization_image)
%function [recon] = sense_tikhnov(sensitivity, reduced_kspace_data,regularization_image,regularization_matrix)
% This is a simple regularization scheme as proposed by Ketcher,
% I_sense = I_ref + inv(s'*s + lambda'*lambda)*s'*(I_overlapped - s * I_ref)
%  regularization_matrix is the matrix of [lambda(x,y)]; can be simply an
%  identity matrix, or the one derived from error image. 
%
% The reductin is done along the second dimension uniformally.
% sensitivity: (Nfe,Npe,Ncoils) sensitivity map 
% reduced_kspace_data: (Nfe,Npe/R,Ncoils)
%  regularizaiton_image, full-fov regularization image. E.g., high-snr, low
%                                                       resoultion images 
%  regularization_matrix, matrix with the same size as the image, for improving numerical condition
% solution: (Nfe,Npe) reconstruced image;
%
% Jim Ji, 2005; jimji@tamu.edu. All rights reserved
% Texas A&M University
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.

% References: Regularized SENSE
 %                   Magnetic Resonance in Medicine 51:559-567(2004)

% Version of 4-June-2005.

% Log:
% Created  2005 Jim Ji	Source code
% Updated
%-----------------------------------------------------
overlapped_img = zeros(size(reduced_kspace_data));
[Nfe,Npe_seg,Ncoils] = size(overlapped_img);
Ro=Nfe;
Npe = size(Receiver.rough_map,2);
C=Npe;
Rr = round(Npe/Npe_seg); %if R-round(R) ~=0; display('Reduction factor must be integer!'); return; end;

% generate the overlapped_img: (Nfe,Npe/R,Ncoils) 
% index as [-N/2:(N/2-1)].  Centered, unshifted 
for coil=1:Ncoils
 overlapped_img(:,:,coil)=ifftshift(ifft2(ifftshift(reduced_kspace_data(:,:,coil))));
end
%shift the overlapped image
%fftshift the overlapped_image so it corresponds to the first I(0:(N/2-1)) segment
%For even reduction factor only.  For odd reduction factor, the central portion does not need to be shifted.
if mod(Rr,2)==0
    tmp_img  = overlapped_img;
	overlapped_img(:,1:(Npe_seg/2),:) = tmp_img(:,(Npe_seg/2+1):Npe_seg,:);
	overlapped_img(:,(Npe_seg/2+1):Npe_seg,:) = tmp_img(:,1:(Npe_seg/2),:);
end

recon=zeros(Nfe,Npe);

regularization_matrix=(1/Ncoils)*eye(Ro,C);
%regularization_matrix(:,32:96)=regularization_matrix(:,32:96)*Ncoils*0.2;
for j=1:Npe_seg
   j;
   for i=1:Nfe
      lambda = 0.2;%diag(regularization_matrix(i,j:Npe_seg:(j+Npe_seg*(Rr-1)))); 
      solution_ref = transpose(regularization_image(i,j:Npe_seg:(j+Npe_seg*(Rr-1)))); 
      s1=squeeze(Receiver.rough_map(i,j:Npe_seg:(j+Npe_seg*(Rr-1)),:));
      s=transpose(s1);
      I_mat=squeeze(overlapped_img(i,j,:));
      recon(i,j:Npe_seg:(j+Npe_seg*(Rr-1))) = transpose(solution_ref + inv(s'*s + lambda'*lambda)*s'*(I_mat - s*solution_ref));
  end 
end
%figure, imagesc(abs(1./gmap));colormap('gray');
return;

