% PULSAR for GRAPPA ver 1.0
%	
%	Jim Ji,	Texas A&M University, 2005
%   All rights reserved
%
% Usage			: Please refer to the manual, 'PULSAR USER MANUAL for GRAPPA.'
%
% References:   Generalized Autocalibrating Partially Parallel Acquisitions (GRAPPA), M. Griswold, Magnetic Resonance in Medicne, 47:1202-1210 (2002)

% Log: 
%    Dante, Swati: 2005
%    JJ: 2005, fix ifft problem in recon
%

clc; clear; close all;

%Step1, simulating the subsampled data and coil-calibration data

%loading 8ch brain data
currentdir = pwd;
load(sprintf('%s\\..\\..\\data\\data_brain',currentdir))

% k-space datafile selection. The dimension of matrix in the file is [PE, FE, COIL]. The file should include only one matrix and the name of matrix in the file can be arbitrary.

[header.Npe, header.Nfe, header.num_coils] = size(full_kspace_data);

% Acceleration factor for GRAPPA reconstruction
header.subsampling_factor = input('Subsampling factor? [default: 2] ');
if (isempty(header.subsampling_factor))
		header.subsampling_factor = 2;
end

% Number of reference blocks for GRAPPA reconstruction
header.blocks = input('Block size? [default: 4] ');
if (isempty(header.blocks))
		header.blocks = 4;
end

% Number of ACS lines
header.central_kspace=input(['Number of ACS lines? [default: 32]']);
if (isempty(header.central_kspace))
		header.central_kspace = 32;
end

% Number of coils used for GRAPPA reconstruction
header.consider_coils = input( ['Number of coils for GRAPPA reconstruction? [default: ' num2str(header.num_coils) '] ' ]);
if (isempty(header.consider_coils))
		header.consider_coils = header.num_coils;
end

% Type of coil's geometric distribution
disp('Type of coil distribution?');
header.coil_type = input( ['1: Linear, 2:circularly symmetric coils [default: 2] ' ]);
if (isempty(header.coil_type))
		header.coil_type = 2;
end

% The method of applying Fourier transform
disp('The method of applying Fourier transform? ');
disp('1: 1D IFFT along FE -> GRAPPA Recon -> 1D IFFT along PE ');
header.fft = input( ['2: GRAPPA Recon -> 2D IFFT [default]']);
if (isempty(header.fft))
		header.fft = 2;
end

% The percentage of k-space along frequency-encoding direction to be used for fitting
header.percent = input( ['The percentage of k-space along frequency-encoding direction to be used for fitting [default:90]']);disp(' ');
if (isempty(header.percent))
    header.percent = 90;
end

% Subsampling k-space data along row-direction
[subsampled_full_kspace_data, header] = kspace_subsample(full_kspace_data, header);

% GRAPPA reconstruction
[I_recon, subsampled_full_kspace_data]  = grappa(subsampled_full_kspace_data, header);

% Image-display for GRAPPA reconstruction and sum-of-squre images
dfig = figure; imagesc(I_recon);colormap('gray');axis image;title('PULSAR for GRAPPA Reconstruction');
scrsz = get(0,'ScreenSize'); location = [1 (scrsz(4)/2 - scrsz(4)/2) scrsz(3)/2 scrsz(4)/2];set( dfig, 'Position', location);
I_sumsquare = sqrt(sum((abs(ifftshift(ifft2(ifftshift(full_kspace_data(:,:,1:header.num_coils)))))).^2, 3)); 
dfig = figure; imagesc(I_sumsquare);colormap('gray');axis image;title('Sum-of-square Image');
location = [(1+scrsz(3)/2) (scrsz(4)/2 - scrsz(4)/2) scrsz(3)/2 scrsz(4)/2];  ;set( dfig, 'Position', location);