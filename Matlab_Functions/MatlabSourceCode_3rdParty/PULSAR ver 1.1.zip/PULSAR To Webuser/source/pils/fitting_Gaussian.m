function err = fitting_Gaussian(x,ver_cordinate,hor_cordinate,sensitivity)
    err = x(5)*exp((-(ver_cordinate-x(1)).^2)/(2*x(2)^2) + (-(hor_cordinate-x(3)).^2)/(2*x(4)^2))-sensitivity;
