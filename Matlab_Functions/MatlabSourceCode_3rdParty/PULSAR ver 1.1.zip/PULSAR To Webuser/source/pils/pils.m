function recon = pils(reduced_kspace_data, FOV_reduction_factor, coil_center_location)
% PULSAR for PILS Ver 1.0
%
%	
%	Jim Ji 
%	Department of Electrical Engineering
%	Texas A&M University
%	College Station, TX 77843-3128
%	jimji@tamu.edu
%
%   Jim Ji, 2005, All rights reserved.
%
% Usage			: Please refer to the manual, 'PULSAR USER MANUAL for GRAPPA.'
%
% References: Partially parallel imaging with localized sensitivities (PILS)
%							Magnetic Resonance in Medicine
%							Volume 44, Issue 4, Date: October 2000, Pages: 602-609
%							Mark A. Griswold, Peter M. Jakob, Mathias Nittka, James W. Goldfarb, Axel Haase

[Num_FES, Npe_seg, Num_coils] = size(reduced_kspace_data);
Num_PES = FOV_reduction_factor * Npe_seg;

negative_flag = 0;

recon = zeros(Num_FES,Num_PES);
temp = zeros(Num_FES,Num_PES);

for coil = 1:Num_coils
     mod = exp(-sqrt(-1) * 2 * pi / Npe_seg * (coil_center_location(coil,2) - (Num_PES / 2 + 1)) * [-Npe_seg / 2:(Npe_seg / 2 - 1)]);
     data = reduced_kspace_data(:, :, coil) .* repmat([mod(:)]', [Num_FES, 1]); %centered at coil
     smallcoilimg  = ifftshift(ifft2(ifftshift(data)));
     bigcoilimg = zerofill2d(smallcoilimg, Num_FES, Num_PES);
     data = fftshift(fft2(fftshift(bigcoilimg)));
     
    % shift to the coil center
     mod1 = exp(-sqrt(-1) * 2 * pi / Num_PES * -(coil_center_location(coil,2) - (Num_PES / 2 + 1)) * [-Num_PES / 2:(Num_PES / 2 - 1)]);
     data1 = data .* repmat([mod1(:)]', [Num_FES, 1]); %centered at coil
     coilimg  = ifftshift(ifft2(ifftshift(data1)));
%     figure(2);imagesc(abs(coilimg)); colormap('gray');pause
     recon = recon + abs(coilimg).^2;
end

recon = sqrt(recon);
return
