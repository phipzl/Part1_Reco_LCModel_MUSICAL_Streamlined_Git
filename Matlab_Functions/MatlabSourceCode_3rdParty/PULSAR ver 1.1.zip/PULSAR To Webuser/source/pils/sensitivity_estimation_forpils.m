function coil_center_location = sensitivity_estimation(central_kdata,FOV_reduction_factor,reduced_kspace_data);
% PULSAR for PILS Ver 1.0
%	
%	Jim Ji
% %	Department of Electrical Engineering
%	Texas A&M University
%	College Station, TX 77843-3128
%	jimji@tamu.edu
%
% Usage			: Please refer to the manual, 'PULSAR USER MANUAL for GRAPPA.'
%
% References: Partially parallel imaging with localized sensitivities (PILS)
%							Magnetic Resonance in Medicine
%							Volume 44, Issue 4, Date: October 2000, Pages: 602-609
%							Mark A. Griswold, Peter M. Jakob, Mathias Nittka, James W. Goldfarb, Axel Haase

[Num_FES,trash, Num_coils] = size(central_kdata);
 Num_PES = FOV_reduction_factor * size(reduced_kspace_data, 2);


for(i = 1:Num_coils)
%     tmp = zerofill2d(reduced_kspace_data(:, :, i),Num_FES,Num_PES);
    Rough_map(:, :, i) = ifftshift(ifft2(ifftshift(central_kdata(:,:,i))));
end      

warning off MATLAB:divideByZero;
sos = sqrt(sum([abs(Rough_map)] .^ 2, 3) / 3) + 1e-18;

for i=1:Num_coils
    Rough_map(:,:,i) = abs(Rough_map(:,:,i) ./ sos);
end


[hor_cordinate, ver_cordinate]= meshgrid(1:Num_PES, 1:Num_FES);

err = fitting_Gaussian(round([Num_FES/2+1 Num_FES/Num_coils+1 Num_PES/2+1 Num_PES/Num_coils+1 1]),ver_cordinate,hor_cordinate,Rough_map(:,:,1))

for (i = 1:Num_coils)
    sprintf('Processing coil: %d',i)
%     x = (lsqcurvefit(@fitting,[Num_PES/2 Num_PES/Num_coils Num_PES/2 Num_PES/Num_coils], meshgrid(1:Num_FES, 1:Num_PES), Rough_map(:,:,i), 1, Num_PES));

   [x]= lsqnonlin('fitting_Gaussian',round([Num_FES/2+1 Num_FES/Num_coils+1 Num_PES/2+1 Num_PES/Num_coils+1 1]),[0 1 0 1 0],[],[],ver_cordinate,hor_cordinate,Rough_map(:,:,i));
 
    if (x(1) > Num_FES)
        x(1) = Num_FES - (x(1) - Num_FES);
    end
    if (x(3) > Num_PES)
        x(3) = Num_PES - (x(3) - Num_PES);
    end   
        
        x(1) = max(0, x(1));
        x(3) = max(0, x(3));
        
    coil_center_location(i,1) = x(1); % vertical center of the coil 
    coil_center_location(i,2) = x(3); % horonzental center of the coil
    clear x;
end


