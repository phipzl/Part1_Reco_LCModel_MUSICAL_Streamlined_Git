% PULSAR for PILS Ver 1.0
%
% Jim Ji, Texas A&M University. All rights reserved
%
% Usage			: Please refer to the manual, 'PULSAR USER MANUAL for GRAPPA.'
%
% References: Partially parallel imaging with localized sensitivities (PILS)
%							Magnetic Resonance in Medicine
%							Volume 44, Issue 4, Date: October 2000, Pages: 602-609
%							Mark A. Griswold, Peter M. Jakob, Mathias Nittka, James W. Goldfarb, Axel Haase
% Log:
% Created  2003 Jim Ji	Source code, Modified Jong Bum Son, Swati Rane
% Updated  2005 Jong Bum son
% Updated  2005 JJ


clc;
clear;
close all;


%loading 4ch spine MRI data
currentdir = pwd;
load(sprintf('%s\\..\\..\\data\\data_spine',currentdir))

FOV_full = 1;
FOV_subsampled = 1/2;
FOV_reduction_factor = round(FOV_full/FOV_subsampled); 
Rnoise = eye(4); %noise correlation matrix betweent channels

% k-space data sumsampling
[reduced_kspace_data, Subsampling_locations] = sample_kd(full_kspace_data,FOV_reduction_factor);
save('subsampled_kdata','reduced_kspace_data', 'Subsampling_locations','FOV_reduction_factor','Rnoise');

%coil profile calibration data, used to determine the central locaiton of
%the coils in the FOV along the Phase encoding direction

Num_centrallines = 1;
[Nfe,trash,Ncoil] = size(reduced_kspace_data);
Npe = trash*FOV_reduction_factor;

for ch=1:Ncoil
    central_kdata(:,:,ch) = datacrop2d(full_kspace_data(:,:,ch),Num_centrallines,Npe);
end
save('calibration_centralkdata','central_kdata');

clear


load('subsampled_kdata');
load('calibration_centralkdata');

% Sensitivity estimation
disp('Estimating coil center locations in the FOV...');
coil_center_location = sensitivity_estimation_forpils(central_kdata,FOV_reduction_factor,reduced_kspace_data);

% Reconstruction with PILS
disp('Reconstructing image...');
recon_pils = pils(reduced_kspace_data,FOV_reduction_factor,coil_center_location);


%sum-of-squares recon
%loading 4ch spine MRI data
currentdir = pwd;
load(sprintf('%s\\..\\..\\data\\data_spine',currentdir))

sos = recon_sumofsquares(full_kspace_data,0, Rnoise);

error_image = abs(abs(recon_pils) - sos);

L2diff=norm(error_image(:))

figure(1); imagesc(abs(recon_pils)); colormap('gray'); axis square; colorbar;title('pil recon'); 
figure(2); imagesc(abs(sos)); colormap('gray'); axis square; colorbar;title('sum of squares recon'); 
figure(3); imagesc(error_image); colormap('gray'); axis square; colorbar; title(sprintf('L2 recon error: %s',L2diff));
