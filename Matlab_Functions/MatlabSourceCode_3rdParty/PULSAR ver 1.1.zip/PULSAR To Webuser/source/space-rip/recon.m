clear all
clc
close all
startup

%Step1, simulating the subsampled data and coil-calibration data

%loading 8ch brain data
currentdir = pwd;
load(sprintf('%s\\..\\..\\data\\data_spine',currentdir))

%truncate to smaller size for fast demonstration
Ncoil = size(full_kspace_data,3);
for ch=1:Ncoil
   tmp(:,:,ch) = datacrop2d(full_kspace_data(:,:,ch),128,128);
end
full_kspace_data = tmp; clear tmp;

FOV_full = 1;
FOV_subsampled = 1/2;
FOV_reduction_factor = round(FOV_full/FOV_subsampled); 
Rnoise = eye(Ncoil); %noise correlation matrix betweent channels

% k-space data sumsampling
variable_density_types = 1; %uniform subsampling
target_num_lines =  round(size(full_kspace_data,2)/FOV_reduction_factor);
[reduced_kspace_data, Subsampling_locations,]= subsamp_variabledensity(full_kspace_data, ...
                variable_density_types, target_num_lines);

save('subsampled_kdata','reduced_kspace_data', 'Subsampling_locations','FOV_reduction_factor','Rnoise');

% coil sensitivity calibration data from the central k-space
Num_centrallines = 32;
[Nfe,trash,Ncoil] = size(reduced_kspace_data);

for ch=1:Ncoil
    central_kdata(:,:,ch) = datacrop2d(full_kspace_data(:,:,ch),Nfe,Num_centrallines);
end
save('8ch_centralkdata','central_kdata');


clear 

%Recon processing

load('subsampled_kdata');

%sensitivity estimation
Npe_tobe = size(reduced_kspace_data,2)*FOV_reduction_factor;

% sensitivity estimate

%filename='coilimages.mat'; datatype =1;
filename='8ch_centralkdata.mat'; datatype =2;


 Filters.type ='nofilter'; 
% Filters.type ='polynomial'; Filters.Poly_Order = 1; Filters.poly_Wc=5; Filters.poly_Wr=5; %for poly 
% Filters.type ='walsh';   Filters.walsh_width = 3; % for walsh method, averaging window size
% Filters.type ='median';   Filters.median_width = 3; % median filter window size
% Filters.type ='wavelet';  Filters.wavelet_name = 'bior5.5'; Filters.wavelet_levels=3; % for wavelet
 %Filters.type ='hamming'; %
 [channelsensitivity, ROI_mask]= sensitivity_estimation(filename, datatype, Npe_tobe,Filters,Rnoise);

%show_group(abs(channelsensitivity),3,4); colorbar; title('filtered map: magnitude'); colorbar
%show_group(angle(channelsensitivity),4,4); colorbar; title('filtered map: phase'); colorbar

%sense reconstruction
[recon_spacerip, flag] = spacerip(reduced_kspace_data,channelsensitivity,0.05,Subsampling_locations);

%error map

%sum of square recon as "standard"
currentdir = pwd;
load(sprintf('%s\\..\\..\\data\\data_spine',currentdir))
%truncate to smaller size for fast demonstration
Ncoil = size(full_kspace_data,3);
for ch=1:Ncoil
   tmp(:,:,ch) = datacrop2d(full_kspace_data(:,:,ch),128,128);
end
full_kspace_data = tmp; clear tmp;
sos = recon_sumofsquares(full_kspace_data,0, Rnoise);

error_image = abs(abs(recon_spacerip) - sos);

L2diff=norm(error_image(:))

figure(1); imagesc(abs(recon_spacerip)); colormap('gray'); axis square; colorbar;title('SPACE-RIP recon'); 
figure(2); imagesc(abs(sos)); colormap('gray'); axis square; colorbar;title('sum of squares recon'); 
figure(3); imagesc(error_image); colormap('gray'); axis square; colorbar; title(sprintf('L2 recon error: %s',L2diff));

