function [subsampled_kspace_data, Subsampling_locations]= subsamp_variabledensity(full_kspace_data, variable_density_types, target_num_lines)
%function [subsampled_kspace_data, Subsampling_locations]= subsamp_variabledensity(full_kspace_data, variable_density_types, target_num_lines)
% This function simulates variable-density sampling of the full-FOV k-space data  
% Input
%    full_kspace_data: full-FOV data, [Nfe, Npe, Ncoil]
%    variable_density_types:   Integer	1-4	
%           1: Uniformally subsampling 
%           2: No subsampling, but only crop the central k-space data 
%           3: Uniform subsampling outer k-space + croping central k-space; Num of central lines = min(target_num_lines/2, 32) 
%           4: Non-uniform subsampling outer k-space + croping central k-space; Num of central lines = min(target_num_lines/2, 32) 
%           5: Non-uniform sampling, sampling interval linearly increasing
%              from the centeral k-space to the outer k-space.
%           6: Non-uniform sampling, sampling interval exponentially increasing
%              from the centeral k-space to the outer k-space.
%          
%   target_num_lines: the targeted number of phase encoding lines in the
%       subsampled_kspace_data; Must be an even number
% 
% Output:
%   Subsampled kspace data: [Nfe, target_num_lines, Ncoil]
%   Subsampling locations: vector representing the index of the target_num_lines PE lines of the
%      subsampled_kspace_data in the hyperthetically full-FOV k-space data;
%
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.
%
% References:
%
% Version of 4-August-2005.
%
% Log:
% Created  2004 Swati Rane	Source code
%          2005 Jim Ji, redefine target_num_lines so all scheme returning same number of lines, 
%                   annotations, remove structures, added uniform
%                   subsampling code
% Updated
%-----------------------------------------------------

%------------------------------------------------------------------------
[Nfe,Npe,num_coils]=size(full_kspace_data);

% the Misc.sampling location is the subsampling location; need to take care of
% the even/odd reduction factor; make sure that the central k-space
% (Npe/2+1) is sampled and the subsmapled phase-encodings is an even number.
switch variable_density_types
    case 1 % uniform sampling
        FOV_reduction_factor = round(Npe/target_num_lines);
        [subsampled_kspace_data, Subsampling_locations] = sample_kd(full_kspace_data,FOV_reduction_factor);
        
    case 2 %crop central k-space with Nyquist rate
         Subsampling_locations = (Npe/2 + 1 - target_num_lines/2) : (Npe/2 +target_num_lines/2);   
         Subsampled_kspace_data = full_kspace_data(:,Subsampling_locations,:);
         
    case 3
         Subsampling_locations=[ceil(Npe/2-target_num_lines):2:ceil(Npe/2+target_num_lines-1)];
         zer=find(Subsampling_locations~=0);
         [trash len]=size(zer);
         [trash lens]=size(Subsampling_locations);
         if(len~=lens)
             temp_samp=Subsampling_locations(zer);
             [trash lent]=size(temp_samp);
             while (temp_samp(lent)+1<=Npe)
                 temp_samp(lent+1)=temp_samp(lent)+1;
                 [trash lent]=size(temp_samp);
             end
             clear Subsampling_locations;
             Subsampling_locations=temp_samp;
         end    
     case 4
    %Subsampling_locations=[1:4:Npe/4 Npe/4+1:2:3*Npe/4 3*Npe/4+3:4:Npe];
     n_lines=ceil(target_num_lines/6);
        tp1=Npe/2-ceil(n_lines):Npe/2+floor(n_lines)-1;
        tp2(1)=Npe/2-ceil(n_lines)-2;
        
        tp3(1)=Npe/2+ceil(n_lines/2)+2;
        for(tp=2:ceil(n_lines))
            if(tp2(tp-1)-2>0)
                tp2(tp)=tp2(tp-1)-2;
            end
            if(tp3(tp-1)+2<=Npe)
                tp3(tp)=tp3(tp-1)+2;
            end
        end
        tp4(1)=Npe/2-2*ceil(n_lines)-4;
        tp5(1)=Npe/2+2*ceil(n_lines)+4;
        for(tp=2:ceil(n_lines))    
            tp;
            if(tp4(tp-1)-4>0)
                tp4(tp)=tp4(tp-1)-4;
            else
                tp4(tp)=tp4(tp-1);
            end
            if(tp5(tp-1)+4<=Npe)
                tp5(tp)=tp5(tp-1)+4;
            else
                tp5(tp)=tp5(tp-1);
            end
        end  
        t1=union(union(union(tp1,tp2),union(tp2,tp3)),union(tp4,tp5));
        clear Subsampling_locations;
        Subsampling_locations=sort(t1);
        [trash lens]=size(Subsampling_locations);
        if(lens<target_num_lines)
            deficit=target_num_lines-lens;
            extra=Npe/2-ceil(n_lines)-1-ceil(deficit/2):Npe/2-ceil(n_lines)-2+2*n_lines+ceil(deficit/2);
            Subsampling_locations=sort(union(Subsampling_locations,extra));
        elseif(lens>target_num_lines)
            t2=Subsampling_locations(1:target_num_lines);
            clear Subsampling_locations;
            Subsampling_locations=t2;
        end
    case 5
        Subsampling_locations=union(Subsampling_locations, Sampling.center_locs);
end


       subsampled_kspace_data = full_kspace_data(:,Subsampling_locations,:);

return
