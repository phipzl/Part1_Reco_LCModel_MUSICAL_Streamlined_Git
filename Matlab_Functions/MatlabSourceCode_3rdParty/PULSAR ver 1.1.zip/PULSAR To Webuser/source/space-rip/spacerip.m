function [recon,sucessful_flag]=spacerip(acquired_kspace_data,channelsensitivity,tolerance,varargin)
%function recon=spacerip(acquired_kspace_data,channelsensitivity)
%function for SPACE RIP simulation
% acquired_kspace_data: The subsampled k-space data, possibly with variable density
%       It can take two format:
%       1) if acquired_ksapce_data can be a matrix with the same size as
%       channelsensitivity, i.e., it has all the Phase encoding lines but
%       only at the sampled locations there are valid data. The other lines are
%       simply zeros. As a convention, the central k-space is at (Nfe/2+1,
%       Npe/2+1).
%       2) acquired_kspace_data cound contain only the subsampled lines. In this
%       case, the index of these lines in the full-FOV data must be
%       provided, using a third input, sampling_locations
%
% channelsensitivity: Nfe by Npe by Ncoil 
%
% tolerance: 0 - 1. In solving SPACE-RIP matrix using SVD, any
%    singular values less than a tolerance*max(eigen values) are treated as zero.
%    usually tolerenace = 0 is used. Using a larger
%    number improve the numerical condition but may result in more residual
%    aliasing error. 
%
% varargin: sampling_locations, the index of subsampled lines in
%   acquired_kspace_data. Necessary if acquired_kspace_data has not been zero padded. (i.e., case (2) above) 
%
% OUTPUT:
%   SPACE-RIP reconstruction
%
%   sucessful_flag:  1 if reconstructin is successful and 0 if there is no error in the process.
%                       
%
% 2003 Jim Ji, University of Illinois at Urbana-Champaign
% All Rights Reserved.
%----------------------------------------------
% Copyright (C) 2005 Jim Ji, Texas A&M University.
% All Rights Reserved.
%
% References:Sensitivity Profiles from an Array of Coils for Encoding and
%            Reconstructioin in Parallel, Walid E. Kyriakos, Lawrence P. Panych, 
%            Daniel F. Kacher, Carl-Fredrick Westin, Sumi M. Bao, 
%            Robert V. Mulkern, and Ferenc A. Jolesz1,
%                    Magnetic Resonance in Medicine, 44:301-308 (2000)
%
% Version of 4-August-2005.
%
% Log:
% Created  2004 Swati Rane	new source code
% Updated  2005 Jim Ji Using efficient inversion solver, separate simulation and recon, dft matrix
%           formation simplified, remove structures, using conventional variable numbers
%           

sucessful_flag = 0; % will return 1 if reconstructin is successful and there is no error in the process.

[trash Npe1 trash]=size(acquired_kspace_data);
[Nfe Npe Ncoils]=size(channelsensitivity);

if Npe1 == Npe %case 1)
    projx = sum(sum(abs(acquired_kspace_data), 3),1);
    sampling_location = find(projx~=0);
    acquired_kspace_data = acquired_kspace_data(:,sampling_location,:); 
else % case 2) 
    sampling_location = varargin(1);
    sampling_location = sampling_location{:};
    if length(sampling_location) ~= Npe1
        display('The length of the sampling_location vector does not match that of the kspace data');
        return
    end
end

Nacquired = size(acquired_kspace_data,2);
% convert sampling_location from [-pi pi] to [0 2pi] used in dft matrix
% the first row of dftmtx corresponding to DC
samploc_dft = (sampling_location-(Npe/2+1));
tmp = find(samploc_dft<0);
samploc_dft(tmp) = samploc_dft(tmp) + Npe;
samploc_dft = samploc_dft+1; % 
%---matrix of dft coefficients--------    

df=dftmtx(Npe);
df_reduced=df(samploc_dft,:); %taking care of the fourier coefficients along with the interval
 
%1D fft along the FE direction
acquired_kspace_data=ifftshift(ifft(ifftshift(acquired_kspace_data,1),[],1),1);

channelsensitivity = fftshift(channelsensitivity,2); 

%-- SPACE-RIP reconstruction-----------------
recon = zeros(Nfe,Npe);
for fe=1:Nfe
    fe
    kdata=[];
    Wfull=[];
    for(coil=1:Ncoils)
        kdata = [kdata; transpose(acquired_kspace_data(fe,:,coil))];
        stmp=repmat(channelsensitivity(fe,:,coil),[Nacquired 1]);
        Wfull=[Wfull; stmp.*df_reduced];
    end
    
    if tolerance == 0
        recon(fe,:)=transpose(pinv(Wfull)*kdata);
    else
        e = svds(Wfull,1);
        recon(fe,:)=transpose(pinv_svd(Wfull,tolerance)*kdata);
    end
end       

%**This is because when acquiring/simulating reduced kspace data, the modulated image
% is defined as from -Fov/2 to Fov/2, not from 1 to FOV as in fft;
% therefore need to be fftshifted correspondingly.
recon = fftshift(recon,2); 
sucessful_flag = 1;
return
